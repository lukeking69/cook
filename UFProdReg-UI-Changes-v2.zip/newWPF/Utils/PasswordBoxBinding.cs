using System.Security;
using System.Windows;
using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Utils;

/// <summary>Copies password input to a SecureString source without creating a plaintext ViewModel property.</summary>
public static class PasswordBoxBinding
{
    public static readonly DependencyProperty IsEnabledProperty = DependencyProperty.RegisterAttached(
        "IsEnabled", typeof(bool), typeof(PasswordBoxBinding), new PropertyMetadata(false, OnEnabledChanged));

    public static readonly DependencyProperty SecurePasswordProperty = DependencyProperty.RegisterAttached(
        "SecurePassword", typeof(SecureString), typeof(PasswordBoxBinding), new PropertyMetadata(null));

    public static bool GetIsEnabled(DependencyObject element) => (bool)element.GetValue(IsEnabledProperty);
    public static void SetIsEnabled(DependencyObject element, bool value) => element.SetValue(IsEnabledProperty, value);
    public static SecureString GetSecurePassword(DependencyObject element) => (SecureString)element.GetValue(SecurePasswordProperty);
    public static void SetSecurePassword(DependencyObject element, SecureString value) => element.SetValue(SecurePasswordProperty, value);

    private static void OnEnabledChanged(DependencyObject element, DependencyPropertyChangedEventArgs e)
    {
        if (!(element is PasswordBox passwordBox)) return;
        passwordBox.PasswordChanged -= OnPasswordChanged;
        if ((bool)e.NewValue) passwordBox.PasswordChanged += OnPasswordChanged;
    }

    private static void OnPasswordChanged(object sender, RoutedEventArgs e)
    {
        var passwordBox = (PasswordBox)sender;
        passwordBox.SetCurrentValue(SecurePasswordProperty, passwordBox.SecurePassword);
        passwordBox.GetBindingExpression(SecurePasswordProperty)?.UpdateSource();
    }
}
