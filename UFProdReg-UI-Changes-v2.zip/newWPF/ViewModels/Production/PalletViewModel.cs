using System;
using System.Windows.Input;
using System.Windows.Media;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Production;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Production;

/// <summary>Presentation state and bindable commands for the palette og varo page.</summary>
public sealed class PalletViewModel : WorkspaceViewModelBase
{
    public PalletViewModel()
    {
        DisplayName = "Palette og Varo";
        Icon = PackIconKind.PackageVariant;
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex { get => _selectedTabIndex; set => Set(ref _selectedTabIndex, value); }
    private string _palletId;
    public string PalletId { get => _palletId; set => Set(ref _palletId, value); }
    private string _orderNumber;
    public string OrderNumber { get => _orderNumber; set => Set(ref _orderNumber, value); }
    private string _serialNumber;
    public string SerialNumber { get => _serialNumber; set => Set(ref _serialNumber, value); }
    private string _customerSerialNumber;
    public string CustomerSerialNumber { get => _customerSerialNumber; set => Set(ref _customerSerialNumber, value); }
    private int? _quantityRemaining;
    public int? QuantityRemaining { get => _quantityRemaining; set => Set(ref _quantityRemaining, value); }
    private string _sequence;
    public string Sequence { get => _sequence; set => Set(ref _sequence, value); }
    private string _lotId;
    public string LotId { get => _lotId; set => Set(ref _lotId, value); }
    private string _palletPosition;
    public string PalletPosition { get => _palletPosition; set => Set(ref _palletPosition, value); }
    private string _station;
    public string Station { get => _station; set => Set(ref _station, value); }
    private string _stationMode;
    public string StationMode { get => _stationMode; set => Set(ref _stationMode, value); }
    private bool _isServerConnected;
    public bool IsServerConnected { get => _isServerConnected; set => Set(ref _isServerConnected, value); }
    private bool _isStationOnline;
    public bool IsStationOnline { get => _isStationOnline; set => Set(ref _isStationOnline, value); }
    private bool _isPalletReady;
    public bool IsPalletReady { get => _isPalletReady; set => Set(ref _isPalletReady, value); }
    private bool _isSendEnabled;
    public bool IsSendEnabled { get => _isSendEnabled; set => Set(ref _isSendEnabled, value); }
    private string _registrationStatus;
    public string RegistrationStatus { get => _registrationStatus; set => Set(ref _registrationStatus, value); }
    private string _uF1Status;
    public string UF1Status { get => _uF1Status; set => Set(ref _uF1Status, value); }
    private string _uF2Status;
    public string UF2Status { get => _uF2Status; set => Set(ref _uF2Status, value); }
    private bool _isReadOnly;
    public bool IsReadOnly { get => _isReadOnly; set => Set(ref _isReadOnly, value); }
    private string _palletMessage;
    public string PalletMessage { get => _palletMessage; set => Set(ref _palletMessage, value); }
    private PalletEventRow _selectedPalletEvent;
    public PalletEventRow SelectedPalletEvent { get => _selectedPalletEvent; set => Set(ref _selectedPalletEvent, value); }
    private ICommand _rereadPalletCommand;
    public ICommand RereadPalletCommand { get => _rereadPalletCommand; set => Set(ref _rereadPalletCommand, value); }
    private ICommand _startPalletCommand;
    public ICommand StartPalletCommand { get => _startPalletCommand; set => Set(ref _startPalletCommand, value); }
    private ICommand _cancelPalletCommand;
    public ICommand CancelPalletCommand { get => _cancelPalletCommand; set => Set(ref _cancelPalletCommand, value); }
    private ICommand _unlockSendCommand;
    public ICommand UnlockSendCommand { get => _unlockSendCommand; set => Set(ref _unlockSendCommand, value); }
    private ICommand _skipUFRegistrationCommand;
    public ICommand SkipUFRegistrationCommand { get => _skipUFRegistrationCommand; set => Set(ref _skipUFRegistrationCommand, value); }
    private ICommand _refreshPalletEventsCommand;
    public ICommand RefreshPalletEventsCommand { get => _refreshPalletEventsCommand; set => Set(ref _refreshPalletEventsCommand, value); }

    public BindableCollection<PalletEventRow> PalletEvents { get; } = new();
}
