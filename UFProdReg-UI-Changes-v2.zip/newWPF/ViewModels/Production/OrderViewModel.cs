using System;
using System.Windows.Input;
using System.Windows.Media;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Production;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Production;

/// <summary>Presentation state and bindable commands for the ordre page.</summary>
public sealed class OrderViewModel : WorkspaceViewModelBase
{
    public OrderViewModel()
    {
        DisplayName = "Ordre";
        Icon = PackIconKind.ClipboardText;
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex { get => _selectedTabIndex; set => Set(ref _selectedTabIndex, value); }
    private string _orderInput;
    public string OrderInput { get => _orderInput; set => Set(ref _orderInput, value); }
    private string _orderNumber;
    public string OrderNumber { get => _orderNumber; set => Set(ref _orderNumber, value); }
    private string _orderLine;
    public string OrderLine { get => _orderLine; set => Set(ref _orderLine, value); }
    private string _shopOrder;
    public string ShopOrder { get => _shopOrder; set => Set(ref _shopOrder, value); }
    private string _orderState;
    public string OrderState { get => _orderState; set => Set(ref _orderState, value); }
    private bool _isReadOnly;
    public bool IsReadOnly { get => _isReadOnly; set => Set(ref _isReadOnly, value); }
    private string _customerName;
    public string CustomerName { get => _customerName; set => Set(ref _customerName, value); }
    private string _customerNumber;
    public string CustomerNumber { get => _customerNumber; set => Set(ref _customerNumber, value); }
    private string _vendor;
    public string Vendor { get => _vendor; set => Set(ref _vendor, value); }
    private DateTime? _deliveryDate;
    public DateTime? DeliveryDate { get => _deliveryDate; set => Set(ref _deliveryDate, value); }
    private int? _quantityOrdered;
    public int? QuantityOrdered { get => _quantityOrdered; set => Set(ref _quantityOrdered, value); }
    private int? _quantityProduced;
    public int? QuantityProduced { get => _quantityProduced; set => Set(ref _quantityProduced, value); }
    private int? _quantityRemaining;
    public int? QuantityRemaining { get => _quantityRemaining; set => Set(ref _quantityRemaining, value); }
    private string _startSerialNumber;
    public string StartSerialNumber { get => _startSerialNumber; set => Set(ref _startSerialNumber, value); }
    private string _nextSerialNumber;
    public string NextSerialNumber { get => _nextSerialNumber; set => Set(ref _nextSerialNumber, value); }
    private string _customerSerialStart;
    public string CustomerSerialStart { get => _customerSerialStart; set => Set(ref _customerSerialStart, value); }
    private bool _hasComments;
    public bool HasComments { get => _hasComments; set => Set(ref _hasComments, value); }
    private string _orderNotes;
    public string OrderNotes { get => _orderNotes; set => Set(ref _orderNotes, value); }
    private string _orderComments;
    public string OrderComments { get => _orderComments; set => Set(ref _orderComments, value); }
    private ComponentRow _selectedComponent;
    public ComponentRow SelectedComponent { get => _selectedComponent; set => Set(ref _selectedComponent, value); }
    private string _ultraflowType;
    public string UltraflowType { get => _ultraflowType; set => Set(ref _ultraflowType, value); }
    private string _verificationType;
    public string VerificationType { get => _verificationType; set => Set(ref _verificationType, value); }
    private string _multicalType;
    public string MulticalType { get => _multicalType; set => Set(ref _multicalType, value); }
    private string _programNumber;
    public string ProgramNumber { get => _programNumber; set => Set(ref _programNumber, value); }
    private string _configNumber;
    public string ConfigNumber { get => _configNumber; set => Set(ref _configNumber, value); }
    private string _module1;
    public string Module1 { get => _module1; set => Set(ref _module1, value); }
    private string _module2;
    public string Module2 { get => _module2; set => Set(ref _module2, value); }
    private string _labelTemplate;
    public string LabelTemplate { get => _labelTemplate; set => Set(ref _labelTemplate, value); }
    private string _labelPrinter;
    public string LabelPrinter { get => _labelPrinter; set => Set(ref _labelPrinter, value); }
    private string _yearMark;
    public string YearMark { get => _yearMark; set => Set(ref _yearMark, value); }
    private string _sealMarkState;
    public string SealMarkState { get => _sealMarkState; set => Set(ref _sealMarkState, value); }
    private ICommand _loadOrderCommand;
    public ICommand LoadOrderCommand { get => _loadOrderCommand; set => Set(ref _loadOrderCommand, value); }
    private ICommand _clearOrderCacheCommand;
    public ICommand ClearOrderCacheCommand { get => _clearOrderCacheCommand; set => Set(ref _clearOrderCacheCommand, value); }

    public BindableCollection<ComponentRow> Components { get; } = new();
}
