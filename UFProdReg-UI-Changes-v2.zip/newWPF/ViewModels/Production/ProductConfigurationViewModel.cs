using System;
using System.Windows.Input;
using System.Windows.Media;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Production;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Production;

/// <summary>Presentation state and bindable commands for the produktkonfiguration page.</summary>
public sealed class ProductConfigurationViewModel : WorkspaceViewModelBase
{
    public ProductConfigurationViewModel()
    {
        DisplayName = "Produktkonfiguration";
        Icon = PackIconKind.Cog;
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex { get => _selectedTabIndex; set => Set(ref _selectedTabIndex, value); }
    private string _orderNumber;
    public string OrderNumber { get => _orderNumber; set => Set(ref _orderNumber, value); }
    private string _ultraflowType;
    public string UltraflowType { get => _ultraflowType; set => Set(ref _ultraflowType, value); }
    private string _ultraflowUnit;
    public string UltraflowUnit { get => _ultraflowUnit; set => Set(ref _ultraflowUnit, value); }
    private string _verificationType;
    public string VerificationType { get => _verificationType; set => Set(ref _verificationType, value); }
    private string _verificationAttention;
    public string VerificationAttention { get => _verificationAttention; set => Set(ref _verificationAttention, value); }
    private bool _isTwinUF;
    public bool IsTwinUF { get => _isTwinUF; set => Set(ref _isTwinUF, value); }
    private string _twinSequence;
    public string TwinSequence { get => _twinSequence; set => Set(ref _twinSequence, value); }
    private bool _isGwf;
    public bool IsGwf { get => _isGwf; set => Set(ref _isGwf, value); }
    private bool _isBigFlow;
    public bool IsBigFlow { get => _isBigFlow; set => Set(ref _isBigFlow, value); }
    private bool _testsWithoutUF;
    public bool TestsWithoutUF { get => _testsWithoutUF; set => Set(ref _testsWithoutUF, value); }
    private string _sensorMountingStatus;
    public string SensorMountingStatus { get => _sensorMountingStatus; set => Set(ref _sensorMountingStatus, value); }
    private string _uFSoftwareRevision;
    public string UFSoftwareRevision { get => _uFSoftwareRevision; set => Set(ref _uFSoftwareRevision, value); }
    private string _testProbe;
    public string TestProbe { get => _testProbe; set => Set(ref _testProbe, value); }
    private string _multicalType;
    public string MulticalType { get => _multicalType; set => Set(ref _multicalType, value); }
    private string _programNumber;
    public string ProgramNumber { get => _programNumber; set => Set(ref _programNumber, value); }
    private string _configNumber;
    public string ConfigNumber { get => _configNumber; set => Set(ref _configNumber, value); }
    private string _startSerialNumber;
    public string StartSerialNumber { get => _startSerialNumber; set => Set(ref _startSerialNumber, value); }
    private string _customerSerialStart;
    public string CustomerSerialStart { get => _customerSerialStart; set => Set(ref _customerSerialStart, value); }
    private string _sensorTypeNumber;
    public string SensorTypeNumber { get => _sensorTypeNumber; set => Set(ref _sensorTypeNumber, value); }
    private string _sensorResistance;
    public string SensorResistance { get => _sensorResistance; set => Set(ref _sensorResistance, value); }
    private string _module1PartNumber;
    public string Module1PartNumber { get => _module1PartNumber; set => Set(ref _module1PartNumber, value); }
    private string _module1Revision;
    public string Module1Revision { get => _module1Revision; set => Set(ref _module1Revision, value); }
    private string _module2PartNumber;
    public string Module2PartNumber { get => _module2PartNumber; set => Set(ref _module2PartNumber, value); }
    private string _module2Revision;
    public string Module2Revision { get => _module2Revision; set => Set(ref _module2Revision, value); }
    private string _yearMark;
    public string YearMark { get => _yearMark; set => Set(ref _yearMark, value); }
    private string _sealMarkState;
    public string SealMarkState { get => _sealMarkState; set => Set(ref _sealMarkState, value); }
    private string _sealColourState;
    public string SealColourState { get => _sealColourState; set => Set(ref _sealColourState, value); }
    private string _labelTemplate;
    public string LabelTemplate { get => _labelTemplate; set => Set(ref _labelTemplate, value); }
    private string _labelPrinter;
    public string LabelPrinter { get => _labelPrinter; set => Set(ref _labelPrinter, value); }
    private string _labelValidationState;
    public string LabelValidationState { get => _labelValidationState; set => Set(ref _labelValidationState, value); }
    private SealMarkRow _selectedSealMark;
    public SealMarkRow SelectedSealMark { get => _selectedSealMark; set => Set(ref _selectedSealMark, value); }
    private ImageSource _meterLabelImage;
    public ImageSource MeterLabelImage { get => _meterLabelImage; set => Set(ref _meterLabelImage, value); }
    private ImageSource _yearMarkImage;
    public ImageSource YearMarkImage { get => _yearMarkImage; set => Set(ref _yearMarkImage, value); }
    private ICommand _refreshCommand;
    public ICommand RefreshCommand { get => _refreshCommand; set => Set(ref _refreshCommand, value); }

    public BindableCollection<SealMarkRow> SealMarks { get; } = new();
    public BindableCollection<ImageSource> SealMarkImages { get; } = new();
    public BindableCollection<LookupOption> SensorTypeOptions { get; } = new();
}
