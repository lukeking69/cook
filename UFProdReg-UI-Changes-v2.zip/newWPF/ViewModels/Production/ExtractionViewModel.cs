using System;
using System.Windows.Input;
using System.Windows.Media;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Production;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Production;

/// <summary>Presentation state and bindable commands for the udtag og serienumre page.</summary>
public sealed class ExtractionViewModel : WorkspaceViewModelBase
{
    public ExtractionViewModel()
    {
        DisplayName = "Udtag og serienumre";
        Icon = PackIconKind.Counter;
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex { get => _selectedTabIndex; set => Set(ref _selectedTabIndex, value); }
    private string _orderNumber;
    public string OrderNumber { get => _orderNumber; set => Set(ref _orderNumber, value); }
    private string _shopOrder;
    public string ShopOrder { get => _shopOrder; set => Set(ref _shopOrder, value); }
    private string _orderState;
    public string OrderState { get => _orderState; set => Set(ref _orderState, value); }
    private string _stationMode;
    public string StationMode { get => _stationMode; set => Set(ref _stationMode, value); }
    private string _extractionNumber;
    public string ExtractionNumber { get => _extractionNumber; set => Set(ref _extractionNumber, value); }
    private bool _usesExtraction;
    public bool UsesExtraction { get => _usesExtraction; set => Set(ref _usesExtraction, value); }
    private int? _extractionQuantity;
    public int? ExtractionQuantity { get => _extractionQuantity; set => Set(ref _extractionQuantity, value); }
    private string _startSerialNumber;
    public string StartSerialNumber { get => _startSerialNumber; set => Set(ref _startSerialNumber, value); }
    private int? _numberUsed;
    public int? NumberUsed { get => _numberUsed; set => Set(ref _numberUsed, value); }
    private int? _numberRemaining;
    public int? NumberRemaining { get => _numberRemaining; set => Set(ref _numberRemaining, value); }
    private string _nextSerialNumber;
    public string NextSerialNumber { get => _nextSerialNumber; set => Set(ref _nextSerialNumber, value); }
    private int? _availableForAll;
    public int? AvailableForAll { get => _availableForAll; set => Set(ref _availableForAll, value); }
    private int? _requestedQuantity;
    public int? RequestedQuantity { get => _requestedQuantity; set => Set(ref _requestedQuantity, value); }
    private string _extractionMessage;
    public string ExtractionMessage { get => _extractionMessage; set => Set(ref _extractionMessage, value); }
    private int? _quantityOrdered;
    public int? QuantityOrdered { get => _quantityOrdered; set => Set(ref _quantityOrdered, value); }
    private int? _quantityProduced;
    public int? QuantityProduced { get => _quantityProduced; set => Set(ref _quantityProduced, value); }
    private int? _quantityRemaining;
    public int? QuantityRemaining { get => _quantityRemaining; set => Set(ref _quantityRemaining, value); }
    private string _serialListState;
    public string SerialListState { get => _serialListState; set => Set(ref _serialListState, value); }
    private ExtractedNumberRow _selectedExtractedNumber;
    public ExtractedNumberRow SelectedExtractedNumber { get => _selectedExtractedNumber; set => Set(ref _selectedExtractedNumber, value); }
    private ICommand _fetchExtractionCommand;
    public ICommand FetchExtractionCommand { get => _fetchExtractionCommand; set => Set(ref _fetchExtractionCommand, value); }
    private ICommand _releaseExtractionCommand;
    public ICommand ReleaseExtractionCommand { get => _releaseExtractionCommand; set => Set(ref _releaseExtractionCommand, value); }
    private ICommand _refreshExtractionCommand;
    public ICommand RefreshExtractionCommand { get => _refreshExtractionCommand; set => Set(ref _refreshExtractionCommand, value); }

    public BindableCollection<ExtractedNumberRow> ExtractedNumbers { get; } = new();
}
