using System;
using System.Windows.Input;
using System.Windows.Media;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Production;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Production;

/// <summary>Presentation state and bindable commands for the produktion page.</summary>
public sealed class ProductionViewModel : WorkspaceViewModelBase
{
    public ProductionViewModel()
    {
        DisplayName = "Produktion";
        Icon = PackIconKind.Factory;
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex { get => _selectedTabIndex; set => Set(ref _selectedTabIndex, value); }
    private string _orderInput;
    public string OrderInput { get => _orderInput; set => Set(ref _orderInput, value); }
    private string _orderNumber;
    public string OrderNumber { get => _orderNumber; set => Set(ref _orderNumber, value); }
    private string _customerName;
    public string CustomerName { get => _customerName; set => Set(ref _customerName, value); }
    private DateTime? _deliveryDate;
    public DateTime? DeliveryDate { get => _deliveryDate; set => Set(ref _deliveryDate, value); }
    private int? _quantityOrdered;
    public int? QuantityOrdered { get => _quantityOrdered; set => Set(ref _quantityOrdered, value); }
    private int? _quantityProduced;
    public int? QuantityProduced { get => _quantityProduced; set => Set(ref _quantityProduced, value); }
    private int? _quantityRemaining;
    public int? QuantityRemaining { get => _quantityRemaining; set => Set(ref _quantityRemaining, value); }
    private string _orderState;
    public string OrderState { get => _orderState; set => Set(ref _orderState, value); }
    private bool _isReadOnly;
    public bool IsReadOnly { get => _isReadOnly; set => Set(ref _isReadOnly, value); }
    private string _scanInput;
    public string ScanInput { get => _scanInput; set => Set(ref _scanInput, value); }
    private string _internalNumber;
    public string InternalNumber { get => _internalNumber; set => Set(ref _internalNumber, value); }
    private string _serialNumber;
    public string SerialNumber { get => _serialNumber; set => Set(ref _serialNumber, value); }
    private string _customerSerialNumber;
    public string CustomerSerialNumber { get => _customerSerialNumber; set => Set(ref _customerSerialNumber, value); }
    private string _softwareRevision;
    public string SoftwareRevision { get => _softwareRevision; set => Set(ref _softwareRevision, value); }
    private string _twinSequence;
    public string TwinSequence { get => _twinSequence; set => Set(ref _twinSequence, value); }
    private string _testStatus;
    public string TestStatus { get => _testStatus; set => Set(ref _testStatus, value); }
    private string _testActivity;
    public string TestActivity { get => _testActivity; set => Set(ref _testActivity, value); }
    private string _writeUFStatus;
    public string WriteUFStatus { get => _writeUFStatus; set => Set(ref _writeUFStatus, value); }
    private string _printOKStatus;
    public string PrintOKStatus { get => _printOKStatus; set => Set(ref _printOKStatus, value); }
    private string _registrationStatus;
    public string RegistrationStatus { get => _registrationStatus; set => Set(ref _registrationStatus, value); }
    private string _resultMessage;
    public string ResultMessage { get => _resultMessage; set => Set(ref _resultMessage, value); }
    private string _station;
    public string Station { get => _station; set => Set(ref _station, value); }
    private string _equipment;
    public string Equipment { get => _equipment; set => Set(ref _equipment, value); }
    private string _stationMode;
    public string StationMode { get => _stationMode; set => Set(ref _stationMode, value); }
    private string _operator;
    public string Operator { get => _operator; set => Set(ref _operator, value); }
    private string _communicationStatus;
    public string CommunicationStatus { get => _communicationStatus; set => Set(ref _communicationStatus, value); }
    private string _testTopPort;
    public string TestTopPort { get => _testTopPort; set => Set(ref _testTopPort, value); }
    private bool _usesTestDatabase;
    public bool UsesTestDatabase { get => _usesTestDatabase; set => Set(ref _usesTestDatabase, value); }
    private string _palletId;
    public string PalletId { get => _palletId; set => Set(ref _palletId, value); }
    private string _palletOrderNumber;
    public string PalletOrderNumber { get => _palletOrderNumber; set => Set(ref _palletOrderNumber, value); }
    private string _palletSerialNumber;
    public string PalletSerialNumber { get => _palletSerialNumber; set => Set(ref _palletSerialNumber, value); }
    private string _palletCustomerSerialNumber;
    public string PalletCustomerSerialNumber { get => _palletCustomerSerialNumber; set => Set(ref _palletCustomerSerialNumber, value); }
    private string _ultraflowType;
    public string UltraflowType { get => _ultraflowType; set => Set(ref _ultraflowType, value); }
    private string _ultraflowUnit;
    public string UltraflowUnit { get => _ultraflowUnit; set => Set(ref _ultraflowUnit, value); }
    private string _verificationType;
    public string VerificationType { get => _verificationType; set => Set(ref _verificationType, value); }
    private string _verificationAttention;
    public string VerificationAttention { get => _verificationAttention; set => Set(ref _verificationAttention, value); }
    private bool _isTwinUF;
    public bool IsTwinUF { get => _isTwinUF; set => Set(ref _isTwinUF, value); }
    private bool _isGwf;
    public bool IsGwf { get => _isGwf; set => Set(ref _isGwf, value); }
    private bool _isBigFlow;
    public bool IsBigFlow { get => _isBigFlow; set => Set(ref _isBigFlow, value); }
    private bool _testsWithoutUF;
    public bool TestsWithoutUF { get => _testsWithoutUF; set => Set(ref _testsWithoutUF, value); }
    private string _sensorMountingStatus;
    public string SensorMountingStatus { get => _sensorMountingStatus; set => Set(ref _sensorMountingStatus, value); }
    private string _multicalType;
    public string MulticalType { get => _multicalType; set => Set(ref _multicalType, value); }
    private string _programNumber;
    public string ProgramNumber { get => _programNumber; set => Set(ref _programNumber, value); }
    private string _configNumber;
    public string ConfigNumber { get => _configNumber; set => Set(ref _configNumber, value); }
    private string _startSerialNumber;
    public string StartSerialNumber { get => _startSerialNumber; set => Set(ref _startSerialNumber, value); }
    private string _customerLabelSerialStart;
    public string CustomerLabelSerialStart { get => _customerLabelSerialStart; set => Set(ref _customerLabelSerialStart, value); }
    private string _sensorTypeNumber;
    public string SensorTypeNumber { get => _sensorTypeNumber; set => Set(ref _sensorTypeNumber, value); }
    private string _sensorResistance;
    public string SensorResistance { get => _sensorResistance; set => Set(ref _sensorResistance, value); }
    private string _module1;
    public string Module1 { get => _module1; set => Set(ref _module1, value); }
    private string _module2;
    public string Module2 { get => _module2; set => Set(ref _module2, value); }
    private bool _isGreenInputActive;
    public bool IsGreenInputActive { get => _isGreenInputActive; set => Set(ref _isGreenInputActive, value); }
    private bool _isBlackInputActive;
    public bool IsBlackInputActive { get => _isBlackInputActive; set => Set(ref _isBlackInputActive, value); }
    private bool _isMC602On;
    public bool IsMC602On { get => _isMC602On; set => Set(ref _isMC602On, value); }
    private bool _isMC602Off;
    public bool IsMC602Off { get => _isMC602Off; set => Set(ref _isMC602Off, value); }
    private string _uFPowerState;
    public string UFPowerState { get => _uFPowerState; set => Set(ref _uFPowerState, value); }
    private string _uFPowerProgress;
    public string UFPowerProgress { get => _uFPowerProgress; set => Set(ref _uFPowerProgress, value); }
    private string _uF44ProgrammingState;
    public string UF44ProgrammingState { get => _uF44ProgrammingState; set => Set(ref _uF44ProgrammingState, value); }
    private string _uF44Activity;
    public string UF44Activity { get => _uF44Activity; set => Set(ref _uF44Activity, value); }
    private string _uF44Progress;
    public string UF44Progress { get => _uF44Progress; set => Set(ref _uF44Progress, value); }
    private string _uF44LockState;
    public string UF44LockState { get => _uF44LockState; set => Set(ref _uF44LockState, value); }
    private string _testTopRevisionStatus;
    public string TestTopRevisionStatus { get => _testTopRevisionStatus; set => Set(ref _testTopRevisionStatus, value); }
    private string _uF44SerialNumber;
    public string UF44SerialNumber { get => _uF44SerialNumber; set => Set(ref _uF44SerialNumber, value); }
    private string _uF44Password;
    public string UF44Password { get => _uF44Password; set => Set(ref _uF44Password, value); }
    private string _serialModeEnabledE2;
    public string SerialModeEnabledE2 { get => _serialModeEnabledE2; set => Set(ref _serialModeEnabledE2, value); }
    private string _passwordWriteEnabledE2;
    public string PasswordWriteEnabledE2 { get => _passwordWriteEnabledE2; set => Set(ref _passwordWriteEnabledE2, value); }
    private string _unlockTimeoutDisabled;
    public string UnlockTimeoutDisabled { get => _unlockTimeoutDisabled; set => Set(ref _unlockTimeoutDisabled, value); }
    private string _unlockTimeout;
    public string UnlockTimeout { get => _unlockTimeout; set => Set(ref _unlockTimeout, value); }
    private bool _hasComments;
    public bool HasComments { get => _hasComments; set => Set(ref _hasComments, value); }
    private string _orderNotes;
    public string OrderNotes { get => _orderNotes; set => Set(ref _orderNotes, value); }
    private ComponentRow _selectedComponent;
    public ComponentRow SelectedComponent { get => _selectedComponent; set => Set(ref _selectedComponent, value); }
    private string _labelTemplate;
    public string LabelTemplate { get => _labelTemplate; set => Set(ref _labelTemplate, value); }
    private string _labelPrinter;
    public string LabelPrinter { get => _labelPrinter; set => Set(ref _labelPrinter, value); }
    private string _labelPreviewState;
    public string LabelPreviewState { get => _labelPreviewState; set => Set(ref _labelPreviewState, value); }
    private string _lastPrintedSerialNumber;
    public string LastPrintedSerialNumber { get => _lastPrintedSerialNumber; set => Set(ref _lastPrintedSerialNumber, value); }
    private string _yearMark;
    public string YearMark { get => _yearMark; set => Set(ref _yearMark, value); }
    private string _sealMarkState;
    public string SealMarkState { get => _sealMarkState; set => Set(ref _sealMarkState, value); }
    private string _sealColourState;
    public string SealColourState { get => _sealColourState; set => Set(ref _sealColourState, value); }
    private SealMarkRow _selectedSealMark;
    public SealMarkRow SelectedSealMark { get => _selectedSealMark; set => Set(ref _selectedSealMark, value); }
    private LabelBarcodeRow _selectedLabelBarcode;
    public LabelBarcodeRow SelectedLabelBarcode { get => _selectedLabelBarcode; set => Set(ref _selectedLabelBarcode, value); }
    private ImageSource _meterLabelImage;
    public ImageSource MeterLabelImage { get => _meterLabelImage; set => Set(ref _meterLabelImage, value); }
    private ImageSource _yearMarkImage;
    public ImageSource YearMarkImage { get => _yearMarkImage; set => Set(ref _yearMarkImage, value); }
    private ProductionMessageRow _selectedError;
    public ProductionMessageRow SelectedError { get => _selectedError; set => Set(ref _selectedError, value); }
    private ProductionCommentRow _selectedComment;
    public ProductionCommentRow SelectedComment { get => _selectedComment; set => Set(ref _selectedComment, value); }
    private string _nextSerialNumber;
    public string NextSerialNumber { get => _nextSerialNumber; set => Set(ref _nextSerialNumber, value); }
    private StepState? _writeUFState;
    public StepState? WriteUFState { get => _writeUFState; set => Set(ref _writeUFState, value); }
    private StepState? _printState;
    public StepState? PrintState { get => _printState; set => Set(ref _printState, value); }
    private StepState? _registrationState;
    public StepState? RegistrationState { get => _registrationState; set => Set(ref _registrationState, value); }
    private double _uFPowerValue;
    public double UFPowerValue { get => _uFPowerValue; set => Set(ref _uFPowerValue, value); }
    private double _uFPowerMaximum;
    public double UFPowerMaximum { get => _uFPowerMaximum; set => Set(ref _uFPowerMaximum, value); }
    private bool _uFPowerIsIndeterminate;
    public bool UFPowerIsIndeterminate { get => _uFPowerIsIndeterminate; set => Set(ref _uFPowerIsIndeterminate, value); }
    private double _uF44ProgrammingValue;
    public double UF44ProgrammingValue { get => _uF44ProgrammingValue; set => Set(ref _uF44ProgrammingValue, value); }
    private double _uF44ProgrammingMaximum;
    public double UF44ProgrammingMaximum { get => _uF44ProgrammingMaximum; set => Set(ref _uF44ProgrammingMaximum, value); }
    private bool _uF44IsIndeterminate;
    public bool UF44IsIndeterminate { get => _uF44IsIndeterminate; set => Set(ref _uF44IsIndeterminate, value); }
    private bool _isUF44PasswordVisible;
    public bool IsUF44PasswordVisible { get => _isUF44PasswordVisible; set => Set(ref _isUF44PasswordVisible, value); }
    private ICommand _scanMeterCommand;
    public ICommand ScanMeterCommand { get => _scanMeterCommand; set => Set(ref _scanMeterCommand, value); }
    private ICommand _loadOrderCommand;
    public ICommand LoadOrderCommand { get => _loadOrderCommand; set => Set(ref _loadOrderCommand, value); }
    private ICommand _readInternalNumberCommand;
    public ICommand ReadInternalNumberCommand { get => _readInternalNumberCommand; set => Set(ref _readInternalNumberCommand, value); }
    private ICommand _startTestCommand;
    public ICommand StartTestCommand { get => _startTestCommand; set => Set(ref _startTestCommand, value); }
    private ICommand _stopTestCommand;
    public ICommand StopTestCommand { get => _stopTestCommand; set => Set(ref _stopTestCommand, value); }
    private ICommand _registerMeterCommand;
    public ICommand RegisterMeterCommand { get => _registerMeterCommand; set => Set(ref _registerMeterCommand, value); }
    private ICommand _readUF44StatusCommand;
    public ICommand ReadUF44StatusCommand { get => _readUF44StatusCommand; set => Set(ref _readUF44StatusCommand, value); }
    private ICommand _restartComPortCommand;
    public ICommand RestartComPortCommand { get => _restartComPortCommand; set => Set(ref _restartComPortCommand, value); }
    private ICommand _reprintLastLabelCommand;
    public ICommand ReprintLastLabelCommand { get => _reprintLastLabelCommand; set => Set(ref _reprintLastLabelCommand, value); }
    private ICommand _scanLabelBarcodesCommand;
    public ICommand ScanLabelBarcodesCommand { get => _scanLabelBarcodesCommand; set => Set(ref _scanLabelBarcodesCommand, value); }

    public BindableCollection<ComponentRow> Components { get; } = new();
    public BindableCollection<SealMarkRow> SealMarks { get; } = new();
    public BindableCollection<LabelBarcodeRow> LabelBarcodes { get; } = new();
    public BindableCollection<ImageSource> SealMarkImages { get; } = new();
    public BindableCollection<ProductionMessageRow> Errors { get; } = new();
    public BindableCollection<ProductionCommentRow> Comments { get; } = new();
    public BindableCollection<LookupOption> SensorTypeOptions { get; } = new();
}
