using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Caliburn.Micro;
using HcwCommon.Core;
using Kamstrup.HC.NewWPF.Utils;
using Kamstrup.HC.NewWPF.ViewModels.Components;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using Kamstrup.HC.NewWPF.ViewModels.Systems;
using Microsoft.Extensions.Logging;
using Action = System.Action;

namespace Kamstrup.HC.NewWPF.ViewModels;

public class MainViewModel : Conductor<WorkspaceViewModelBase>.Collection.OneActive
{
    private readonly IDictionary<string, string> _connectionStrings =
        ConfigurationManager.ConnectionStrings.Cast<ConnectionStringSettings>().ToDictionary(k => k.Name.Split('.').Last(), v => v.ConnectionString);

    private readonly MainMenuItemViewModel _defaultMainMenu;
    private readonly WorkspaceViewModelBase _defaultSubMenu;

    private readonly ILogger<MainViewModel> _logger;
    private readonly UserAuthentication _userAuthentication;
    private readonly SemaphoreSlim _navigationLock = new(1, 1);
    private MainMenuItemViewModel _selectedMainMenu;
    private string _navigationMessage = string.Empty;

    public MainViewModel(BindableCollection<MainMenuItemViewModel> mainMenu, UserAuthentication userAuthentication, StepProgressViewModel stepProgress, ILoggerFactory loggerFactory)
    {
        _logger = loggerFactory.CreateLogger<MainViewModel>();
        _logger.LogDebug("Program starter");

        _userAuthentication = userAuthentication;
        StepProgress = stepProgress;
        _userAuthentication.OperatorStateChanged += OperatorStateChanged;
        _userAuthentication.TechnicianStateChanged += TechnicianStateChanged;
        _userAuthentication.LoginRemainingSecondsChanged += LoginRemainingSecondsChanged;
        _userAuthentication.LoginCancelled += LoginCancelled;

        MainMenu = mainMenu;
        IEnumerable<WorkspaceViewModelBase> workspaces = MainMenu.SelectMany(m => m.SubMenu).OfType<WorkspaceViewModelBase>();
        Items.AddRange(workspaces);

        _defaultMainMenu = MainMenu.First(menu => menu.SubMenu.OfType<WorkspaceViewModelBase>().Any());
        _defaultSubMenu = _defaultMainMenu.SubMenu.OfType<WorkspaceViewModelBase>().First();
    }

    public bool CanOperatorLogin => !_userAuthentication.OperatorLoggedIn;
    public bool CanOperatorLogout => _userAuthentication.OperatorLoggedIn;
    public bool CanOperatorSwitchLogin => _userAuthentication.OperatorLoggedIn;
    public bool Debug => App.Config.Debug;
    public bool LoggedIn => _userAuthentication.LoggedIn;
    public int LoginRemainingSeconds => _userAuthentication.LoginRemainingSeconds;
    public BindableCollection<MainMenuItemViewModel> MainMenu { get; }
    public string OperatorName => _userAuthentication.OperatorName;
    public string OperatorDisplayName => _userAuthentication.OperatorLoggedIn ? OperatorName : "Ingen operatør logget ind";
    public StepProgressViewModel StepProgress { get; }
    public string ProgramTitle => $"{Versioning.GetProgramTitle(true)} - {_userAuthentication.OperatorName}";

    public MainMenuItemViewModel SelectedMainMenu
    {
        get => _selectedMainMenu;
        set
        {
            if (value != null && _selectedMainMenu != value)
                _ = NavigateSafelyAsync(() => SelectMainMenuAsync(value));
        }
    }

    public IMenuItem SelectedSubMenu
    {
        get => SelectedMainMenu?.SelectedSubMenu;
        set
        {
            if (value == null) return;

            if (value is CommandBase command)
            {
                _ = NavigateSafelyAsync(() =>
                {
                    ExecuteCommand(command);
                    return Task.CompletedTask;
                });
                return;
            }

            if (value is WorkspaceViewModelBase workspace)
            {
                if (SelectedMainMenu == null || SelectedMainMenu.SelectedSubMenu == workspace) return;

                MainMenuItemViewModel menu = SelectedMainMenu;
                _ = NavigateSafelyAsync(() => SelectWorkspaceAsync(menu, workspace));
            }
        }
    }

    public BindableCollection<IMenuItem> SubMenu => SelectedMainMenu == null ? new BindableCollection<IMenuItem>() : SelectedMainMenu.SubMenu;
    public bool TechnicianLoggedIn => _userAuthentication.TechnicianLoggedIn;
    public string TechnicianName => _userAuthentication.TechnicianName;
    public string TechnicianDisplayName => _userAuthentication.TechnicianLoggedIn ? TechnicianName : "Ingen tekniker logget ind";
    public bool UsingTestDatabase => _connectionStrings.Values.Any(connection => connection.ToUpper().Contains("TEST") || connection.ToUpper().Contains("HEAT"));

    public string NavigationMessage
    {
        get => _navigationMessage;
        private set
        {
            if (Set(ref _navigationMessage, value)) NotifyOfPropertyChange(nameof(HasNavigationMessage));
        }
    }

    public bool HasNavigationMessage => !string.IsNullOrWhiteSpace(NavigationMessage);

    public Task HomeAsync() => NavigateSafelyAsync(() => SelectWorkspaceAsync(_defaultMainMenu, _defaultSubMenu));

    public void OperatorLogin()
    {
        _userAuthentication.OperatorLogin();
    }

    public void OperatorLogout()
    {
        _userAuthentication.OperatorLogout();
    }

    public void OperatorSwitchLogin()
    {
        if (_userAuthentication.OperatorLoggedIn) OperatorLogout();
        _userAuthentication.OperatorLogin();
    }

    public void TechnicianLogin()
    {
        ExecuteCommand<TechnicianLoginCommand>();
    }

    public void TechnicianLogout()
    {
        ExecuteCommand<TechnicianLogoutCommand>();
    }

    public void UserLogin()
    {
        OperatorLogin();
    }

    public void UserLogout()
    {
        if (CanOperatorLogout)
            OperatorLogout();
    }

    public void UserSwitchLogin()
    {
        OperatorSwitchLogin();
    }

    public void ViewClosing(CancelEventArgs e)
    {
        try
        {
            _logger?.LogInformation($"Program lukker ned, sidste bruger {_userAuthentication.LatestOperatorUser}");
            _logger?.LogInformation("Program afsluttes");
        }
        catch (Exception ex)
        {
            _logger?.LogWarning(ex, $"Under nedlukning opstod der en fejl, sidste bruger{_userAuthentication.LatestOperatorUser}");
        }
    }

    protected override async Task OnInitializeAsync(CancellationToken cancellationToken)
    {
        await base.OnInitializeAsync(cancellationToken);
        await HomeAsync();
        //        _userAuthentication.StartLoginLoop(); todo
    }

    private void ExecuteCommand(CommandBase command)
    {
        if (command.CanExecute()) command.Execute();
    }

    private void ExecuteCommand<T>() where T : CommandBase
    {
        CommandBase command = MainMenu.SelectMany(mm => mm.SubMenu).OfType<T>().FirstOrDefault();
        if (command != null && command.CanExecute()) command.Execute();
    }

    private void LoginCancelled(object sender, EventArgs e)
    {
        Application.Current.Dispatcher.BeginInvoke(new Action(() => TryCloseAsync()));
    }

    private void LoginRemainingSecondsChanged(object sender, EventArgs e)
    {
        NotifyOfPropertyChange(() => LoginRemainingSeconds);
    }

    private void OperatorStateChanged(object sender, EventArgs e)
    {
        NotifyOfPropertyChange(() => OperatorName);
        NotifyOfPropertyChange(() => OperatorDisplayName);
        NotifyOfPropertyChange(() => CanOperatorLogin);
        NotifyOfPropertyChange(() => CanOperatorLogout);
        NotifyOfPropertyChange(() => CanOperatorSwitchLogin);
        NotifyOfPropertyChange(() => LoggedIn);
        NotifyOfPropertyChange(() => ProgramTitle);
    }

    private async Task SelectMainMenuAsync(MainMenuItemViewModel menu)
    {
        if (menu == null) return;

        WorkspaceViewModelBase workspace = menu.SelectedSubMenu as WorkspaceViewModelBase
            ?? menu.SubMenu.OfType<WorkspaceViewModelBase>().FirstOrDefault();
        if (workspace != null) await SelectWorkspaceAsync(menu, workspace);
    }

    private async Task SelectWorkspaceAsync(MainMenuItemViewModel menu, WorkspaceViewModelBase workspace)
    {
        // Capture the requested menu so a queued submenu selection cannot be
        // assigned to a different main menu while another transition is running.
        if (menu == null || workspace == null || !MainMenu.Contains(menu) || !menu.SubMenu.Contains(workspace))
            return;

        if (ActiveItem != null && ActiveItem != workspace)
        {
            bool canClose = await ActiveItem.CanCloseAsync();
            if (!canClose) return;
        }

        // Commit both selections only after the target screen has activated.
        // Home uses this same transition and therefore has only one close guard.
        await ActivateItemAsync(workspace);
        _selectedMainMenu = menu;
        menu.SelectedSubMenu = workspace;
    }

    private async Task NavigateSafelyAsync(Func<Task> navigation)
    {
        await _navigationLock.WaitAsync();
        try
        {
            NavigationMessage = string.Empty;
            await navigation();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Kunne ikke gennemføre navigation eller menukommando");
            NavigationMessage = "Siden kunne ikke åbnes. Se programloggen for detaljer.";
        }
        finally
        {
            // Reassert the accepted source selection even when the screen's
            // close guard refuses navigation or a menu command was executed.
            NotifyOfPropertyChange(() => SelectedMainMenu);
            NotifyOfPropertyChange(() => SubMenu);
            NotifyOfPropertyChange(() => SelectedSubMenu);
            _navigationLock.Release();
        }
    }

    private void TechnicianStateChanged(object sender, EventArgs e)
    {
        NotifyOfPropertyChange(() => TechnicianName);
        NotifyOfPropertyChange(() => TechnicianDisplayName);
        NotifyOfPropertyChange(() => TechnicianLoggedIn);
        NotifyOfPropertyChange(() => LoggedIn);
    }
}
