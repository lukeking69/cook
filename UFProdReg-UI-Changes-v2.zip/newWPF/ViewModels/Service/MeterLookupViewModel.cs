using Kamstrup.HC.NewWPF.Entities;
using Caliburn.Micro;
using System;
using System.Windows.Input;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Service;

public sealed class MeterLookupViewModel : WorkspaceViewModelBase
{
    public MeterLookupViewModel()
    {
        DisplayName = "Måleropslag";
        Icon = PackIconKind.Magnify;
    }

    private string _statusMessage;
    public string StatusMessage
    {
        get => _statusMessage;
        set => Set(ref _statusMessage, value);
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex
    {
        get => _selectedTabIndex;
        set => Set(ref _selectedTabIndex, value);
    }

    private string _searchSerialNumber;
    public string SearchSerialNumber
    {
        get => _searchSerialNumber;
        set => Set(ref _searchSerialNumber, value);
    }

    private string _searchInternalNumber;
    public string SearchInternalNumber
    {
        get => _searchInternalNumber;
        set => Set(ref _searchInternalNumber, value);
    }

    private string _selectedFamily;
    public string SelectedFamily
    {
        get => _selectedFamily;
        set => Set(ref _selectedFamily, value);
    }

    private ICommand _searchCommand;
    public ICommand SearchCommand
    {
        get => _searchCommand;
        set => Set(ref _searchCommand, value);
    }

    private ICommand _searchInternalCommand;
    public ICommand SearchInternalCommand
    {
        get => _searchInternalCommand;
        set => Set(ref _searchInternalCommand, value);
    }

    private ICommand _clearSearchCommand;
    public ICommand ClearSearchCommand
    {
        get => _clearSearchCommand;
        set => Set(ref _clearSearchCommand, value);
    }

    private string _serialUFx4InternalNumber;
    public string SerialUFx4InternalNumber
    {
        get => _serialUFx4InternalNumber;
        set => Set(ref _serialUFx4InternalNumber, value);
    }

    private string _serialUFx4OrderNumber;
    public string SerialUFx4OrderNumber
    {
        get => _serialUFx4OrderNumber;
        set => Set(ref _serialUFx4OrderNumber, value);
    }

    private string _serialUFx4MeterSerialNumber;
    public string SerialUFx4MeterSerialNumber
    {
        get => _serialUFx4MeterSerialNumber;
        set => Set(ref _serialUFx4MeterSerialNumber, value);
    }

    private string _serialUFx4UFSerialNumber;
    public string SerialUFx4UFSerialNumber
    {
        get => _serialUFx4UFSerialNumber;
        set => Set(ref _serialUFx4UFSerialNumber, value);
    }

    private string _serialUFx4TypeNumber;
    public string SerialUFx4TypeNumber
    {
        get => _serialUFx4TypeNumber;
        set => Set(ref _serialUFx4TypeNumber, value);
    }

    private string _serialUFx4Number59xx;
    public string SerialUFx4Number59xx
    {
        get => _serialUFx4Number59xx;
        set => Set(ref _serialUFx4Number59xx, value);
    }

    private string _serialUFx4MeterConfiguration;
    public string SerialUFx4MeterConfiguration
    {
        get => _serialUFx4MeterConfiguration;
        set => Set(ref _serialUFx4MeterConfiguration, value);
    }

    private string _serialUFx4CustomerNumber;
    public string SerialUFx4CustomerNumber
    {
        get => _serialUFx4CustomerNumber;
        set => Set(ref _serialUFx4CustomerNumber, value);
    }

    private DateTime? _serialUFx4RegistrationDate;
    public DateTime? SerialUFx4RegistrationDate
    {
        get => _serialUFx4RegistrationDate;
        set => Set(ref _serialUFx4RegistrationDate, value);
    }

    private string _serialUFx4RegisteredBy;
    public string SerialUFx4RegisteredBy
    {
        get => _serialUFx4RegisteredBy;
        set => Set(ref _serialUFx4RegisteredBy, value);
    }

    private string _serialUFx4TestType;
    public string SerialUFx4TestType
    {
        get => _serialUFx4TestType;
        set => Set(ref _serialUFx4TestType, value);
    }

    private DateTime? _serialUFx4FinalTestDate;
    public DateTime? SerialUFx4FinalTestDate
    {
        get => _serialUFx4FinalTestDate;
        set => Set(ref _serialUFx4FinalTestDate, value);
    }

    private string _serialUFx4FinalTestOperator;
    public string SerialUFx4FinalTestOperator
    {
        get => _serialUFx4FinalTestOperator;
        set => Set(ref _serialUFx4FinalTestOperator, value);
    }

    private string _serialUFx4ConfigurationId;
    public string SerialUFx4ConfigurationId
    {
        get => _serialUFx4ConfigurationId;
        set => Set(ref _serialUFx4ConfigurationId, value);
    }

    private int? _serialUFx4StorageDays;
    public int? SerialUFx4StorageDays
    {
        get => _serialUFx4StorageDays;
        set => Set(ref _serialUFx4StorageDays, value);
    }

    private string _serialUFx4LabApproval;
    public string SerialUFx4LabApproval
    {
        get => _serialUFx4LabApproval;
        set => Set(ref _serialUFx4LabApproval, value);
    }

    private string _serialUFx4SoftwareRevision;
    public string SerialUFx4SoftwareRevision
    {
        get => _serialUFx4SoftwareRevision;
        set => Set(ref _serialUFx4SoftwareRevision, value);
    }

    private string _serialUFx4RegistrationStatus;
    public string SerialUFx4RegistrationStatus
    {
        get => _serialUFx4RegistrationStatus;
        set => Set(ref _serialUFx4RegistrationStatus, value);
    }

    private string _serialUFx5InternalNumber;
    public string SerialUFx5InternalNumber
    {
        get => _serialUFx5InternalNumber;
        set => Set(ref _serialUFx5InternalNumber, value);
    }

    private string _serialUFx5OrderNumber;
    public string SerialUFx5OrderNumber
    {
        get => _serialUFx5OrderNumber;
        set => Set(ref _serialUFx5OrderNumber, value);
    }

    private string _serialUFx5UFSerialNumber;
    public string SerialUFx5UFSerialNumber
    {
        get => _serialUFx5UFSerialNumber;
        set => Set(ref _serialUFx5UFSerialNumber, value);
    }

    private string _serialUFx5UFExternalSerialNumber;
    public string SerialUFx5UFExternalSerialNumber
    {
        get => _serialUFx5UFExternalSerialNumber;
        set => Set(ref _serialUFx5UFExternalSerialNumber, value);
    }

    private string _serialUFx5TypeNumber;
    public string SerialUFx5TypeNumber
    {
        get => _serialUFx5TypeNumber;
        set => Set(ref _serialUFx5TypeNumber, value);
    }

    private string _serialUFx5CustomerSerialNumber;
    public string SerialUFx5CustomerSerialNumber
    {
        get => _serialUFx5CustomerSerialNumber;
        set => Set(ref _serialUFx5CustomerSerialNumber, value);
    }

    private string _serialUFx5MeterSerialNumber;
    public string SerialUFx5MeterSerialNumber
    {
        get => _serialUFx5MeterSerialNumber;
        set => Set(ref _serialUFx5MeterSerialNumber, value);
    }

    private string _serialUFx5Number59xx;
    public string SerialUFx5Number59xx
    {
        get => _serialUFx5Number59xx;
        set => Set(ref _serialUFx5Number59xx, value);
    }

    private string _serialUFx5MeterConfiguration;
    public string SerialUFx5MeterConfiguration
    {
        get => _serialUFx5MeterConfiguration;
        set => Set(ref _serialUFx5MeterConfiguration, value);
    }

    private DateTime? _serialUFx5RegistrationDate;
    public DateTime? SerialUFx5RegistrationDate
    {
        get => _serialUFx5RegistrationDate;
        set => Set(ref _serialUFx5RegistrationDate, value);
    }

    private string _serialUFx5RegisteredBy;
    public string SerialUFx5RegisteredBy
    {
        get => _serialUFx5RegisteredBy;
        set => Set(ref _serialUFx5RegisteredBy, value);
    }

    private DateTime? _serialUFx5FinalTestDate;
    public DateTime? SerialUFx5FinalTestDate
    {
        get => _serialUFx5FinalTestDate;
        set => Set(ref _serialUFx5FinalTestDate, value);
    }

    private string _serialUFx5FinalTestOperator;
    public string SerialUFx5FinalTestOperator
    {
        get => _serialUFx5FinalTestOperator;
        set => Set(ref _serialUFx5FinalTestOperator, value);
    }

    private string _serialUFx5ConfigurationId;
    public string SerialUFx5ConfigurationId
    {
        get => _serialUFx5ConfigurationId;
        set => Set(ref _serialUFx5ConfigurationId, value);
    }

    private int? _serialUFx5StorageDays;
    public int? SerialUFx5StorageDays
    {
        get => _serialUFx5StorageDays;
        set => Set(ref _serialUFx5StorageDays, value);
    }

    private string _serialUFx5LabApproval;
    public string SerialUFx5LabApproval
    {
        get => _serialUFx5LabApproval;
        set => Set(ref _serialUFx5LabApproval, value);
    }

    private string _serialUFx5SoftwareRevision;
    public string SerialUFx5SoftwareRevision
    {
        get => _serialUFx5SoftwareRevision;
        set => Set(ref _serialUFx5SoftwareRevision, value);
    }

    private string _serialUFx5SoftwareCrc;
    public string SerialUFx5SoftwareCrc
    {
        get => _serialUFx5SoftwareCrc;
        set => Set(ref _serialUFx5SoftwareCrc, value);
    }

    private string _serialUFx5RegistrationStatus;
    public string SerialUFx5RegistrationStatus
    {
        get => _serialUFx5RegistrationStatus;
        set => Set(ref _serialUFx5RegistrationStatus, value);
    }

    private string _cablePort;
    public string CablePort
    {
        get => _cablePort;
        set => Set(ref _cablePort, value);
    }

    private ICommand _readCableCommand;
    public ICommand ReadCableCommand
    {
        get => _readCableCommand;
        set => Set(ref _readCableCommand, value);
    }

    private string _cableUFx4InternalNumber;
    public string CableUFx4InternalNumber
    {
        get => _cableUFx4InternalNumber;
        set => Set(ref _cableUFx4InternalNumber, value);
    }

    private string _cableUFx4OrderNumber;
    public string CableUFx4OrderNumber
    {
        get => _cableUFx4OrderNumber;
        set => Set(ref _cableUFx4OrderNumber, value);
    }

    private string _cableUFx4MeterSerialNumber;
    public string CableUFx4MeterSerialNumber
    {
        get => _cableUFx4MeterSerialNumber;
        set => Set(ref _cableUFx4MeterSerialNumber, value);
    }

    private string _cableUFx4UFSerialNumber;
    public string CableUFx4UFSerialNumber
    {
        get => _cableUFx4UFSerialNumber;
        set => Set(ref _cableUFx4UFSerialNumber, value);
    }

    private string _cableUFx4TypeNumber;
    public string CableUFx4TypeNumber
    {
        get => _cableUFx4TypeNumber;
        set => Set(ref _cableUFx4TypeNumber, value);
    }

    private string _cableUFx4Number59xx;
    public string CableUFx4Number59xx
    {
        get => _cableUFx4Number59xx;
        set => Set(ref _cableUFx4Number59xx, value);
    }

    private string _cableUFx4MeterConfiguration;
    public string CableUFx4MeterConfiguration
    {
        get => _cableUFx4MeterConfiguration;
        set => Set(ref _cableUFx4MeterConfiguration, value);
    }

    private string _cableUFx4CustomerNumber;
    public string CableUFx4CustomerNumber
    {
        get => _cableUFx4CustomerNumber;
        set => Set(ref _cableUFx4CustomerNumber, value);
    }

    private DateTime? _cableUFx4RegistrationDate;
    public DateTime? CableUFx4RegistrationDate
    {
        get => _cableUFx4RegistrationDate;
        set => Set(ref _cableUFx4RegistrationDate, value);
    }

    private string _cableUFx4RegisteredBy;
    public string CableUFx4RegisteredBy
    {
        get => _cableUFx4RegisteredBy;
        set => Set(ref _cableUFx4RegisteredBy, value);
    }

    private string _cableUFx4TestType;
    public string CableUFx4TestType
    {
        get => _cableUFx4TestType;
        set => Set(ref _cableUFx4TestType, value);
    }

    private DateTime? _cableUFx4FinalTestDate;
    public DateTime? CableUFx4FinalTestDate
    {
        get => _cableUFx4FinalTestDate;
        set => Set(ref _cableUFx4FinalTestDate, value);
    }

    private string _cableUFx4FinalTestOperator;
    public string CableUFx4FinalTestOperator
    {
        get => _cableUFx4FinalTestOperator;
        set => Set(ref _cableUFx4FinalTestOperator, value);
    }

    private string _cableUFx4ConfigurationId;
    public string CableUFx4ConfigurationId
    {
        get => _cableUFx4ConfigurationId;
        set => Set(ref _cableUFx4ConfigurationId, value);
    }

    private int? _cableUFx4StorageDays;
    public int? CableUFx4StorageDays
    {
        get => _cableUFx4StorageDays;
        set => Set(ref _cableUFx4StorageDays, value);
    }

    private string _cableUFx4LabApproval;
    public string CableUFx4LabApproval
    {
        get => _cableUFx4LabApproval;
        set => Set(ref _cableUFx4LabApproval, value);
    }

    private string _cableUFx4SoftwareRevision;
    public string CableUFx4SoftwareRevision
    {
        get => _cableUFx4SoftwareRevision;
        set => Set(ref _cableUFx4SoftwareRevision, value);
    }

    private string _cableUFx4RegistrationStatus;
    public string CableUFx4RegistrationStatus
    {
        get => _cableUFx4RegistrationStatus;
        set => Set(ref _cableUFx4RegistrationStatus, value);
    }

    private ICommand _readFixtureCommand;
    public ICommand ReadFixtureCommand
    {
        get => _readFixtureCommand;
        set => Set(ref _readFixtureCommand, value);
    }

    private ICommand _readUF44LockCommand;
    public ICommand ReadUF44LockCommand
    {
        get => _readUF44LockCommand;
        set => Set(ref _readUF44LockCommand, value);
    }

    private string _fixtureUFx4InternalNumber;
    public string FixtureUFx4InternalNumber
    {
        get => _fixtureUFx4InternalNumber;
        set => Set(ref _fixtureUFx4InternalNumber, value);
    }

    private string _fixtureUFx4OrderNumber;
    public string FixtureUFx4OrderNumber
    {
        get => _fixtureUFx4OrderNumber;
        set => Set(ref _fixtureUFx4OrderNumber, value);
    }

    private string _fixtureUFx4MeterSerialNumber;
    public string FixtureUFx4MeterSerialNumber
    {
        get => _fixtureUFx4MeterSerialNumber;
        set => Set(ref _fixtureUFx4MeterSerialNumber, value);
    }

    private string _fixtureUFx4UFSerialNumber;
    public string FixtureUFx4UFSerialNumber
    {
        get => _fixtureUFx4UFSerialNumber;
        set => Set(ref _fixtureUFx4UFSerialNumber, value);
    }

    private string _fixtureUFx4TypeNumber;
    public string FixtureUFx4TypeNumber
    {
        get => _fixtureUFx4TypeNumber;
        set => Set(ref _fixtureUFx4TypeNumber, value);
    }

    private string _fixtureUFx4Number59xx;
    public string FixtureUFx4Number59xx
    {
        get => _fixtureUFx4Number59xx;
        set => Set(ref _fixtureUFx4Number59xx, value);
    }

    private string _fixtureUFx4MeterConfiguration;
    public string FixtureUFx4MeterConfiguration
    {
        get => _fixtureUFx4MeterConfiguration;
        set => Set(ref _fixtureUFx4MeterConfiguration, value);
    }

    private string _fixtureUFx4CustomerNumber;
    public string FixtureUFx4CustomerNumber
    {
        get => _fixtureUFx4CustomerNumber;
        set => Set(ref _fixtureUFx4CustomerNumber, value);
    }

    private DateTime? _fixtureUFx4RegistrationDate;
    public DateTime? FixtureUFx4RegistrationDate
    {
        get => _fixtureUFx4RegistrationDate;
        set => Set(ref _fixtureUFx4RegistrationDate, value);
    }

    private string _fixtureUFx4RegisteredBy;
    public string FixtureUFx4RegisteredBy
    {
        get => _fixtureUFx4RegisteredBy;
        set => Set(ref _fixtureUFx4RegisteredBy, value);
    }

    private string _fixtureUFx4TestType;
    public string FixtureUFx4TestType
    {
        get => _fixtureUFx4TestType;
        set => Set(ref _fixtureUFx4TestType, value);
    }

    private DateTime? _fixtureUFx4FinalTestDate;
    public DateTime? FixtureUFx4FinalTestDate
    {
        get => _fixtureUFx4FinalTestDate;
        set => Set(ref _fixtureUFx4FinalTestDate, value);
    }

    private string _fixtureUFx4FinalTestOperator;
    public string FixtureUFx4FinalTestOperator
    {
        get => _fixtureUFx4FinalTestOperator;
        set => Set(ref _fixtureUFx4FinalTestOperator, value);
    }

    private string _fixtureUFx4ConfigurationId;
    public string FixtureUFx4ConfigurationId
    {
        get => _fixtureUFx4ConfigurationId;
        set => Set(ref _fixtureUFx4ConfigurationId, value);
    }

    private int? _fixtureUFx4StorageDays;
    public int? FixtureUFx4StorageDays
    {
        get => _fixtureUFx4StorageDays;
        set => Set(ref _fixtureUFx4StorageDays, value);
    }

    private string _fixtureUFx4LabApproval;
    public string FixtureUFx4LabApproval
    {
        get => _fixtureUFx4LabApproval;
        set => Set(ref _fixtureUFx4LabApproval, value);
    }

    private string _fixtureUFx4SoftwareRevision;
    public string FixtureUFx4SoftwareRevision
    {
        get => _fixtureUFx4SoftwareRevision;
        set => Set(ref _fixtureUFx4SoftwareRevision, value);
    }

    private string _fixtureUFx4RegistrationStatus;
    public string FixtureUFx4RegistrationStatus
    {
        get => _fixtureUFx4RegistrationStatus;
        set => Set(ref _fixtureUFx4RegistrationStatus, value);
    }

    private string _fixtureUF44SerialNumber;
    public string FixtureUF44SerialNumber
    {
        get => _fixtureUF44SerialNumber;
        set => Set(ref _fixtureUF44SerialNumber, value);
    }

    private string _fixtureUF44LockStatus;
    public string FixtureUF44LockStatus
    {
        get => _fixtureUF44LockStatus;
        set => Set(ref _fixtureUF44LockStatus, value);
    }

    private string _fixtureUF44Status;
    public string FixtureUF44Status
    {
        get => _fixtureUF44Status;
        set => Set(ref _fixtureUF44Status, value);
    }

    private string _fixtureUF44TestTopRevision;
    public string FixtureUF44TestTopRevision
    {
        get => _fixtureUF44TestTopRevision;
        set => Set(ref _fixtureUF44TestTopRevision, value);
    }

    private string _fixtureUF44UnlockTimeoutDisabled;
    public string FixtureUF44UnlockTimeoutDisabled
    {
        get => _fixtureUF44UnlockTimeoutDisabled;
        set => Set(ref _fixtureUF44UnlockTimeoutDisabled, value);
    }

    private string _fixtureUF44PasswordWriteEnabledE2;
    public string FixtureUF44PasswordWriteEnabledE2
    {
        get => _fixtureUF44PasswordWriteEnabledE2;
        set => Set(ref _fixtureUF44PasswordWriteEnabledE2, value);
    }

    private string _fixtureUF44SerialModeEnabledE2;
    public string FixtureUF44SerialModeEnabledE2
    {
        get => _fixtureUF44SerialModeEnabledE2;
        set => Set(ref _fixtureUF44SerialModeEnabledE2, value);
    }

    private string _fixtureUF44Timeout;
    public string FixtureUF44Timeout
    {
        get => _fixtureUF44Timeout;
        set => Set(ref _fixtureUF44Timeout, value);
    }

    private string _fixtureUF44PasswordDisplay;
    public string FixtureUF44PasswordDisplay
    {
        get => _fixtureUF44PasswordDisplay;
        set => Set(ref _fixtureUF44PasswordDisplay, value);
    }

    private ICommand _readUFx5Command;
    public ICommand ReadUFx5Command
    {
        get => _readUFx5Command;
        set => Set(ref _readUFx5Command, value);
    }

    private string _connectedUFx5SerialNumber;
    public string ConnectedUFx5SerialNumber
    {
        get => _connectedUFx5SerialNumber;
        set => Set(ref _connectedUFx5SerialNumber, value);
    }

    private string _connectedUFx5MeterPartNumber;
    public string ConnectedUFx5MeterPartNumber
    {
        get => _connectedUFx5MeterPartNumber;
        set => Set(ref _connectedUFx5MeterPartNumber, value);
    }

    private string _connectedUFx5MeterCustomerId;
    public string ConnectedUFx5MeterCustomerId
    {
        get => _connectedUFx5MeterCustomerId;
        set => Set(ref _connectedUFx5MeterCustomerId, value);
    }

    private string _connectedUFx5MeterInternalId;
    public string ConnectedUFx5MeterInternalId
    {
        get => _connectedUFx5MeterInternalId;
        set => Set(ref _connectedUFx5MeterInternalId, value);
    }

    private string _connectedUFx5InternalNumber;
    public string ConnectedUFx5InternalNumber
    {
        get => _connectedUFx5InternalNumber;
        set => Set(ref _connectedUFx5InternalNumber, value);
    }

    private string _connectedUFx5ExternalSerialNumber;
    public string ConnectedUFx5ExternalSerialNumber
    {
        get => _connectedUFx5ExternalSerialNumber;
        set => Set(ref _connectedUFx5ExternalSerialNumber, value);
    }

    private string _connectedUFx5SoftwareRevision;
    public string ConnectedUFx5SoftwareRevision
    {
        get => _connectedUFx5SoftwareRevision;
        set => Set(ref _connectedUFx5SoftwareRevision, value);
    }

    private string _connectedUFx5SoftwareCrc;
    public string ConnectedUFx5SoftwareCrc
    {
        get => _connectedUFx5SoftwareCrc;
        set => Set(ref _connectedUFx5SoftwareCrc, value);
    }

    private string _connectedUFx5ProgrammingVerification;
    public string ConnectedUFx5ProgrammingVerification
    {
        get => _connectedUFx5ProgrammingVerification;
        set => Set(ref _connectedUFx5ProgrammingVerification, value);
    }

    private string _connectedUFx5WarmForwardVerification;
    public string ConnectedUFx5WarmForwardVerification
    {
        get => _connectedUFx5WarmForwardVerification;
        set => Set(ref _connectedUFx5WarmForwardVerification, value);
    }

    private string _connectedUFx5WarmReverseVerification;
    public string ConnectedUFx5WarmReverseVerification
    {
        get => _connectedUFx5WarmReverseVerification;
        set => Set(ref _connectedUFx5WarmReverseVerification, value);
    }

    private string _connectedUFx5ColdForwardVerification;
    public string ConnectedUFx5ColdForwardVerification
    {
        get => _connectedUFx5ColdForwardVerification;
        set => Set(ref _connectedUFx5ColdForwardVerification, value);
    }

    private string _connectedUFx5ExternalDesiredMeterType;
    public string ConnectedUFx5ExternalDesiredMeterType
    {
        get => _connectedUFx5ExternalDesiredMeterType;
        set => Set(ref _connectedUFx5ExternalDesiredMeterType, value);
    }

    private string _connectedUFx5DatabaseInternalNumber;
    public string ConnectedUFx5DatabaseInternalNumber
    {
        get => _connectedUFx5DatabaseInternalNumber;
        set => Set(ref _connectedUFx5DatabaseInternalNumber, value);
    }

    private string _connectedUFx5DatabaseOrderNumber;
    public string ConnectedUFx5DatabaseOrderNumber
    {
        get => _connectedUFx5DatabaseOrderNumber;
        set => Set(ref _connectedUFx5DatabaseOrderNumber, value);
    }

    private string _connectedUFx5DatabaseUFSerialNumber;
    public string ConnectedUFx5DatabaseUFSerialNumber
    {
        get => _connectedUFx5DatabaseUFSerialNumber;
        set => Set(ref _connectedUFx5DatabaseUFSerialNumber, value);
    }

    private string _connectedUFx5DatabaseUFExternalSerialNumber;
    public string ConnectedUFx5DatabaseUFExternalSerialNumber
    {
        get => _connectedUFx5DatabaseUFExternalSerialNumber;
        set => Set(ref _connectedUFx5DatabaseUFExternalSerialNumber, value);
    }

    private string _connectedUFx5DatabaseTypeNumber;
    public string ConnectedUFx5DatabaseTypeNumber
    {
        get => _connectedUFx5DatabaseTypeNumber;
        set => Set(ref _connectedUFx5DatabaseTypeNumber, value);
    }

    private string _connectedUFx5DatabaseCustomerSerialNumber;
    public string ConnectedUFx5DatabaseCustomerSerialNumber
    {
        get => _connectedUFx5DatabaseCustomerSerialNumber;
        set => Set(ref _connectedUFx5DatabaseCustomerSerialNumber, value);
    }

    private string _connectedUFx5DatabaseMeterSerialNumber;
    public string ConnectedUFx5DatabaseMeterSerialNumber
    {
        get => _connectedUFx5DatabaseMeterSerialNumber;
        set => Set(ref _connectedUFx5DatabaseMeterSerialNumber, value);
    }

    private string _connectedUFx5DatabaseNumber59xx;
    public string ConnectedUFx5DatabaseNumber59xx
    {
        get => _connectedUFx5DatabaseNumber59xx;
        set => Set(ref _connectedUFx5DatabaseNumber59xx, value);
    }

    private string _connectedUFx5DatabaseMeterConfiguration;
    public string ConnectedUFx5DatabaseMeterConfiguration
    {
        get => _connectedUFx5DatabaseMeterConfiguration;
        set => Set(ref _connectedUFx5DatabaseMeterConfiguration, value);
    }

    private DateTime? _connectedUFx5DatabaseRegistrationDate;
    public DateTime? ConnectedUFx5DatabaseRegistrationDate
    {
        get => _connectedUFx5DatabaseRegistrationDate;
        set => Set(ref _connectedUFx5DatabaseRegistrationDate, value);
    }

    private string _connectedUFx5DatabaseRegisteredBy;
    public string ConnectedUFx5DatabaseRegisteredBy
    {
        get => _connectedUFx5DatabaseRegisteredBy;
        set => Set(ref _connectedUFx5DatabaseRegisteredBy, value);
    }

    private DateTime? _connectedUFx5DatabaseFinalTestDate;
    public DateTime? ConnectedUFx5DatabaseFinalTestDate
    {
        get => _connectedUFx5DatabaseFinalTestDate;
        set => Set(ref _connectedUFx5DatabaseFinalTestDate, value);
    }

    private string _connectedUFx5DatabaseFinalTestOperator;
    public string ConnectedUFx5DatabaseFinalTestOperator
    {
        get => _connectedUFx5DatabaseFinalTestOperator;
        set => Set(ref _connectedUFx5DatabaseFinalTestOperator, value);
    }

    private string _connectedUFx5DatabaseConfigurationId;
    public string ConnectedUFx5DatabaseConfigurationId
    {
        get => _connectedUFx5DatabaseConfigurationId;
        set => Set(ref _connectedUFx5DatabaseConfigurationId, value);
    }

    private int? _connectedUFx5DatabaseStorageDays;
    public int? ConnectedUFx5DatabaseStorageDays
    {
        get => _connectedUFx5DatabaseStorageDays;
        set => Set(ref _connectedUFx5DatabaseStorageDays, value);
    }

    private string _connectedUFx5DatabaseLabApproval;
    public string ConnectedUFx5DatabaseLabApproval
    {
        get => _connectedUFx5DatabaseLabApproval;
        set => Set(ref _connectedUFx5DatabaseLabApproval, value);
    }

    private string _connectedUFx5DatabaseSoftwareRevision;
    public string ConnectedUFx5DatabaseSoftwareRevision
    {
        get => _connectedUFx5DatabaseSoftwareRevision;
        set => Set(ref _connectedUFx5DatabaseSoftwareRevision, value);
    }

    private string _connectedUFx5DatabaseSoftwareCrc;
    public string ConnectedUFx5DatabaseSoftwareCrc
    {
        get => _connectedUFx5DatabaseSoftwareCrc;
        set => Set(ref _connectedUFx5DatabaseSoftwareCrc, value);
    }

    private string _connectedUFx5DatabaseRegistrationStatus;
    public string ConnectedUFx5DatabaseRegistrationStatus
    {
        get => _connectedUFx5DatabaseRegistrationStatus;
        set => Set(ref _connectedUFx5DatabaseRegistrationStatus, value);
    }

    private ICommand _closeCommand;
    public ICommand CloseCommand
    {
        get => _closeCommand;
        set => Set(ref _closeCommand, value);
    }

    public BindableCollection<LookupOption> FamilyOptions { get; } = new();


    private StatusIndicatorState _cableUFx4RegistrationStatusIndicatorState;
    public StatusIndicatorState CableUFx4RegistrationStatusIndicatorState { get => _cableUFx4RegistrationStatusIndicatorState; set => Set(ref _cableUFx4RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _connectedUFx5DatabaseRegistrationStatusIndicatorState;
    public StatusIndicatorState ConnectedUFx5DatabaseRegistrationStatusIndicatorState { get => _connectedUFx5DatabaseRegistrationStatusIndicatorState; set => Set(ref _connectedUFx5DatabaseRegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _fixtureUF44LockStatusIndicatorState;
    public StatusIndicatorState FixtureUF44LockStatusIndicatorState { get => _fixtureUF44LockStatusIndicatorState; set => Set(ref _fixtureUF44LockStatusIndicatorState, value); }

    private StatusIndicatorState _fixtureUF44StatusIndicatorState;
    public StatusIndicatorState FixtureUF44StatusIndicatorState { get => _fixtureUF44StatusIndicatorState; set => Set(ref _fixtureUF44StatusIndicatorState, value); }

    private StatusIndicatorState _fixtureUFx4RegistrationStatusIndicatorState;
    public StatusIndicatorState FixtureUFx4RegistrationStatusIndicatorState { get => _fixtureUFx4RegistrationStatusIndicatorState; set => Set(ref _fixtureUFx4RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _serialUFx4RegistrationStatusIndicatorState;
    public StatusIndicatorState SerialUFx4RegistrationStatusIndicatorState { get => _serialUFx4RegistrationStatusIndicatorState; set => Set(ref _serialUFx4RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _serialUFx5RegistrationStatusIndicatorState;
    public StatusIndicatorState SerialUFx5RegistrationStatusIndicatorState { get => _serialUFx5RegistrationStatusIndicatorState; set => Set(ref _serialUFx5RegistrationStatusIndicatorState, value); }
}
