using Kamstrup.HC.NewWPF.Entities;
using System.Windows.Input;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Service;

public sealed class ModuleViewModel : WorkspaceViewModelBase
{
    public ModuleViewModel()
    {
        DisplayName = "Moduler";
        Icon = PackIconKind.PuzzleOutline;
    }

    private string _statusMessage;
    public string StatusMessage
    {
        get => _statusMessage;
        set => Set(ref _statusMessage, value);
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex
    {
        get => _selectedTabIndex;
        set => Set(ref _selectedTabIndex, value);
    }

    private string _moduleType;
    public string ModuleType
    {
        get => _moduleType;
        set => Set(ref _moduleType, value);
    }

    private string _internalNumber;
    public string InternalNumber
    {
        get => _internalNumber;
        set => Set(ref _internalNumber, value);
    }

    private string _orderNumber;
    public string OrderNumber
    {
        get => _orderNumber;
        set => Set(ref _orderNumber, value);
    }

    private string _serialNumber;
    public string SerialNumber
    {
        get => _serialNumber;
        set => Set(ref _serialNumber, value);
    }

    private string _operatorName;
    public string OperatorName
    {
        get => _operatorName;
        set => Set(ref _operatorName, value);
    }

    private string _partNumber;
    public string PartNumber
    {
        get => _partNumber;
        set => Set(ref _partNumber, value);
    }

    private string _printRevision;
    public string PrintRevision
    {
        get => _printRevision;
        set => Set(ref _printRevision, value);
    }

    private string _registrationStatus;
    public string RegistrationStatus
    {
        get => _registrationStatus;
        set => Set(ref _registrationStatus, value);
    }

    private string _barcode;
    public string Barcode
    {
        get => _barcode;
        set => Set(ref _barcode, value);
    }

    private ICommand _findModuleCommand;
    public ICommand FindModuleCommand
    {
        get => _findModuleCommand;
        set => Set(ref _findModuleCommand, value);
    }

    private ICommand _clearModuleCommand;
    public ICommand ClearModuleCommand
    {
        get => _clearModuleCommand;
        set => Set(ref _clearModuleCommand, value);
    }

    private string _releasePermissionStatus;
    public string ReleasePermissionStatus
    {
        get => _releasePermissionStatus;
        set => Set(ref _releasePermissionStatus, value);
    }

    private string _releaseStatus;
    public string ReleaseStatus
    {
        get => _releaseStatus;
        set => Set(ref _releaseStatus, value);
    }

    private ICommand _releaseModuleCommand;
    public ICommand ReleaseModuleCommand
    {
        get => _releaseModuleCommand;
        set => Set(ref _releaseModuleCommand, value);
    }

    private ICommand _closeCommand;
    public ICommand CloseCommand
    {
        get => _closeCommand;
        set => Set(ref _closeCommand, value);
    }


    private StatusIndicatorState _registrationStatusIndicatorState;
    public StatusIndicatorState RegistrationStatusIndicatorState { get => _registrationStatusIndicatorState; set => Set(ref _registrationStatusIndicatorState, value); }

    private StatusIndicatorState _releasePermissionStatusIndicatorState;
    public StatusIndicatorState ReleasePermissionStatusIndicatorState { get => _releasePermissionStatusIndicatorState; set => Set(ref _releasePermissionStatusIndicatorState, value); }

    private StatusIndicatorState _releaseStatusIndicatorState;
    public StatusIndicatorState ReleaseStatusIndicatorState { get => _releaseStatusIndicatorState; set => Set(ref _releaseStatusIndicatorState, value); }
}
