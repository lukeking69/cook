using Kamstrup.HC.NewWPF.Entities;
using Caliburn.Micro;
using System.Windows.Media;
using System;
using System.Windows.Input;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;
using Kamstrup.HC.NewWPF.Entities.Service;

namespace Kamstrup.HC.NewWPF.ViewModels.Service;

public sealed class ReplacementViewModel : WorkspaceViewModelBase
{
    public ReplacementViewModel()
    {
        DisplayName = "Udskift UF";
        Icon = PackIconKind.SwapHorizontal;
    }

    private string _statusMessage;
    public string StatusMessage
    {
        get => _statusMessage;
        set => Set(ref _statusMessage, value);
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex
    {
        get => _selectedTabIndex;
        set => Set(ref _selectedTabIndex, value);
    }

    private ICommand _readOldCableCommand;
    public ICommand ReadOldCableCommand
    {
        get => _readOldCableCommand;
        set => Set(ref _readOldCableCommand, value);
    }

    private ICommand _readNewCableCommand;
    public ICommand ReadNewCableCommand
    {
        get => _readNewCableCommand;
        set => Set(ref _readNewCableCommand, value);
    }

    private ICommand _replaceCableCommand;
    public ICommand ReplaceCableCommand
    {
        get => _replaceCableCommand;
        set => Set(ref _replaceCableCommand, value);
    }

    private string _oldCableUFx4InternalNumber;
    public string OldCableUFx4InternalNumber
    {
        get => _oldCableUFx4InternalNumber;
        set => Set(ref _oldCableUFx4InternalNumber, value);
    }

    private string _oldCableUFx4OrderNumber;
    public string OldCableUFx4OrderNumber
    {
        get => _oldCableUFx4OrderNumber;
        set => Set(ref _oldCableUFx4OrderNumber, value);
    }

    private string _oldCableUFx4MeterSerialNumber;
    public string OldCableUFx4MeterSerialNumber
    {
        get => _oldCableUFx4MeterSerialNumber;
        set => Set(ref _oldCableUFx4MeterSerialNumber, value);
    }

    private string _oldCableUFx4UFSerialNumber;
    public string OldCableUFx4UFSerialNumber
    {
        get => _oldCableUFx4UFSerialNumber;
        set => Set(ref _oldCableUFx4UFSerialNumber, value);
    }

    private string _oldCableUFx4TypeNumber;
    public string OldCableUFx4TypeNumber
    {
        get => _oldCableUFx4TypeNumber;
        set => Set(ref _oldCableUFx4TypeNumber, value);
    }

    private string _oldCableUFx4Number59xx;
    public string OldCableUFx4Number59xx
    {
        get => _oldCableUFx4Number59xx;
        set => Set(ref _oldCableUFx4Number59xx, value);
    }

    private string _oldCableUFx4MeterConfiguration;
    public string OldCableUFx4MeterConfiguration
    {
        get => _oldCableUFx4MeterConfiguration;
        set => Set(ref _oldCableUFx4MeterConfiguration, value);
    }

    private string _oldCableUFx4CustomerNumber;
    public string OldCableUFx4CustomerNumber
    {
        get => _oldCableUFx4CustomerNumber;
        set => Set(ref _oldCableUFx4CustomerNumber, value);
    }

    private DateTime? _oldCableUFx4RegistrationDate;
    public DateTime? OldCableUFx4RegistrationDate
    {
        get => _oldCableUFx4RegistrationDate;
        set => Set(ref _oldCableUFx4RegistrationDate, value);
    }

    private string _oldCableUFx4RegisteredBy;
    public string OldCableUFx4RegisteredBy
    {
        get => _oldCableUFx4RegisteredBy;
        set => Set(ref _oldCableUFx4RegisteredBy, value);
    }

    private string _oldCableUFx4TestType;
    public string OldCableUFx4TestType
    {
        get => _oldCableUFx4TestType;
        set => Set(ref _oldCableUFx4TestType, value);
    }

    private DateTime? _oldCableUFx4FinalTestDate;
    public DateTime? OldCableUFx4FinalTestDate
    {
        get => _oldCableUFx4FinalTestDate;
        set => Set(ref _oldCableUFx4FinalTestDate, value);
    }

    private string _oldCableUFx4FinalTestOperator;
    public string OldCableUFx4FinalTestOperator
    {
        get => _oldCableUFx4FinalTestOperator;
        set => Set(ref _oldCableUFx4FinalTestOperator, value);
    }

    private string _oldCableUFx4ConfigurationId;
    public string OldCableUFx4ConfigurationId
    {
        get => _oldCableUFx4ConfigurationId;
        set => Set(ref _oldCableUFx4ConfigurationId, value);
    }

    private int? _oldCableUFx4StorageDays;
    public int? OldCableUFx4StorageDays
    {
        get => _oldCableUFx4StorageDays;
        set => Set(ref _oldCableUFx4StorageDays, value);
    }

    private string _oldCableUFx4LabApproval;
    public string OldCableUFx4LabApproval
    {
        get => _oldCableUFx4LabApproval;
        set => Set(ref _oldCableUFx4LabApproval, value);
    }

    private string _oldCableUFx4SoftwareRevision;
    public string OldCableUFx4SoftwareRevision
    {
        get => _oldCableUFx4SoftwareRevision;
        set => Set(ref _oldCableUFx4SoftwareRevision, value);
    }

    private string _oldCableUFx4RegistrationStatus;
    public string OldCableUFx4RegistrationStatus
    {
        get => _oldCableUFx4RegistrationStatus;
        set => Set(ref _oldCableUFx4RegistrationStatus, value);
    }

    private string _newCableUFx4InternalNumber;
    public string NewCableUFx4InternalNumber
    {
        get => _newCableUFx4InternalNumber;
        set => Set(ref _newCableUFx4InternalNumber, value);
    }

    private string _newCableUFx4OrderNumber;
    public string NewCableUFx4OrderNumber
    {
        get => _newCableUFx4OrderNumber;
        set => Set(ref _newCableUFx4OrderNumber, value);
    }

    private string _newCableUFx4MeterSerialNumber;
    public string NewCableUFx4MeterSerialNumber
    {
        get => _newCableUFx4MeterSerialNumber;
        set => Set(ref _newCableUFx4MeterSerialNumber, value);
    }

    private string _newCableUFx4UFSerialNumber;
    public string NewCableUFx4UFSerialNumber
    {
        get => _newCableUFx4UFSerialNumber;
        set => Set(ref _newCableUFx4UFSerialNumber, value);
    }

    private string _newCableUFx4TypeNumber;
    public string NewCableUFx4TypeNumber
    {
        get => _newCableUFx4TypeNumber;
        set => Set(ref _newCableUFx4TypeNumber, value);
    }

    private string _newCableUFx4Number59xx;
    public string NewCableUFx4Number59xx
    {
        get => _newCableUFx4Number59xx;
        set => Set(ref _newCableUFx4Number59xx, value);
    }

    private string _newCableUFx4MeterConfiguration;
    public string NewCableUFx4MeterConfiguration
    {
        get => _newCableUFx4MeterConfiguration;
        set => Set(ref _newCableUFx4MeterConfiguration, value);
    }

    private string _newCableUFx4CustomerNumber;
    public string NewCableUFx4CustomerNumber
    {
        get => _newCableUFx4CustomerNumber;
        set => Set(ref _newCableUFx4CustomerNumber, value);
    }

    private DateTime? _newCableUFx4RegistrationDate;
    public DateTime? NewCableUFx4RegistrationDate
    {
        get => _newCableUFx4RegistrationDate;
        set => Set(ref _newCableUFx4RegistrationDate, value);
    }

    private string _newCableUFx4RegisteredBy;
    public string NewCableUFx4RegisteredBy
    {
        get => _newCableUFx4RegisteredBy;
        set => Set(ref _newCableUFx4RegisteredBy, value);
    }

    private string _newCableUFx4TestType;
    public string NewCableUFx4TestType
    {
        get => _newCableUFx4TestType;
        set => Set(ref _newCableUFx4TestType, value);
    }

    private DateTime? _newCableUFx4FinalTestDate;
    public DateTime? NewCableUFx4FinalTestDate
    {
        get => _newCableUFx4FinalTestDate;
        set => Set(ref _newCableUFx4FinalTestDate, value);
    }

    private string _newCableUFx4FinalTestOperator;
    public string NewCableUFx4FinalTestOperator
    {
        get => _newCableUFx4FinalTestOperator;
        set => Set(ref _newCableUFx4FinalTestOperator, value);
    }

    private string _newCableUFx4ConfigurationId;
    public string NewCableUFx4ConfigurationId
    {
        get => _newCableUFx4ConfigurationId;
        set => Set(ref _newCableUFx4ConfigurationId, value);
    }

    private int? _newCableUFx4StorageDays;
    public int? NewCableUFx4StorageDays
    {
        get => _newCableUFx4StorageDays;
        set => Set(ref _newCableUFx4StorageDays, value);
    }

    private string _newCableUFx4LabApproval;
    public string NewCableUFx4LabApproval
    {
        get => _newCableUFx4LabApproval;
        set => Set(ref _newCableUFx4LabApproval, value);
    }

    private string _newCableUFx4SoftwareRevision;
    public string NewCableUFx4SoftwareRevision
    {
        get => _newCableUFx4SoftwareRevision;
        set => Set(ref _newCableUFx4SoftwareRevision, value);
    }

    private string _newCableUFx4RegistrationStatus;
    public string NewCableUFx4RegistrationStatus
    {
        get => _newCableUFx4RegistrationStatus;
        set => Set(ref _newCableUFx4RegistrationStatus, value);
    }

    private ImageSource _cableMountingImage;
    public ImageSource CableMountingImage
    {
        get => _cableMountingImage;
        set => Set(ref _cableMountingImage, value);
    }

    private ICommand _readOldFixtureCommand;
    public ICommand ReadOldFixtureCommand
    {
        get => _readOldFixtureCommand;
        set => Set(ref _readOldFixtureCommand, value);
    }

    private ICommand _readNewFixtureCommand;
    public ICommand ReadNewFixtureCommand
    {
        get => _readNewFixtureCommand;
        set => Set(ref _readNewFixtureCommand, value);
    }

    private ICommand _replaceFixtureCommand;
    public ICommand ReplaceFixtureCommand
    {
        get => _replaceFixtureCommand;
        set => Set(ref _replaceFixtureCommand, value);
    }

    private string _oldFixtureUFx4InternalNumber;
    public string OldFixtureUFx4InternalNumber
    {
        get => _oldFixtureUFx4InternalNumber;
        set => Set(ref _oldFixtureUFx4InternalNumber, value);
    }

    private string _oldFixtureUFx4OrderNumber;
    public string OldFixtureUFx4OrderNumber
    {
        get => _oldFixtureUFx4OrderNumber;
        set => Set(ref _oldFixtureUFx4OrderNumber, value);
    }

    private string _oldFixtureUFx4MeterSerialNumber;
    public string OldFixtureUFx4MeterSerialNumber
    {
        get => _oldFixtureUFx4MeterSerialNumber;
        set => Set(ref _oldFixtureUFx4MeterSerialNumber, value);
    }

    private string _oldFixtureUFx4UFSerialNumber;
    public string OldFixtureUFx4UFSerialNumber
    {
        get => _oldFixtureUFx4UFSerialNumber;
        set => Set(ref _oldFixtureUFx4UFSerialNumber, value);
    }

    private string _oldFixtureUFx4TypeNumber;
    public string OldFixtureUFx4TypeNumber
    {
        get => _oldFixtureUFx4TypeNumber;
        set => Set(ref _oldFixtureUFx4TypeNumber, value);
    }

    private string _oldFixtureUFx4Number59xx;
    public string OldFixtureUFx4Number59xx
    {
        get => _oldFixtureUFx4Number59xx;
        set => Set(ref _oldFixtureUFx4Number59xx, value);
    }

    private string _oldFixtureUFx4MeterConfiguration;
    public string OldFixtureUFx4MeterConfiguration
    {
        get => _oldFixtureUFx4MeterConfiguration;
        set => Set(ref _oldFixtureUFx4MeterConfiguration, value);
    }

    private string _oldFixtureUFx4CustomerNumber;
    public string OldFixtureUFx4CustomerNumber
    {
        get => _oldFixtureUFx4CustomerNumber;
        set => Set(ref _oldFixtureUFx4CustomerNumber, value);
    }

    private DateTime? _oldFixtureUFx4RegistrationDate;
    public DateTime? OldFixtureUFx4RegistrationDate
    {
        get => _oldFixtureUFx4RegistrationDate;
        set => Set(ref _oldFixtureUFx4RegistrationDate, value);
    }

    private string _oldFixtureUFx4RegisteredBy;
    public string OldFixtureUFx4RegisteredBy
    {
        get => _oldFixtureUFx4RegisteredBy;
        set => Set(ref _oldFixtureUFx4RegisteredBy, value);
    }

    private string _oldFixtureUFx4TestType;
    public string OldFixtureUFx4TestType
    {
        get => _oldFixtureUFx4TestType;
        set => Set(ref _oldFixtureUFx4TestType, value);
    }

    private DateTime? _oldFixtureUFx4FinalTestDate;
    public DateTime? OldFixtureUFx4FinalTestDate
    {
        get => _oldFixtureUFx4FinalTestDate;
        set => Set(ref _oldFixtureUFx4FinalTestDate, value);
    }

    private string _oldFixtureUFx4FinalTestOperator;
    public string OldFixtureUFx4FinalTestOperator
    {
        get => _oldFixtureUFx4FinalTestOperator;
        set => Set(ref _oldFixtureUFx4FinalTestOperator, value);
    }

    private string _oldFixtureUFx4ConfigurationId;
    public string OldFixtureUFx4ConfigurationId
    {
        get => _oldFixtureUFx4ConfigurationId;
        set => Set(ref _oldFixtureUFx4ConfigurationId, value);
    }

    private int? _oldFixtureUFx4StorageDays;
    public int? OldFixtureUFx4StorageDays
    {
        get => _oldFixtureUFx4StorageDays;
        set => Set(ref _oldFixtureUFx4StorageDays, value);
    }

    private string _oldFixtureUFx4LabApproval;
    public string OldFixtureUFx4LabApproval
    {
        get => _oldFixtureUFx4LabApproval;
        set => Set(ref _oldFixtureUFx4LabApproval, value);
    }

    private string _oldFixtureUFx4SoftwareRevision;
    public string OldFixtureUFx4SoftwareRevision
    {
        get => _oldFixtureUFx4SoftwareRevision;
        set => Set(ref _oldFixtureUFx4SoftwareRevision, value);
    }

    private string _oldFixtureUFx4RegistrationStatus;
    public string OldFixtureUFx4RegistrationStatus
    {
        get => _oldFixtureUFx4RegistrationStatus;
        set => Set(ref _oldFixtureUFx4RegistrationStatus, value);
    }

    private string _newFixtureUFx4InternalNumber;
    public string NewFixtureUFx4InternalNumber
    {
        get => _newFixtureUFx4InternalNumber;
        set => Set(ref _newFixtureUFx4InternalNumber, value);
    }

    private string _newFixtureUFx4OrderNumber;
    public string NewFixtureUFx4OrderNumber
    {
        get => _newFixtureUFx4OrderNumber;
        set => Set(ref _newFixtureUFx4OrderNumber, value);
    }

    private string _newFixtureUFx4MeterSerialNumber;
    public string NewFixtureUFx4MeterSerialNumber
    {
        get => _newFixtureUFx4MeterSerialNumber;
        set => Set(ref _newFixtureUFx4MeterSerialNumber, value);
    }

    private string _newFixtureUFx4UFSerialNumber;
    public string NewFixtureUFx4UFSerialNumber
    {
        get => _newFixtureUFx4UFSerialNumber;
        set => Set(ref _newFixtureUFx4UFSerialNumber, value);
    }

    private string _newFixtureUFx4TypeNumber;
    public string NewFixtureUFx4TypeNumber
    {
        get => _newFixtureUFx4TypeNumber;
        set => Set(ref _newFixtureUFx4TypeNumber, value);
    }

    private string _newFixtureUFx4Number59xx;
    public string NewFixtureUFx4Number59xx
    {
        get => _newFixtureUFx4Number59xx;
        set => Set(ref _newFixtureUFx4Number59xx, value);
    }

    private string _newFixtureUFx4MeterConfiguration;
    public string NewFixtureUFx4MeterConfiguration
    {
        get => _newFixtureUFx4MeterConfiguration;
        set => Set(ref _newFixtureUFx4MeterConfiguration, value);
    }

    private string _newFixtureUFx4CustomerNumber;
    public string NewFixtureUFx4CustomerNumber
    {
        get => _newFixtureUFx4CustomerNumber;
        set => Set(ref _newFixtureUFx4CustomerNumber, value);
    }

    private DateTime? _newFixtureUFx4RegistrationDate;
    public DateTime? NewFixtureUFx4RegistrationDate
    {
        get => _newFixtureUFx4RegistrationDate;
        set => Set(ref _newFixtureUFx4RegistrationDate, value);
    }

    private string _newFixtureUFx4RegisteredBy;
    public string NewFixtureUFx4RegisteredBy
    {
        get => _newFixtureUFx4RegisteredBy;
        set => Set(ref _newFixtureUFx4RegisteredBy, value);
    }

    private string _newFixtureUFx4TestType;
    public string NewFixtureUFx4TestType
    {
        get => _newFixtureUFx4TestType;
        set => Set(ref _newFixtureUFx4TestType, value);
    }

    private DateTime? _newFixtureUFx4FinalTestDate;
    public DateTime? NewFixtureUFx4FinalTestDate
    {
        get => _newFixtureUFx4FinalTestDate;
        set => Set(ref _newFixtureUFx4FinalTestDate, value);
    }

    private string _newFixtureUFx4FinalTestOperator;
    public string NewFixtureUFx4FinalTestOperator
    {
        get => _newFixtureUFx4FinalTestOperator;
        set => Set(ref _newFixtureUFx4FinalTestOperator, value);
    }

    private string _newFixtureUFx4ConfigurationId;
    public string NewFixtureUFx4ConfigurationId
    {
        get => _newFixtureUFx4ConfigurationId;
        set => Set(ref _newFixtureUFx4ConfigurationId, value);
    }

    private int? _newFixtureUFx4StorageDays;
    public int? NewFixtureUFx4StorageDays
    {
        get => _newFixtureUFx4StorageDays;
        set => Set(ref _newFixtureUFx4StorageDays, value);
    }

    private string _newFixtureUFx4LabApproval;
    public string NewFixtureUFx4LabApproval
    {
        get => _newFixtureUFx4LabApproval;
        set => Set(ref _newFixtureUFx4LabApproval, value);
    }

    private string _newFixtureUFx4SoftwareRevision;
    public string NewFixtureUFx4SoftwareRevision
    {
        get => _newFixtureUFx4SoftwareRevision;
        set => Set(ref _newFixtureUFx4SoftwareRevision, value);
    }

    private string _newFixtureUFx4RegistrationStatus;
    public string NewFixtureUFx4RegistrationStatus
    {
        get => _newFixtureUFx4RegistrationStatus;
        set => Set(ref _newFixtureUFx4RegistrationStatus, value);
    }

    private string _replacementUF44SerialNumber;
    public string ReplacementUF44SerialNumber
    {
        get => _replacementUF44SerialNumber;
        set => Set(ref _replacementUF44SerialNumber, value);
    }

    private string _replacementUF44LockStatus;
    public string ReplacementUF44LockStatus
    {
        get => _replacementUF44LockStatus;
        set => Set(ref _replacementUF44LockStatus, value);
    }

    private string _replacementUF44Status;
    public string ReplacementUF44Status
    {
        get => _replacementUF44Status;
        set => Set(ref _replacementUF44Status, value);
    }

    private string _replacementUF44TestTopRevision;
    public string ReplacementUF44TestTopRevision
    {
        get => _replacementUF44TestTopRevision;
        set => Set(ref _replacementUF44TestTopRevision, value);
    }

    private string _replacementUF44UnlockTimeoutDisabled;
    public string ReplacementUF44UnlockTimeoutDisabled
    {
        get => _replacementUF44UnlockTimeoutDisabled;
        set => Set(ref _replacementUF44UnlockTimeoutDisabled, value);
    }

    private string _replacementUF44PasswordWriteEnabledE2;
    public string ReplacementUF44PasswordWriteEnabledE2
    {
        get => _replacementUF44PasswordWriteEnabledE2;
        set => Set(ref _replacementUF44PasswordWriteEnabledE2, value);
    }

    private string _replacementUF44SerialModeEnabledE2;
    public string ReplacementUF44SerialModeEnabledE2
    {
        get => _replacementUF44SerialModeEnabledE2;
        set => Set(ref _replacementUF44SerialModeEnabledE2, value);
    }

    private string _replacementUF44Timeout;
    public string ReplacementUF44Timeout
    {
        get => _replacementUF44Timeout;
        set => Set(ref _replacementUF44Timeout, value);
    }

    private string _replacementUF44PasswordDisplay;
    public string ReplacementUF44PasswordDisplay
    {
        get => _replacementUF44PasswordDisplay;
        set => Set(ref _replacementUF44PasswordDisplay, value);
    }

    private ImageSource _fixtureMountingImage;
    public ImageSource FixtureMountingImage
    {
        get => _fixtureMountingImage;
        set => Set(ref _fixtureMountingImage, value);
    }

    private string _oldUFx5Port;
    public string OldUFx5Port
    {
        get => _oldUFx5Port;
        set => Set(ref _oldUFx5Port, value);
    }

    private string _newUFx5Port;
    public string NewUFx5Port
    {
        get => _newUFx5Port;
        set => Set(ref _newUFx5Port, value);
    }

    private ICommand _readOldUFx5Command;
    public ICommand ReadOldUFx5Command
    {
        get => _readOldUFx5Command;
        set => Set(ref _readOldUFx5Command, value);
    }

    private ICommand _testCurrentCommand;
    public ICommand TestCurrentCommand
    {
        get => _testCurrentCommand;
        set => Set(ref _testCurrentCommand, value);
    }

    private ICommand _readNewUFx5Command;
    public ICommand ReadNewUFx5Command
    {
        get => _readNewUFx5Command;
        set => Set(ref _readNewUFx5Command, value);
    }

    private ICommand _replaceUFx5Command;
    public ICommand ReplaceUFx5Command
    {
        get => _replaceUFx5Command;
        set => Set(ref _replaceUFx5Command, value);
    }

    private string _currentTestStatus;
    public string CurrentTestStatus
    {
        get => _currentTestStatus;
        set => Set(ref _currentTestStatus, value);
    }

    private decimal? _currentMeasurement;
    public decimal? CurrentMeasurement
    {
        get => _currentMeasurement;
        set => Set(ref _currentMeasurement, value);
    }

    private decimal? _currentLimit;
    public decimal? CurrentLimit
    {
        get => _currentLimit;
        set => Set(ref _currentLimit, value);
    }

    private string _oldPhysicalUFx5SerialNumber;
    public string OldPhysicalUFx5SerialNumber
    {
        get => _oldPhysicalUFx5SerialNumber;
        set => Set(ref _oldPhysicalUFx5SerialNumber, value);
    }

    private string _oldPhysicalUFx5MeterPartNumber;
    public string OldPhysicalUFx5MeterPartNumber
    {
        get => _oldPhysicalUFx5MeterPartNumber;
        set => Set(ref _oldPhysicalUFx5MeterPartNumber, value);
    }

    private string _oldPhysicalUFx5MeterCustomerId;
    public string OldPhysicalUFx5MeterCustomerId
    {
        get => _oldPhysicalUFx5MeterCustomerId;
        set => Set(ref _oldPhysicalUFx5MeterCustomerId, value);
    }

    private string _oldPhysicalUFx5MeterInternalId;
    public string OldPhysicalUFx5MeterInternalId
    {
        get => _oldPhysicalUFx5MeterInternalId;
        set => Set(ref _oldPhysicalUFx5MeterInternalId, value);
    }

    private string _oldPhysicalUFx5InternalNumber;
    public string OldPhysicalUFx5InternalNumber
    {
        get => _oldPhysicalUFx5InternalNumber;
        set => Set(ref _oldPhysicalUFx5InternalNumber, value);
    }

    private string _oldPhysicalUFx5ExternalSerialNumber;
    public string OldPhysicalUFx5ExternalSerialNumber
    {
        get => _oldPhysicalUFx5ExternalSerialNumber;
        set => Set(ref _oldPhysicalUFx5ExternalSerialNumber, value);
    }

    private string _oldPhysicalUFx5SoftwareRevision;
    public string OldPhysicalUFx5SoftwareRevision
    {
        get => _oldPhysicalUFx5SoftwareRevision;
        set => Set(ref _oldPhysicalUFx5SoftwareRevision, value);
    }

    private string _oldPhysicalUFx5SoftwareCrc;
    public string OldPhysicalUFx5SoftwareCrc
    {
        get => _oldPhysicalUFx5SoftwareCrc;
        set => Set(ref _oldPhysicalUFx5SoftwareCrc, value);
    }

    private string _oldPhysicalUFx5ProgrammingVerification;
    public string OldPhysicalUFx5ProgrammingVerification
    {
        get => _oldPhysicalUFx5ProgrammingVerification;
        set => Set(ref _oldPhysicalUFx5ProgrammingVerification, value);
    }

    private string _oldPhysicalUFx5WarmForwardVerification;
    public string OldPhysicalUFx5WarmForwardVerification
    {
        get => _oldPhysicalUFx5WarmForwardVerification;
        set => Set(ref _oldPhysicalUFx5WarmForwardVerification, value);
    }

    private string _oldPhysicalUFx5WarmReverseVerification;
    public string OldPhysicalUFx5WarmReverseVerification
    {
        get => _oldPhysicalUFx5WarmReverseVerification;
        set => Set(ref _oldPhysicalUFx5WarmReverseVerification, value);
    }

    private string _oldPhysicalUFx5ColdForwardVerification;
    public string OldPhysicalUFx5ColdForwardVerification
    {
        get => _oldPhysicalUFx5ColdForwardVerification;
        set => Set(ref _oldPhysicalUFx5ColdForwardVerification, value);
    }

    private string _oldPhysicalUFx5ExternalDesiredMeterType;
    public string OldPhysicalUFx5ExternalDesiredMeterType
    {
        get => _oldPhysicalUFx5ExternalDesiredMeterType;
        set => Set(ref _oldPhysicalUFx5ExternalDesiredMeterType, value);
    }

    private string _oldDatabaseUFx5InternalNumber;
    public string OldDatabaseUFx5InternalNumber
    {
        get => _oldDatabaseUFx5InternalNumber;
        set => Set(ref _oldDatabaseUFx5InternalNumber, value);
    }

    private string _oldDatabaseUFx5OrderNumber;
    public string OldDatabaseUFx5OrderNumber
    {
        get => _oldDatabaseUFx5OrderNumber;
        set => Set(ref _oldDatabaseUFx5OrderNumber, value);
    }

    private string _oldDatabaseUFx5UFSerialNumber;
    public string OldDatabaseUFx5UFSerialNumber
    {
        get => _oldDatabaseUFx5UFSerialNumber;
        set => Set(ref _oldDatabaseUFx5UFSerialNumber, value);
    }

    private string _oldDatabaseUFx5UFExternalSerialNumber;
    public string OldDatabaseUFx5UFExternalSerialNumber
    {
        get => _oldDatabaseUFx5UFExternalSerialNumber;
        set => Set(ref _oldDatabaseUFx5UFExternalSerialNumber, value);
    }

    private string _oldDatabaseUFx5TypeNumber;
    public string OldDatabaseUFx5TypeNumber
    {
        get => _oldDatabaseUFx5TypeNumber;
        set => Set(ref _oldDatabaseUFx5TypeNumber, value);
    }

    private string _oldDatabaseUFx5CustomerSerialNumber;
    public string OldDatabaseUFx5CustomerSerialNumber
    {
        get => _oldDatabaseUFx5CustomerSerialNumber;
        set => Set(ref _oldDatabaseUFx5CustomerSerialNumber, value);
    }

    private string _oldDatabaseUFx5MeterSerialNumber;
    public string OldDatabaseUFx5MeterSerialNumber
    {
        get => _oldDatabaseUFx5MeterSerialNumber;
        set => Set(ref _oldDatabaseUFx5MeterSerialNumber, value);
    }

    private string _oldDatabaseUFx5Number59xx;
    public string OldDatabaseUFx5Number59xx
    {
        get => _oldDatabaseUFx5Number59xx;
        set => Set(ref _oldDatabaseUFx5Number59xx, value);
    }

    private string _oldDatabaseUFx5MeterConfiguration;
    public string OldDatabaseUFx5MeterConfiguration
    {
        get => _oldDatabaseUFx5MeterConfiguration;
        set => Set(ref _oldDatabaseUFx5MeterConfiguration, value);
    }

    private DateTime? _oldDatabaseUFx5RegistrationDate;
    public DateTime? OldDatabaseUFx5RegistrationDate
    {
        get => _oldDatabaseUFx5RegistrationDate;
        set => Set(ref _oldDatabaseUFx5RegistrationDate, value);
    }

    private string _oldDatabaseUFx5RegisteredBy;
    public string OldDatabaseUFx5RegisteredBy
    {
        get => _oldDatabaseUFx5RegisteredBy;
        set => Set(ref _oldDatabaseUFx5RegisteredBy, value);
    }

    private DateTime? _oldDatabaseUFx5FinalTestDate;
    public DateTime? OldDatabaseUFx5FinalTestDate
    {
        get => _oldDatabaseUFx5FinalTestDate;
        set => Set(ref _oldDatabaseUFx5FinalTestDate, value);
    }

    private string _oldDatabaseUFx5FinalTestOperator;
    public string OldDatabaseUFx5FinalTestOperator
    {
        get => _oldDatabaseUFx5FinalTestOperator;
        set => Set(ref _oldDatabaseUFx5FinalTestOperator, value);
    }

    private string _oldDatabaseUFx5ConfigurationId;
    public string OldDatabaseUFx5ConfigurationId
    {
        get => _oldDatabaseUFx5ConfigurationId;
        set => Set(ref _oldDatabaseUFx5ConfigurationId, value);
    }

    private int? _oldDatabaseUFx5StorageDays;
    public int? OldDatabaseUFx5StorageDays
    {
        get => _oldDatabaseUFx5StorageDays;
        set => Set(ref _oldDatabaseUFx5StorageDays, value);
    }

    private string _oldDatabaseUFx5LabApproval;
    public string OldDatabaseUFx5LabApproval
    {
        get => _oldDatabaseUFx5LabApproval;
        set => Set(ref _oldDatabaseUFx5LabApproval, value);
    }

    private string _oldDatabaseUFx5SoftwareRevision;
    public string OldDatabaseUFx5SoftwareRevision
    {
        get => _oldDatabaseUFx5SoftwareRevision;
        set => Set(ref _oldDatabaseUFx5SoftwareRevision, value);
    }

    private string _oldDatabaseUFx5SoftwareCrc;
    public string OldDatabaseUFx5SoftwareCrc
    {
        get => _oldDatabaseUFx5SoftwareCrc;
        set => Set(ref _oldDatabaseUFx5SoftwareCrc, value);
    }

    private string _oldDatabaseUFx5RegistrationStatus;
    public string OldDatabaseUFx5RegistrationStatus
    {
        get => _oldDatabaseUFx5RegistrationStatus;
        set => Set(ref _oldDatabaseUFx5RegistrationStatus, value);
    }

    private string _newPhysicalUFx5SerialNumber;
    public string NewPhysicalUFx5SerialNumber
    {
        get => _newPhysicalUFx5SerialNumber;
        set => Set(ref _newPhysicalUFx5SerialNumber, value);
    }

    private string _newPhysicalUFx5MeterPartNumber;
    public string NewPhysicalUFx5MeterPartNumber
    {
        get => _newPhysicalUFx5MeterPartNumber;
        set => Set(ref _newPhysicalUFx5MeterPartNumber, value);
    }

    private string _newPhysicalUFx5MeterCustomerId;
    public string NewPhysicalUFx5MeterCustomerId
    {
        get => _newPhysicalUFx5MeterCustomerId;
        set => Set(ref _newPhysicalUFx5MeterCustomerId, value);
    }

    private string _newPhysicalUFx5MeterInternalId;
    public string NewPhysicalUFx5MeterInternalId
    {
        get => _newPhysicalUFx5MeterInternalId;
        set => Set(ref _newPhysicalUFx5MeterInternalId, value);
    }

    private string _newPhysicalUFx5InternalNumber;
    public string NewPhysicalUFx5InternalNumber
    {
        get => _newPhysicalUFx5InternalNumber;
        set => Set(ref _newPhysicalUFx5InternalNumber, value);
    }

    private string _newPhysicalUFx5ExternalSerialNumber;
    public string NewPhysicalUFx5ExternalSerialNumber
    {
        get => _newPhysicalUFx5ExternalSerialNumber;
        set => Set(ref _newPhysicalUFx5ExternalSerialNumber, value);
    }

    private string _newPhysicalUFx5SoftwareRevision;
    public string NewPhysicalUFx5SoftwareRevision
    {
        get => _newPhysicalUFx5SoftwareRevision;
        set => Set(ref _newPhysicalUFx5SoftwareRevision, value);
    }

    private string _newPhysicalUFx5SoftwareCrc;
    public string NewPhysicalUFx5SoftwareCrc
    {
        get => _newPhysicalUFx5SoftwareCrc;
        set => Set(ref _newPhysicalUFx5SoftwareCrc, value);
    }

    private string _newPhysicalUFx5ProgrammingVerification;
    public string NewPhysicalUFx5ProgrammingVerification
    {
        get => _newPhysicalUFx5ProgrammingVerification;
        set => Set(ref _newPhysicalUFx5ProgrammingVerification, value);
    }

    private string _newPhysicalUFx5WarmForwardVerification;
    public string NewPhysicalUFx5WarmForwardVerification
    {
        get => _newPhysicalUFx5WarmForwardVerification;
        set => Set(ref _newPhysicalUFx5WarmForwardVerification, value);
    }

    private string _newPhysicalUFx5WarmReverseVerification;
    public string NewPhysicalUFx5WarmReverseVerification
    {
        get => _newPhysicalUFx5WarmReverseVerification;
        set => Set(ref _newPhysicalUFx5WarmReverseVerification, value);
    }

    private string _newPhysicalUFx5ColdForwardVerification;
    public string NewPhysicalUFx5ColdForwardVerification
    {
        get => _newPhysicalUFx5ColdForwardVerification;
        set => Set(ref _newPhysicalUFx5ColdForwardVerification, value);
    }

    private string _newPhysicalUFx5ExternalDesiredMeterType;
    public string NewPhysicalUFx5ExternalDesiredMeterType
    {
        get => _newPhysicalUFx5ExternalDesiredMeterType;
        set => Set(ref _newPhysicalUFx5ExternalDesiredMeterType, value);
    }

    private string _newDatabaseUFx5InternalNumber;
    public string NewDatabaseUFx5InternalNumber
    {
        get => _newDatabaseUFx5InternalNumber;
        set => Set(ref _newDatabaseUFx5InternalNumber, value);
    }

    private string _newDatabaseUFx5OrderNumber;
    public string NewDatabaseUFx5OrderNumber
    {
        get => _newDatabaseUFx5OrderNumber;
        set => Set(ref _newDatabaseUFx5OrderNumber, value);
    }

    private string _newDatabaseUFx5UFSerialNumber;
    public string NewDatabaseUFx5UFSerialNumber
    {
        get => _newDatabaseUFx5UFSerialNumber;
        set => Set(ref _newDatabaseUFx5UFSerialNumber, value);
    }

    private string _newDatabaseUFx5UFExternalSerialNumber;
    public string NewDatabaseUFx5UFExternalSerialNumber
    {
        get => _newDatabaseUFx5UFExternalSerialNumber;
        set => Set(ref _newDatabaseUFx5UFExternalSerialNumber, value);
    }

    private string _newDatabaseUFx5TypeNumber;
    public string NewDatabaseUFx5TypeNumber
    {
        get => _newDatabaseUFx5TypeNumber;
        set => Set(ref _newDatabaseUFx5TypeNumber, value);
    }

    private string _newDatabaseUFx5CustomerSerialNumber;
    public string NewDatabaseUFx5CustomerSerialNumber
    {
        get => _newDatabaseUFx5CustomerSerialNumber;
        set => Set(ref _newDatabaseUFx5CustomerSerialNumber, value);
    }

    private string _newDatabaseUFx5MeterSerialNumber;
    public string NewDatabaseUFx5MeterSerialNumber
    {
        get => _newDatabaseUFx5MeterSerialNumber;
        set => Set(ref _newDatabaseUFx5MeterSerialNumber, value);
    }

    private string _newDatabaseUFx5Number59xx;
    public string NewDatabaseUFx5Number59xx
    {
        get => _newDatabaseUFx5Number59xx;
        set => Set(ref _newDatabaseUFx5Number59xx, value);
    }

    private string _newDatabaseUFx5MeterConfiguration;
    public string NewDatabaseUFx5MeterConfiguration
    {
        get => _newDatabaseUFx5MeterConfiguration;
        set => Set(ref _newDatabaseUFx5MeterConfiguration, value);
    }

    private DateTime? _newDatabaseUFx5RegistrationDate;
    public DateTime? NewDatabaseUFx5RegistrationDate
    {
        get => _newDatabaseUFx5RegistrationDate;
        set => Set(ref _newDatabaseUFx5RegistrationDate, value);
    }

    private string _newDatabaseUFx5RegisteredBy;
    public string NewDatabaseUFx5RegisteredBy
    {
        get => _newDatabaseUFx5RegisteredBy;
        set => Set(ref _newDatabaseUFx5RegisteredBy, value);
    }

    private DateTime? _newDatabaseUFx5FinalTestDate;
    public DateTime? NewDatabaseUFx5FinalTestDate
    {
        get => _newDatabaseUFx5FinalTestDate;
        set => Set(ref _newDatabaseUFx5FinalTestDate, value);
    }

    private string _newDatabaseUFx5FinalTestOperator;
    public string NewDatabaseUFx5FinalTestOperator
    {
        get => _newDatabaseUFx5FinalTestOperator;
        set => Set(ref _newDatabaseUFx5FinalTestOperator, value);
    }

    private string _newDatabaseUFx5ConfigurationId;
    public string NewDatabaseUFx5ConfigurationId
    {
        get => _newDatabaseUFx5ConfigurationId;
        set => Set(ref _newDatabaseUFx5ConfigurationId, value);
    }

    private int? _newDatabaseUFx5StorageDays;
    public int? NewDatabaseUFx5StorageDays
    {
        get => _newDatabaseUFx5StorageDays;
        set => Set(ref _newDatabaseUFx5StorageDays, value);
    }

    private string _newDatabaseUFx5LabApproval;
    public string NewDatabaseUFx5LabApproval
    {
        get => _newDatabaseUFx5LabApproval;
        set => Set(ref _newDatabaseUFx5LabApproval, value);
    }

    private string _newDatabaseUFx5SoftwareRevision;
    public string NewDatabaseUFx5SoftwareRevision
    {
        get => _newDatabaseUFx5SoftwareRevision;
        set => Set(ref _newDatabaseUFx5SoftwareRevision, value);
    }

    private string _newDatabaseUFx5SoftwareCrc;
    public string NewDatabaseUFx5SoftwareCrc
    {
        get => _newDatabaseUFx5SoftwareCrc;
        set => Set(ref _newDatabaseUFx5SoftwareCrc, value);
    }

    private string _newDatabaseUFx5RegistrationStatus;
    public string NewDatabaseUFx5RegistrationStatus
    {
        get => _newDatabaseUFx5RegistrationStatus;
        set => Set(ref _newDatabaseUFx5RegistrationStatus, value);
    }

    private ImageSource _uFx5MountingImage;
    public ImageSource UFx5MountingImage
    {
        get => _uFx5MountingImage;
        set => Set(ref _uFx5MountingImage, value);
    }

    private string _operatorInstruction;
    public string OperatorInstruction
    {
        get => _operatorInstruction;
        set => Set(ref _operatorInstruction, value);
    }

    private string _replacementStatus;
    public string ReplacementStatus
    {
        get => _replacementStatus;
        set => Set(ref _replacementStatus, value);
    }

    private string _mountingStatus;
    public string MountingStatus
    {
        get => _mountingStatus;
        set => Set(ref _mountingStatus, value);
    }

    private ReplacementProgressRow _selectedProgressRow;
    public ReplacementProgressRow SelectedProgressRow
    {
        get => _selectedProgressRow;
        set => Set(ref _selectedProgressRow, value);
    }

    private ICommand _closeCommand;
    public ICommand CloseCommand
    {
        get => _closeCommand;
        set => Set(ref _closeCommand, value);
    }

    public BindableCollection<ReplacementProgressRow> ProgressRows { get; } = new();


    private StatusIndicatorState _currentTestStatusIndicatorState;
    public StatusIndicatorState CurrentTestStatusIndicatorState { get => _currentTestStatusIndicatorState; set => Set(ref _currentTestStatusIndicatorState, value); }

    private StatusIndicatorState _mountingStatusIndicatorState;
    public StatusIndicatorState MountingStatusIndicatorState { get => _mountingStatusIndicatorState; set => Set(ref _mountingStatusIndicatorState, value); }

    private StatusIndicatorState _newCableUFx4RegistrationStatusIndicatorState;
    public StatusIndicatorState NewCableUFx4RegistrationStatusIndicatorState { get => _newCableUFx4RegistrationStatusIndicatorState; set => Set(ref _newCableUFx4RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _newDatabaseUFx5RegistrationStatusIndicatorState;
    public StatusIndicatorState NewDatabaseUFx5RegistrationStatusIndicatorState { get => _newDatabaseUFx5RegistrationStatusIndicatorState; set => Set(ref _newDatabaseUFx5RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _newFixtureUFx4RegistrationStatusIndicatorState;
    public StatusIndicatorState NewFixtureUFx4RegistrationStatusIndicatorState { get => _newFixtureUFx4RegistrationStatusIndicatorState; set => Set(ref _newFixtureUFx4RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _oldCableUFx4RegistrationStatusIndicatorState;
    public StatusIndicatorState OldCableUFx4RegistrationStatusIndicatorState { get => _oldCableUFx4RegistrationStatusIndicatorState; set => Set(ref _oldCableUFx4RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _oldDatabaseUFx5RegistrationStatusIndicatorState;
    public StatusIndicatorState OldDatabaseUFx5RegistrationStatusIndicatorState { get => _oldDatabaseUFx5RegistrationStatusIndicatorState; set => Set(ref _oldDatabaseUFx5RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _oldFixtureUFx4RegistrationStatusIndicatorState;
    public StatusIndicatorState OldFixtureUFx4RegistrationStatusIndicatorState { get => _oldFixtureUFx4RegistrationStatusIndicatorState; set => Set(ref _oldFixtureUFx4RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _replacementStatusIndicatorState;
    public StatusIndicatorState ReplacementStatusIndicatorState { get => _replacementStatusIndicatorState; set => Set(ref _replacementStatusIndicatorState, value); }

    private StatusIndicatorState _replacementUF44LockStatusIndicatorState;
    public StatusIndicatorState ReplacementUF44LockStatusIndicatorState { get => _replacementUF44LockStatusIndicatorState; set => Set(ref _replacementUF44LockStatusIndicatorState, value); }

    private StatusIndicatorState _replacementUF44StatusIndicatorState;
    public StatusIndicatorState ReplacementUF44StatusIndicatorState { get => _replacementUF44StatusIndicatorState; set => Set(ref _replacementUF44StatusIndicatorState, value); }
}
