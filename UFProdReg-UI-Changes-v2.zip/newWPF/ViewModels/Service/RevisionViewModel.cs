using Kamstrup.HC.NewWPF.Entities;
using Caliburn.Micro;
using System.Windows.Input;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Service;

public sealed class RevisionViewModel : WorkspaceViewModelBase
{
    public RevisionViewModel()
    {
        DisplayName = "SW-revision";
        Icon = PackIconKind.SourceBranch;
    }

    private string _statusMessage;
    public string StatusMessage
    {
        get => _statusMessage;
        set => Set(ref _statusMessage, value);
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex
    {
        get => _selectedTabIndex;
        set => Set(ref _selectedTabIndex, value);
    }

    private string _internalNumber;
    public string InternalNumber
    {
        get => _internalNumber;
        set => Set(ref _internalNumber, value);
    }

    private string _readRevision;
    public string ReadRevision
    {
        get => _readRevision;
        set => Set(ref _readRevision, value);
    }

    private string _readErrorMessage;
    public string ReadErrorMessage
    {
        get => _readErrorMessage;
        set => Set(ref _readErrorMessage, value);
    }

    private bool _closeAfterRead;
    public bool CloseAfterRead
    {
        get => _closeAfterRead;
        set => Set(ref _closeAfterRead, value);
    }

    private ICommand _readRevisionCommand;
    public ICommand ReadRevisionCommand
    {
        get => _readRevisionCommand;
        set => Set(ref _readRevisionCommand, value);
    }

    private string _selectedMeterPosition;
    public string SelectedMeterPosition
    {
        get => _selectedMeterPosition;
        set => Set(ref _selectedMeterPosition, value);
    }

    private string _selectedRevision;
    public string SelectedRevision
    {
        get => _selectedRevision;
        set => Set(ref _selectedRevision, value);
    }

    private string _defaultRevision;
    public string DefaultRevision
    {
        get => _defaultRevision;
        set => Set(ref _defaultRevision, value);
    }

    private string _latestRevision;
    public string LatestRevision
    {
        get => _latestRevision;
        set => Set(ref _latestRevision, value);
    }

    private string _selectedRevisionDisplay;
    public string SelectedRevisionDisplay
    {
        get => _selectedRevisionDisplay;
        set => Set(ref _selectedRevisionDisplay, value);
    }

    private ICommand _loadRevisionsCommand;
    public ICommand LoadRevisionsCommand
    {
        get => _loadRevisionsCommand;
        set => Set(ref _loadRevisionsCommand, value);
    }

    private ICommand _useDefaultRevisionCommand;
    public ICommand UseDefaultRevisionCommand
    {
        get => _useDefaultRevisionCommand;
        set => Set(ref _useDefaultRevisionCommand, value);
    }

    private ICommand _useLatestRevisionCommand;
    public ICommand UseLatestRevisionCommand
    {
        get => _useLatestRevisionCommand;
        set => Set(ref _useLatestRevisionCommand, value);
    }

    private ICommand _confirmRevisionCommand;
    public ICommand ConfirmRevisionCommand
    {
        get => _confirmRevisionCommand;
        set => Set(ref _confirmRevisionCommand, value);
    }

    private ICommand _closeCommand;
    public ICommand CloseCommand
    {
        get => _closeCommand;
        set => Set(ref _closeCommand, value);
    }

    public BindableCollection<LookupOption> MeterPositionOptions { get; } = new();

    public BindableCollection<LookupOption> RevisionOptions { get; } = new();

}
