using Kamstrup.HC.NewWPF.Entities;
using Caliburn.Micro;
using System;
using System.Windows.Input;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;
using Kamstrup.HC.NewWPF.Entities.Service;

namespace Kamstrup.HC.NewWPF.ViewModels.Service;

public sealed class ReleaseViewModel : WorkspaceViewModelBase
{
    public ReleaseViewModel()
    {
        DisplayName = "Frigiv måler";
        Icon = PackIconKind.LockOpenOutline;
    }

    private string _statusMessage;
    public string StatusMessage
    {
        get => _statusMessage;
        set => Set(ref _statusMessage, value);
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex
    {
        get => _selectedTabIndex;
        set => Set(ref _selectedTabIndex, value);
    }

    private ICommand _readCableCommand;
    public ICommand ReadCableCommand
    {
        get => _readCableCommand;
        set => Set(ref _readCableCommand, value);
    }

    private ICommand _releaseCableCommand;
    public ICommand ReleaseCableCommand
    {
        get => _releaseCableCommand;
        set => Set(ref _releaseCableCommand, value);
    }

    private string _cableUFx4InternalNumber;
    public string CableUFx4InternalNumber
    {
        get => _cableUFx4InternalNumber;
        set => Set(ref _cableUFx4InternalNumber, value);
    }

    private string _cableUFx4OrderNumber;
    public string CableUFx4OrderNumber
    {
        get => _cableUFx4OrderNumber;
        set => Set(ref _cableUFx4OrderNumber, value);
    }

    private string _cableUFx4MeterSerialNumber;
    public string CableUFx4MeterSerialNumber
    {
        get => _cableUFx4MeterSerialNumber;
        set => Set(ref _cableUFx4MeterSerialNumber, value);
    }

    private string _cableUFx4UFSerialNumber;
    public string CableUFx4UFSerialNumber
    {
        get => _cableUFx4UFSerialNumber;
        set => Set(ref _cableUFx4UFSerialNumber, value);
    }

    private string _cableUFx4TypeNumber;
    public string CableUFx4TypeNumber
    {
        get => _cableUFx4TypeNumber;
        set => Set(ref _cableUFx4TypeNumber, value);
    }

    private string _cableUFx4Number59xx;
    public string CableUFx4Number59xx
    {
        get => _cableUFx4Number59xx;
        set => Set(ref _cableUFx4Number59xx, value);
    }

    private string _cableUFx4MeterConfiguration;
    public string CableUFx4MeterConfiguration
    {
        get => _cableUFx4MeterConfiguration;
        set => Set(ref _cableUFx4MeterConfiguration, value);
    }

    private string _cableUFx4CustomerNumber;
    public string CableUFx4CustomerNumber
    {
        get => _cableUFx4CustomerNumber;
        set => Set(ref _cableUFx4CustomerNumber, value);
    }

    private DateTime? _cableUFx4RegistrationDate;
    public DateTime? CableUFx4RegistrationDate
    {
        get => _cableUFx4RegistrationDate;
        set => Set(ref _cableUFx4RegistrationDate, value);
    }

    private string _cableUFx4RegisteredBy;
    public string CableUFx4RegisteredBy
    {
        get => _cableUFx4RegisteredBy;
        set => Set(ref _cableUFx4RegisteredBy, value);
    }

    private string _cableUFx4TestType;
    public string CableUFx4TestType
    {
        get => _cableUFx4TestType;
        set => Set(ref _cableUFx4TestType, value);
    }

    private DateTime? _cableUFx4FinalTestDate;
    public DateTime? CableUFx4FinalTestDate
    {
        get => _cableUFx4FinalTestDate;
        set => Set(ref _cableUFx4FinalTestDate, value);
    }

    private string _cableUFx4FinalTestOperator;
    public string CableUFx4FinalTestOperator
    {
        get => _cableUFx4FinalTestOperator;
        set => Set(ref _cableUFx4FinalTestOperator, value);
    }

    private string _cableUFx4ConfigurationId;
    public string CableUFx4ConfigurationId
    {
        get => _cableUFx4ConfigurationId;
        set => Set(ref _cableUFx4ConfigurationId, value);
    }

    private int? _cableUFx4StorageDays;
    public int? CableUFx4StorageDays
    {
        get => _cableUFx4StorageDays;
        set => Set(ref _cableUFx4StorageDays, value);
    }

    private string _cableUFx4LabApproval;
    public string CableUFx4LabApproval
    {
        get => _cableUFx4LabApproval;
        set => Set(ref _cableUFx4LabApproval, value);
    }

    private string _cableUFx4SoftwareRevision;
    public string CableUFx4SoftwareRevision
    {
        get => _cableUFx4SoftwareRevision;
        set => Set(ref _cableUFx4SoftwareRevision, value);
    }

    private string _cableUFx4RegistrationStatus;
    public string CableUFx4RegistrationStatus
    {
        get => _cableUFx4RegistrationStatus;
        set => Set(ref _cableUFx4RegistrationStatus, value);
    }

    private ICommand _readFixtureCommand;
    public ICommand ReadFixtureCommand
    {
        get => _readFixtureCommand;
        set => Set(ref _readFixtureCommand, value);
    }

    private ICommand _releaseFixtureCommand;
    public ICommand ReleaseFixtureCommand
    {
        get => _releaseFixtureCommand;
        set => Set(ref _releaseFixtureCommand, value);
    }

    private string _fixtureUFx4InternalNumber;
    public string FixtureUFx4InternalNumber
    {
        get => _fixtureUFx4InternalNumber;
        set => Set(ref _fixtureUFx4InternalNumber, value);
    }

    private string _fixtureUFx4OrderNumber;
    public string FixtureUFx4OrderNumber
    {
        get => _fixtureUFx4OrderNumber;
        set => Set(ref _fixtureUFx4OrderNumber, value);
    }

    private string _fixtureUFx4MeterSerialNumber;
    public string FixtureUFx4MeterSerialNumber
    {
        get => _fixtureUFx4MeterSerialNumber;
        set => Set(ref _fixtureUFx4MeterSerialNumber, value);
    }

    private string _fixtureUFx4UFSerialNumber;
    public string FixtureUFx4UFSerialNumber
    {
        get => _fixtureUFx4UFSerialNumber;
        set => Set(ref _fixtureUFx4UFSerialNumber, value);
    }

    private string _fixtureUFx4TypeNumber;
    public string FixtureUFx4TypeNumber
    {
        get => _fixtureUFx4TypeNumber;
        set => Set(ref _fixtureUFx4TypeNumber, value);
    }

    private string _fixtureUFx4Number59xx;
    public string FixtureUFx4Number59xx
    {
        get => _fixtureUFx4Number59xx;
        set => Set(ref _fixtureUFx4Number59xx, value);
    }

    private string _fixtureUFx4MeterConfiguration;
    public string FixtureUFx4MeterConfiguration
    {
        get => _fixtureUFx4MeterConfiguration;
        set => Set(ref _fixtureUFx4MeterConfiguration, value);
    }

    private string _fixtureUFx4CustomerNumber;
    public string FixtureUFx4CustomerNumber
    {
        get => _fixtureUFx4CustomerNumber;
        set => Set(ref _fixtureUFx4CustomerNumber, value);
    }

    private DateTime? _fixtureUFx4RegistrationDate;
    public DateTime? FixtureUFx4RegistrationDate
    {
        get => _fixtureUFx4RegistrationDate;
        set => Set(ref _fixtureUFx4RegistrationDate, value);
    }

    private string _fixtureUFx4RegisteredBy;
    public string FixtureUFx4RegisteredBy
    {
        get => _fixtureUFx4RegisteredBy;
        set => Set(ref _fixtureUFx4RegisteredBy, value);
    }

    private string _fixtureUFx4TestType;
    public string FixtureUFx4TestType
    {
        get => _fixtureUFx4TestType;
        set => Set(ref _fixtureUFx4TestType, value);
    }

    private DateTime? _fixtureUFx4FinalTestDate;
    public DateTime? FixtureUFx4FinalTestDate
    {
        get => _fixtureUFx4FinalTestDate;
        set => Set(ref _fixtureUFx4FinalTestDate, value);
    }

    private string _fixtureUFx4FinalTestOperator;
    public string FixtureUFx4FinalTestOperator
    {
        get => _fixtureUFx4FinalTestOperator;
        set => Set(ref _fixtureUFx4FinalTestOperator, value);
    }

    private string _fixtureUFx4ConfigurationId;
    public string FixtureUFx4ConfigurationId
    {
        get => _fixtureUFx4ConfigurationId;
        set => Set(ref _fixtureUFx4ConfigurationId, value);
    }

    private int? _fixtureUFx4StorageDays;
    public int? FixtureUFx4StorageDays
    {
        get => _fixtureUFx4StorageDays;
        set => Set(ref _fixtureUFx4StorageDays, value);
    }

    private string _fixtureUFx4LabApproval;
    public string FixtureUFx4LabApproval
    {
        get => _fixtureUFx4LabApproval;
        set => Set(ref _fixtureUFx4LabApproval, value);
    }

    private string _fixtureUFx4SoftwareRevision;
    public string FixtureUFx4SoftwareRevision
    {
        get => _fixtureUFx4SoftwareRevision;
        set => Set(ref _fixtureUFx4SoftwareRevision, value);
    }

    private string _fixtureUFx4RegistrationStatus;
    public string FixtureUFx4RegistrationStatus
    {
        get => _fixtureUFx4RegistrationStatus;
        set => Set(ref _fixtureUFx4RegistrationStatus, value);
    }

    private string _fixtureUF44SerialNumber;
    public string FixtureUF44SerialNumber
    {
        get => _fixtureUF44SerialNumber;
        set => Set(ref _fixtureUF44SerialNumber, value);
    }

    private string _fixtureUF44LockStatus;
    public string FixtureUF44LockStatus
    {
        get => _fixtureUF44LockStatus;
        set => Set(ref _fixtureUF44LockStatus, value);
    }

    private string _fixtureUF44Status;
    public string FixtureUF44Status
    {
        get => _fixtureUF44Status;
        set => Set(ref _fixtureUF44Status, value);
    }

    private string _fixtureUF44TestTopRevision;
    public string FixtureUF44TestTopRevision
    {
        get => _fixtureUF44TestTopRevision;
        set => Set(ref _fixtureUF44TestTopRevision, value);
    }

    private string _fixtureUF44UnlockTimeoutDisabled;
    public string FixtureUF44UnlockTimeoutDisabled
    {
        get => _fixtureUF44UnlockTimeoutDisabled;
        set => Set(ref _fixtureUF44UnlockTimeoutDisabled, value);
    }

    private string _fixtureUF44PasswordWriteEnabledE2;
    public string FixtureUF44PasswordWriteEnabledE2
    {
        get => _fixtureUF44PasswordWriteEnabledE2;
        set => Set(ref _fixtureUF44PasswordWriteEnabledE2, value);
    }

    private string _fixtureUF44SerialModeEnabledE2;
    public string FixtureUF44SerialModeEnabledE2
    {
        get => _fixtureUF44SerialModeEnabledE2;
        set => Set(ref _fixtureUF44SerialModeEnabledE2, value);
    }

    private string _fixtureUF44Timeout;
    public string FixtureUF44Timeout
    {
        get => _fixtureUF44Timeout;
        set => Set(ref _fixtureUF44Timeout, value);
    }

    private string _fixtureUF44PasswordDisplay;
    public string FixtureUF44PasswordDisplay
    {
        get => _fixtureUF44PasswordDisplay;
        set => Set(ref _fixtureUF44PasswordDisplay, value);
    }

    private ICommand _readUFx5Command;
    public ICommand ReadUFx5Command
    {
        get => _readUFx5Command;
        set => Set(ref _readUFx5Command, value);
    }

    private ICommand _releaseUFx5Command;
    public ICommand ReleaseUFx5Command
    {
        get => _releaseUFx5Command;
        set => Set(ref _releaseUFx5Command, value);
    }

    private string _physicalUFx5SerialNumber;
    public string PhysicalUFx5SerialNumber
    {
        get => _physicalUFx5SerialNumber;
        set => Set(ref _physicalUFx5SerialNumber, value);
    }

    private string _physicalUFx5MeterPartNumber;
    public string PhysicalUFx5MeterPartNumber
    {
        get => _physicalUFx5MeterPartNumber;
        set => Set(ref _physicalUFx5MeterPartNumber, value);
    }

    private string _physicalUFx5MeterCustomerId;
    public string PhysicalUFx5MeterCustomerId
    {
        get => _physicalUFx5MeterCustomerId;
        set => Set(ref _physicalUFx5MeterCustomerId, value);
    }

    private string _physicalUFx5MeterInternalId;
    public string PhysicalUFx5MeterInternalId
    {
        get => _physicalUFx5MeterInternalId;
        set => Set(ref _physicalUFx5MeterInternalId, value);
    }

    private string _physicalUFx5InternalNumber;
    public string PhysicalUFx5InternalNumber
    {
        get => _physicalUFx5InternalNumber;
        set => Set(ref _physicalUFx5InternalNumber, value);
    }

    private string _physicalUFx5ExternalSerialNumber;
    public string PhysicalUFx5ExternalSerialNumber
    {
        get => _physicalUFx5ExternalSerialNumber;
        set => Set(ref _physicalUFx5ExternalSerialNumber, value);
    }

    private string _physicalUFx5SoftwareRevision;
    public string PhysicalUFx5SoftwareRevision
    {
        get => _physicalUFx5SoftwareRevision;
        set => Set(ref _physicalUFx5SoftwareRevision, value);
    }

    private string _physicalUFx5SoftwareCrc;
    public string PhysicalUFx5SoftwareCrc
    {
        get => _physicalUFx5SoftwareCrc;
        set => Set(ref _physicalUFx5SoftwareCrc, value);
    }

    private string _physicalUFx5ProgrammingVerification;
    public string PhysicalUFx5ProgrammingVerification
    {
        get => _physicalUFx5ProgrammingVerification;
        set => Set(ref _physicalUFx5ProgrammingVerification, value);
    }

    private string _physicalUFx5WarmForwardVerification;
    public string PhysicalUFx5WarmForwardVerification
    {
        get => _physicalUFx5WarmForwardVerification;
        set => Set(ref _physicalUFx5WarmForwardVerification, value);
    }

    private string _physicalUFx5WarmReverseVerification;
    public string PhysicalUFx5WarmReverseVerification
    {
        get => _physicalUFx5WarmReverseVerification;
        set => Set(ref _physicalUFx5WarmReverseVerification, value);
    }

    private string _physicalUFx5ColdForwardVerification;
    public string PhysicalUFx5ColdForwardVerification
    {
        get => _physicalUFx5ColdForwardVerification;
        set => Set(ref _physicalUFx5ColdForwardVerification, value);
    }

    private string _physicalUFx5ExternalDesiredMeterType;
    public string PhysicalUFx5ExternalDesiredMeterType
    {
        get => _physicalUFx5ExternalDesiredMeterType;
        set => Set(ref _physicalUFx5ExternalDesiredMeterType, value);
    }

    private string _databaseUFx5InternalNumber;
    public string DatabaseUFx5InternalNumber
    {
        get => _databaseUFx5InternalNumber;
        set => Set(ref _databaseUFx5InternalNumber, value);
    }

    private string _databaseUFx5OrderNumber;
    public string DatabaseUFx5OrderNumber
    {
        get => _databaseUFx5OrderNumber;
        set => Set(ref _databaseUFx5OrderNumber, value);
    }

    private string _databaseUFx5UFSerialNumber;
    public string DatabaseUFx5UFSerialNumber
    {
        get => _databaseUFx5UFSerialNumber;
        set => Set(ref _databaseUFx5UFSerialNumber, value);
    }

    private string _databaseUFx5UFExternalSerialNumber;
    public string DatabaseUFx5UFExternalSerialNumber
    {
        get => _databaseUFx5UFExternalSerialNumber;
        set => Set(ref _databaseUFx5UFExternalSerialNumber, value);
    }

    private string _databaseUFx5TypeNumber;
    public string DatabaseUFx5TypeNumber
    {
        get => _databaseUFx5TypeNumber;
        set => Set(ref _databaseUFx5TypeNumber, value);
    }

    private string _databaseUFx5CustomerSerialNumber;
    public string DatabaseUFx5CustomerSerialNumber
    {
        get => _databaseUFx5CustomerSerialNumber;
        set => Set(ref _databaseUFx5CustomerSerialNumber, value);
    }

    private string _databaseUFx5MeterSerialNumber;
    public string DatabaseUFx5MeterSerialNumber
    {
        get => _databaseUFx5MeterSerialNumber;
        set => Set(ref _databaseUFx5MeterSerialNumber, value);
    }

    private string _databaseUFx5Number59xx;
    public string DatabaseUFx5Number59xx
    {
        get => _databaseUFx5Number59xx;
        set => Set(ref _databaseUFx5Number59xx, value);
    }

    private string _databaseUFx5MeterConfiguration;
    public string DatabaseUFx5MeterConfiguration
    {
        get => _databaseUFx5MeterConfiguration;
        set => Set(ref _databaseUFx5MeterConfiguration, value);
    }

    private DateTime? _databaseUFx5RegistrationDate;
    public DateTime? DatabaseUFx5RegistrationDate
    {
        get => _databaseUFx5RegistrationDate;
        set => Set(ref _databaseUFx5RegistrationDate, value);
    }

    private string _databaseUFx5RegisteredBy;
    public string DatabaseUFx5RegisteredBy
    {
        get => _databaseUFx5RegisteredBy;
        set => Set(ref _databaseUFx5RegisteredBy, value);
    }

    private DateTime? _databaseUFx5FinalTestDate;
    public DateTime? DatabaseUFx5FinalTestDate
    {
        get => _databaseUFx5FinalTestDate;
        set => Set(ref _databaseUFx5FinalTestDate, value);
    }

    private string _databaseUFx5FinalTestOperator;
    public string DatabaseUFx5FinalTestOperator
    {
        get => _databaseUFx5FinalTestOperator;
        set => Set(ref _databaseUFx5FinalTestOperator, value);
    }

    private string _databaseUFx5ConfigurationId;
    public string DatabaseUFx5ConfigurationId
    {
        get => _databaseUFx5ConfigurationId;
        set => Set(ref _databaseUFx5ConfigurationId, value);
    }

    private int? _databaseUFx5StorageDays;
    public int? DatabaseUFx5StorageDays
    {
        get => _databaseUFx5StorageDays;
        set => Set(ref _databaseUFx5StorageDays, value);
    }

    private string _databaseUFx5LabApproval;
    public string DatabaseUFx5LabApproval
    {
        get => _databaseUFx5LabApproval;
        set => Set(ref _databaseUFx5LabApproval, value);
    }

    private string _databaseUFx5SoftwareRevision;
    public string DatabaseUFx5SoftwareRevision
    {
        get => _databaseUFx5SoftwareRevision;
        set => Set(ref _databaseUFx5SoftwareRevision, value);
    }

    private string _databaseUFx5SoftwareCrc;
    public string DatabaseUFx5SoftwareCrc
    {
        get => _databaseUFx5SoftwareCrc;
        set => Set(ref _databaseUFx5SoftwareCrc, value);
    }

    private string _databaseUFx5RegistrationStatus;
    public string DatabaseUFx5RegistrationStatus
    {
        get => _databaseUFx5RegistrationStatus;
        set => Set(ref _databaseUFx5RegistrationStatus, value);
    }

    private string _identityCheckStatus;
    public string IdentityCheckStatus
    {
        get => _identityCheckStatus;
        set => Set(ref _identityCheckStatus, value);
    }

    private string _databaseReleaseStatus;
    public string DatabaseReleaseStatus
    {
        get => _databaseReleaseStatus;
        set => Set(ref _databaseReleaseStatus, value);
    }

    private string _iFSReleaseStatus;
    public string IFSReleaseStatus
    {
        get => _iFSReleaseStatus;
        set => Set(ref _iFSReleaseStatus, value);
    }

    private string _resetStatus;
    public string ResetStatus
    {
        get => _resetStatus;
        set => Set(ref _resetStatus, value);
    }

    private string _manualSerialNumber;
    public string ManualSerialNumber
    {
        get => _manualSerialNumber;
        set => Set(ref _manualSerialNumber, value);
    }

    private string _manualPermissionStatus;
    public string ManualPermissionStatus
    {
        get => _manualPermissionStatus;
        set => Set(ref _manualPermissionStatus, value);
    }

    private ICommand _findManualCommand;
    public ICommand FindManualCommand
    {
        get => _findManualCommand;
        set => Set(ref _findManualCommand, value);
    }

    private ICommand _releaseManualCommand;
    public ICommand ReleaseManualCommand
    {
        get => _releaseManualCommand;
        set => Set(ref _releaseManualCommand, value);
    }

    private string _manualUFx4InternalNumber;
    public string ManualUFx4InternalNumber
    {
        get => _manualUFx4InternalNumber;
        set => Set(ref _manualUFx4InternalNumber, value);
    }

    private string _manualUFx4OrderNumber;
    public string ManualUFx4OrderNumber
    {
        get => _manualUFx4OrderNumber;
        set => Set(ref _manualUFx4OrderNumber, value);
    }

    private string _manualUFx4MeterSerialNumber;
    public string ManualUFx4MeterSerialNumber
    {
        get => _manualUFx4MeterSerialNumber;
        set => Set(ref _manualUFx4MeterSerialNumber, value);
    }

    private string _manualUFx4UFSerialNumber;
    public string ManualUFx4UFSerialNumber
    {
        get => _manualUFx4UFSerialNumber;
        set => Set(ref _manualUFx4UFSerialNumber, value);
    }

    private string _manualUFx4TypeNumber;
    public string ManualUFx4TypeNumber
    {
        get => _manualUFx4TypeNumber;
        set => Set(ref _manualUFx4TypeNumber, value);
    }

    private string _manualUFx4Number59xx;
    public string ManualUFx4Number59xx
    {
        get => _manualUFx4Number59xx;
        set => Set(ref _manualUFx4Number59xx, value);
    }

    private string _manualUFx4MeterConfiguration;
    public string ManualUFx4MeterConfiguration
    {
        get => _manualUFx4MeterConfiguration;
        set => Set(ref _manualUFx4MeterConfiguration, value);
    }

    private string _manualUFx4CustomerNumber;
    public string ManualUFx4CustomerNumber
    {
        get => _manualUFx4CustomerNumber;
        set => Set(ref _manualUFx4CustomerNumber, value);
    }

    private DateTime? _manualUFx4RegistrationDate;
    public DateTime? ManualUFx4RegistrationDate
    {
        get => _manualUFx4RegistrationDate;
        set => Set(ref _manualUFx4RegistrationDate, value);
    }

    private string _manualUFx4RegisteredBy;
    public string ManualUFx4RegisteredBy
    {
        get => _manualUFx4RegisteredBy;
        set => Set(ref _manualUFx4RegisteredBy, value);
    }

    private string _manualUFx4TestType;
    public string ManualUFx4TestType
    {
        get => _manualUFx4TestType;
        set => Set(ref _manualUFx4TestType, value);
    }

    private DateTime? _manualUFx4FinalTestDate;
    public DateTime? ManualUFx4FinalTestDate
    {
        get => _manualUFx4FinalTestDate;
        set => Set(ref _manualUFx4FinalTestDate, value);
    }

    private string _manualUFx4FinalTestOperator;
    public string ManualUFx4FinalTestOperator
    {
        get => _manualUFx4FinalTestOperator;
        set => Set(ref _manualUFx4FinalTestOperator, value);
    }

    private string _manualUFx4ConfigurationId;
    public string ManualUFx4ConfigurationId
    {
        get => _manualUFx4ConfigurationId;
        set => Set(ref _manualUFx4ConfigurationId, value);
    }

    private int? _manualUFx4StorageDays;
    public int? ManualUFx4StorageDays
    {
        get => _manualUFx4StorageDays;
        set => Set(ref _manualUFx4StorageDays, value);
    }

    private string _manualUFx4LabApproval;
    public string ManualUFx4LabApproval
    {
        get => _manualUFx4LabApproval;
        set => Set(ref _manualUFx4LabApproval, value);
    }

    private string _manualUFx4SoftwareRevision;
    public string ManualUFx4SoftwareRevision
    {
        get => _manualUFx4SoftwareRevision;
        set => Set(ref _manualUFx4SoftwareRevision, value);
    }

    private string _manualUFx4RegistrationStatus;
    public string ManualUFx4RegistrationStatus
    {
        get => _manualUFx4RegistrationStatus;
        set => Set(ref _manualUFx4RegistrationStatus, value);
    }

    private string _archivedOrderNumber;
    public string ArchivedOrderNumber
    {
        get => _archivedOrderNumber;
        set => Set(ref _archivedOrderNumber, value);
    }

    private ArchivedReleaseRow _selectedArchivedOrder;
    public ArchivedReleaseRow SelectedArchivedOrder
    {
        get => _selectedArchivedOrder;
        set => Set(ref _selectedArchivedOrder, value);
    }

    private ICommand _closeCommand;
    public ICommand CloseCommand
    {
        get => _closeCommand;
        set => Set(ref _closeCommand, value);
    }

    public BindableCollection<ArchivedReleaseRow> ArchivedOrderRows { get; } = new();


    private StatusIndicatorState _cableUFx4RegistrationStatusIndicatorState;
    public StatusIndicatorState CableUFx4RegistrationStatusIndicatorState { get => _cableUFx4RegistrationStatusIndicatorState; set => Set(ref _cableUFx4RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _databaseReleaseStatusIndicatorState;
    public StatusIndicatorState DatabaseReleaseStatusIndicatorState { get => _databaseReleaseStatusIndicatorState; set => Set(ref _databaseReleaseStatusIndicatorState, value); }

    private StatusIndicatorState _databaseUFx5RegistrationStatusIndicatorState;
    public StatusIndicatorState DatabaseUFx5RegistrationStatusIndicatorState { get => _databaseUFx5RegistrationStatusIndicatorState; set => Set(ref _databaseUFx5RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _fixtureUF44LockStatusIndicatorState;
    public StatusIndicatorState FixtureUF44LockStatusIndicatorState { get => _fixtureUF44LockStatusIndicatorState; set => Set(ref _fixtureUF44LockStatusIndicatorState, value); }

    private StatusIndicatorState _fixtureUF44StatusIndicatorState;
    public StatusIndicatorState FixtureUF44StatusIndicatorState { get => _fixtureUF44StatusIndicatorState; set => Set(ref _fixtureUF44StatusIndicatorState, value); }

    private StatusIndicatorState _fixtureUFx4RegistrationStatusIndicatorState;
    public StatusIndicatorState FixtureUFx4RegistrationStatusIndicatorState { get => _fixtureUFx4RegistrationStatusIndicatorState; set => Set(ref _fixtureUFx4RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _iFSReleaseStatusIndicatorState;
    public StatusIndicatorState IFSReleaseStatusIndicatorState { get => _iFSReleaseStatusIndicatorState; set => Set(ref _iFSReleaseStatusIndicatorState, value); }

    private StatusIndicatorState _identityCheckStatusIndicatorState;
    public StatusIndicatorState IdentityCheckStatusIndicatorState { get => _identityCheckStatusIndicatorState; set => Set(ref _identityCheckStatusIndicatorState, value); }

    private StatusIndicatorState _manualPermissionStatusIndicatorState;
    public StatusIndicatorState ManualPermissionStatusIndicatorState { get => _manualPermissionStatusIndicatorState; set => Set(ref _manualPermissionStatusIndicatorState, value); }

    private StatusIndicatorState _manualUFx4RegistrationStatusIndicatorState;
    public StatusIndicatorState ManualUFx4RegistrationStatusIndicatorState { get => _manualUFx4RegistrationStatusIndicatorState; set => Set(ref _manualUFx4RegistrationStatusIndicatorState, value); }

    private StatusIndicatorState _resetStatusIndicatorState;
    public StatusIndicatorState ResetStatusIndicatorState { get => _resetStatusIndicatorState; set => Set(ref _resetStatusIndicatorState, value); }
}
