using Kamstrup.HC.NewWPF.Entities;
using Caliburn.Micro;
using System.Windows.Input;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;
using Kamstrup.HC.NewWPF.Entities.Labels;

namespace Kamstrup.HC.NewWPF.ViewModels.Service;

public sealed class BarcodeScanViewModel : WorkspaceViewModelBase
{
    public BarcodeScanViewModel()
    {
        DisplayName = "Labelkontrol";
        Icon = PackIconKind.BarcodeScan;
    }

    private string _statusMessage;
    public string StatusMessage
    {
        get => _statusMessage;
        set => Set(ref _statusMessage, value);
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex
    {
        get => _selectedTabIndex;
        set => Set(ref _selectedTabIndex, value);
    }

    private string _orderNumber;
    public string OrderNumber
    {
        get => _orderNumber;
        set => Set(ref _orderNumber, value);
    }

    private string _labelBarcode;
    public string LabelBarcode
    {
        get => _labelBarcode;
        set => Set(ref _labelBarcode, value);
    }

    private string _scanStatus;
    public string ScanStatus
    {
        get => _scanStatus;
        set => Set(ref _scanStatus, value);
    }

    private ICommand _loadLabelsCommand;
    public ICommand LoadLabelsCommand
    {
        get => _loadLabelsCommand;
        set => Set(ref _loadLabelsCommand, value);
    }

    private ICommand _scanLabelCommand;
    public ICommand ScanLabelCommand
    {
        get => _scanLabelCommand;
        set => Set(ref _scanLabelCommand, value);
    }

    private ICommand _resetScansCommand;
    public ICommand ResetScansCommand
    {
        get => _resetScansCommand;
        set => Set(ref _resetScansCommand, value);
    }

    private ICommand _confirmLabelsCommand;
    public ICommand ConfirmLabelsCommand
    {
        get => _confirmLabelsCommand;
        set => Set(ref _confirmLabelsCommand, value);
    }

    private LabelScanRow _selectedLabel;
    public LabelScanRow SelectedLabel
    {
        get => _selectedLabel;
        set => Set(ref _selectedLabel, value);
    }

    private ICommand _closeCommand;
    public ICommand CloseCommand
    {
        get => _closeCommand;
        set => Set(ref _closeCommand, value);
    }

    public BindableCollection<LabelScanRow> LabelRows { get; } = new();


    private StatusIndicatorState _scanStatusIndicatorState;
    public StatusIndicatorState ScanStatusIndicatorState { get => _scanStatusIndicatorState; set => Set(ref _scanStatusIndicatorState, value); }
}
