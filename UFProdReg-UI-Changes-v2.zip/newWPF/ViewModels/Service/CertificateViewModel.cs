using Kamstrup.HC.NewWPF.Entities;
using System;
using System.Windows.Input;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Service;

public sealed class CertificateViewModel : WorkspaceViewModelBase
{
    public CertificateViewModel()
    {
        DisplayName = "Certifikatdato";
        Icon = PackIconKind.CertificateOutline;
    }

    private string _statusMessage;
    public string StatusMessage
    {
        get => _statusMessage;
        set => Set(ref _statusMessage, value);
    }

    private int _selectedTabIndex;
    public int SelectedTabIndex
    {
        get => _selectedTabIndex;
        set => Set(ref _selectedTabIndex, value);
    }

    private string _internalNumber;
    public string InternalNumber
    {
        get => _internalNumber;
        set => Set(ref _internalNumber, value);
    }

    private DateTime? _certificateDate;
    public DateTime? CertificateDate
    {
        get => _certificateDate;
        set => Set(ref _certificateDate, value);
    }

    private DateTime? _originalVerificationDate;
    public DateTime? OriginalVerificationDate
    {
        get => _originalVerificationDate;
        set => Set(ref _originalVerificationDate, value);
    }

    private int? _ageInDays;
    public int? AgeInDays
    {
        get => _ageInDays;
        set => Set(ref _ageInDays, value);
    }

    private int? _maximumStorageDays;
    public int? MaximumStorageDays
    {
        get => _maximumStorageDays;
        set => Set(ref _maximumStorageDays, value);
    }

    private DateTime? _earliestDate;
    public DateTime? EarliestDate
    {
        get => _earliestDate;
        set => Set(ref _earliestDate, value);
    }

    private DateTime? _latestDate;
    public DateTime? LatestDate
    {
        get => _latestDate;
        set => Set(ref _latestDate, value);
    }

    private string _certificateStatus;
    public string CertificateStatus
    {
        get => _certificateStatus;
        set => Set(ref _certificateStatus, value);
    }

    private ICommand _loadCertificateCommand;
    public ICommand LoadCertificateCommand
    {
        get => _loadCertificateCommand;
        set => Set(ref _loadCertificateCommand, value);
    }

    private ICommand _confirmCertificateCommand;
    public ICommand ConfirmCertificateCommand
    {
        get => _confirmCertificateCommand;
        set => Set(ref _confirmCertificateCommand, value);
    }

    private ICommand _closeCommand;
    public ICommand CloseCommand
    {
        get => _closeCommand;
        set => Set(ref _closeCommand, value);
    }


    private StatusIndicatorState _certificateStatusIndicatorState;
    public StatusIndicatorState CertificateStatusIndicatorState { get => _certificateStatusIndicatorState; set => Set(ref _certificateStatusIndicatorState, value); }
}
