using System;
using System.Windows.Input;
using System.Windows.Media;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Systems;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Systems;

public sealed class HardwareStatusViewModel : WorkspaceViewModelBase
{
    public HardwareStatusViewModel()
    {
        DisplayName = "Hardwarestatus";
        Icon = PackIconKind.Usb;
    }

    private string _testBoxPort = string.Empty;
    public string TestBoxPort { get => _testBoxPort; set => Set(ref _testBoxPort, value); }

    private string _testBoxPortState = string.Empty;
    public string TestBoxPortState { get => _testBoxPortState; set => Set(ref _testBoxPortState, value); }

    private string _testBoxListeningState = string.Empty;
    public string TestBoxListeningState { get => _testBoxListeningState; set => Set(ref _testBoxListeningState, value); }

    private DateTime? _testBoxLastCheck;
    public DateTime? TestBoxLastCheck { get => _testBoxLastCheck; set => Set(ref _testBoxLastCheck, value); }

    private string _cable1Port = string.Empty;
    public string Cable1Port { get => _cable1Port; set => Set(ref _cable1Port, value); }

    private string _cable1PortState = string.Empty;
    public string Cable1PortState { get => _cable1PortState; set => Set(ref _cable1PortState, value); }

    private string _cable1ListeningState = string.Empty;
    public string Cable1ListeningState { get => _cable1ListeningState; set => Set(ref _cable1ListeningState, value); }

    private DateTime? _cable1LastCheck;
    public DateTime? Cable1LastCheck { get => _cable1LastCheck; set => Set(ref _cable1LastCheck, value); }

    private string _cable2Port = string.Empty;
    public string Cable2Port { get => _cable2Port; set => Set(ref _cable2Port, value); }

    private string _cable2PortState = string.Empty;
    public string Cable2PortState { get => _cable2PortState; set => Set(ref _cable2PortState, value); }

    private string _cable2ListeningState = string.Empty;
    public string Cable2ListeningState { get => _cable2ListeningState; set => Set(ref _cable2ListeningState, value); }

    private DateTime? _cable2LastCheck;
    public DateTime? Cable2LastCheck { get => _cable2LastCheck; set => Set(ref _cable2LastCheck, value); }

    private string _ufPowerState = string.Empty;
    public string UfPowerState { get => _ufPowerState; set => Set(ref _ufPowerState, value); }

    private string _testTopFirmware = string.Empty;
    public string TestTopFirmware { get => _testTopFirmware; set => Set(ref _testTopFirmware, value); }

    private string _testTopActivity = string.Empty;
    public string TestTopActivity { get => _testTopActivity; set => Set(ref _testTopActivity, value); }

    private string _io1State = string.Empty;
    public string Io1State { get => _io1State; set => Set(ref _io1State, value); }

    private string _io2State = string.Empty;
    public string Io2State { get => _io2State; set => Set(ref _io2State, value); }

    private string _io3State = string.Empty;
    public string Io3State { get => _io3State; set => Set(ref _io3State, value); }

    private string _io4State = string.Empty;
    public string Io4State { get => _io4State; set => Set(ref _io4State, value); }

    private string _io5State = string.Empty;
    public string Io5State { get => _io5State; set => Set(ref _io5State, value); }

    private string _io6State = string.Empty;
    public string Io6State { get => _io6State; set => Set(ref _io6State, value); }

    private string _scannerDevice = string.Empty;
    public string ScannerDevice { get => _scannerDevice; set => Set(ref _scannerDevice, value); }

    private string _scannerState = string.Empty;
    public string ScannerState { get => _scannerState; set => Set(ref _scannerState, value); }

    private string _scannerLastRead = string.Empty;
    public string ScannerLastRead { get => _scannerLastRead; set => Set(ref _scannerLastRead, value); }

    private string _printerUf54Name = string.Empty;
    public string PrinterUf54Name { get => _printerUf54Name; set => Set(ref _printerUf54Name, value); }

    private string _printerUf54State = string.Empty;
    public string PrinterUf54State { get => _printerUf54State; set => Set(ref _printerUf54State, value); }

    private string _printerUf34Name = string.Empty;
    public string PrinterUf34Name { get => _printerUf34Name; set => Set(ref _printerUf34Name, value); }

    private string _printerUf34State = string.Empty;
    public string PrinterUf34State { get => _printerUf34State; set => Set(ref _printerUf34State, value); }

    private string _printerUf85Name = string.Empty;
    public string PrinterUf85Name { get => _printerUf85Name; set => Set(ref _printerUf85Name, value); }

    private string _printerUf85State = string.Empty;
    public string PrinterUf85State { get => _printerUf85State; set => Set(ref _printerUf85State, value); }

    private string _printerBigFlowName = string.Empty;
    public string PrinterBigFlowName { get => _printerBigFlowName; set => Set(ref _printerBigFlowName, value); }

    private string _printerBigFlowState = string.Empty;
    public string PrinterBigFlowState { get => _printerBigFlowState; set => Set(ref _printerBigFlowState, value); }

    private string _printerContainerName = string.Empty;
    public string PrinterContainerName { get => _printerContainerName; set => Set(ref _printerContainerName, value); }

    private string _printerContainerState = string.Empty;
    public string PrinterContainerState { get => _printerContainerState; set => Set(ref _printerContainerState, value); }

    private ICommand _refreshHardwareCommand;
    public ICommand RefreshHardwareCommand { get => _refreshHardwareCommand; set => Set(ref _refreshHardwareCommand, value); }

    private ICommand _restartTestBoxCommand;
    public ICommand RestartTestBoxCommand { get => _restartTestBoxCommand; set => Set(ref _restartTestBoxCommand, value); }

    private ICommand _restartCable1Command;
    public ICommand RestartCable1Command { get => _restartCable1Command; set => Set(ref _restartCable1Command, value); }

    private ICommand _restartCable2Command;
    public ICommand RestartCable2Command { get => _restartCable2Command; set => Set(ref _restartCable2Command, value); }

    private ICommand _readIoCommand;
    public ICommand ReadIoCommand { get => _readIoCommand; set => Set(ref _readIoCommand, value); }

    private ICommand _refreshPeripheralsCommand;
    public ICommand RefreshPeripheralsCommand { get => _refreshPeripheralsCommand; set => Set(ref _refreshPeripheralsCommand, value); }


    private StatusIndicatorState _cable1ListeningStateIndicatorState;
    public StatusIndicatorState Cable1ListeningStateIndicatorState { get => _cable1ListeningStateIndicatorState; set => Set(ref _cable1ListeningStateIndicatorState, value); }

    private StatusIndicatorState _cable1PortStateIndicatorState;
    public StatusIndicatorState Cable1PortStateIndicatorState { get => _cable1PortStateIndicatorState; set => Set(ref _cable1PortStateIndicatorState, value); }

    private StatusIndicatorState _cable2ListeningStateIndicatorState;
    public StatusIndicatorState Cable2ListeningStateIndicatorState { get => _cable2ListeningStateIndicatorState; set => Set(ref _cable2ListeningStateIndicatorState, value); }

    private StatusIndicatorState _cable2PortStateIndicatorState;
    public StatusIndicatorState Cable2PortStateIndicatorState { get => _cable2PortStateIndicatorState; set => Set(ref _cable2PortStateIndicatorState, value); }

    private StatusIndicatorState _io1StateIndicatorState;
    public StatusIndicatorState Io1StateIndicatorState { get => _io1StateIndicatorState; set => Set(ref _io1StateIndicatorState, value); }

    private StatusIndicatorState _io2StateIndicatorState;
    public StatusIndicatorState Io2StateIndicatorState { get => _io2StateIndicatorState; set => Set(ref _io2StateIndicatorState, value); }

    private StatusIndicatorState _io3StateIndicatorState;
    public StatusIndicatorState Io3StateIndicatorState { get => _io3StateIndicatorState; set => Set(ref _io3StateIndicatorState, value); }

    private StatusIndicatorState _io4StateIndicatorState;
    public StatusIndicatorState Io4StateIndicatorState { get => _io4StateIndicatorState; set => Set(ref _io4StateIndicatorState, value); }

    private StatusIndicatorState _io5StateIndicatorState;
    public StatusIndicatorState Io5StateIndicatorState { get => _io5StateIndicatorState; set => Set(ref _io5StateIndicatorState, value); }

    private StatusIndicatorState _io6StateIndicatorState;
    public StatusIndicatorState Io6StateIndicatorState { get => _io6StateIndicatorState; set => Set(ref _io6StateIndicatorState, value); }

    private StatusIndicatorState _printerBigFlowStateIndicatorState;
    public StatusIndicatorState PrinterBigFlowStateIndicatorState { get => _printerBigFlowStateIndicatorState; set => Set(ref _printerBigFlowStateIndicatorState, value); }

    private StatusIndicatorState _printerContainerStateIndicatorState;
    public StatusIndicatorState PrinterContainerStateIndicatorState { get => _printerContainerStateIndicatorState; set => Set(ref _printerContainerStateIndicatorState, value); }

    private StatusIndicatorState _printerUf34StateIndicatorState;
    public StatusIndicatorState PrinterUf34StateIndicatorState { get => _printerUf34StateIndicatorState; set => Set(ref _printerUf34StateIndicatorState, value); }

    private StatusIndicatorState _printerUf54StateIndicatorState;
    public StatusIndicatorState PrinterUf54StateIndicatorState { get => _printerUf54StateIndicatorState; set => Set(ref _printerUf54StateIndicatorState, value); }

    private StatusIndicatorState _printerUf85StateIndicatorState;
    public StatusIndicatorState PrinterUf85StateIndicatorState { get => _printerUf85StateIndicatorState; set => Set(ref _printerUf85StateIndicatorState, value); }

    private StatusIndicatorState _scannerStateIndicatorState;
    public StatusIndicatorState ScannerStateIndicatorState { get => _scannerStateIndicatorState; set => Set(ref _scannerStateIndicatorState, value); }

    private StatusIndicatorState _testBoxListeningStateIndicatorState;
    public StatusIndicatorState TestBoxListeningStateIndicatorState { get => _testBoxListeningStateIndicatorState; set => Set(ref _testBoxListeningStateIndicatorState, value); }

    private StatusIndicatorState _testBoxPortStateIndicatorState;
    public StatusIndicatorState TestBoxPortStateIndicatorState { get => _testBoxPortStateIndicatorState; set => Set(ref _testBoxPortStateIndicatorState, value); }

    private StatusIndicatorState _ufPowerStateIndicatorState;
    public StatusIndicatorState UfPowerStateIndicatorState { get => _ufPowerStateIndicatorState; set => Set(ref _ufPowerStateIndicatorState, value); }
}
