using System;
using System.Windows.Input;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Systems;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Systems;

/// <summary>UI contract only. The host supplies values and commands.</summary>
public sealed class DatabaseInfoViewModel : WorkspaceViewModelBase
{
    public DatabaseInfoViewModel()
    {
        DisplayName = "Databaser og tjenester";
        Icon = PackIconKind.Database;
    }


    private string _databaseEnvironment = string.Empty;
    public string DatabaseEnvironment
    {
        get => _databaseEnvironment;
        set => Set(ref _databaseEnvironment, value);
    }

    private string _databaseConsistency = string.Empty;
    public string DatabaseConsistency
    {
        get => _databaseConsistency;
        set => Set(ref _databaseConsistency, value);
    }

    private string _serviceEnvironment = string.Empty;
    public string ServiceEnvironment
    {
        get => _serviceEnvironment;
        set => Set(ref _serviceEnvironment, value);
    }

    private string _serviceConsistency = string.Empty;
    public string ServiceConsistency
    {
        get => _serviceConsistency;
        set => Set(ref _serviceConsistency, value);
    }

    private string _prods2005ConnectionDisplay = string.Empty;
    public string Prods2005ConnectionDisplay
    {
        get => _prods2005ConnectionDisplay;
        set => Set(ref _prods2005ConnectionDisplay, value);
    }

    private string _prods2005Status = string.Empty;
    public string Prods2005Status
    {
        get => _prods2005Status;
        set => Set(ref _prods2005Status, value);
    }

    private string _montageLinje11BConnectionDisplay = string.Empty;
    public string MontageLinje11BConnectionDisplay
    {
        get => _montageLinje11BConnectionDisplay;
        set => Set(ref _montageLinje11BConnectionDisplay, value);
    }

    private string _montageLinje11BStatus = string.Empty;
    public string MontageLinje11BStatus
    {
        get => _montageLinje11BStatus;
        set => Set(ref _montageLinje11BStatus, value);
    }

    private string _flowBenchConnectionDisplay = string.Empty;
    public string FlowBenchConnectionDisplay
    {
        get => _flowBenchConnectionDisplay;
        set => Set(ref _flowBenchConnectionDisplay, value);
    }

    private string _flowBenchStatus = string.Empty;
    public string FlowBenchStatus
    {
        get => _flowBenchStatus;
        set => Set(ref _flowBenchStatus, value);
    }

    private string _uFX4ConfigConnectionDisplay = string.Empty;
    public string UFX4ConfigConnectionDisplay
    {
        get => _uFX4ConfigConnectionDisplay;
        set => Set(ref _uFX4ConfigConnectionDisplay, value);
    }

    private string _uFX4ConfigStatus = string.Empty;
    public string UFX4ConfigStatus
    {
        get => _uFX4ConfigStatus;
        set => Set(ref _uFX4ConfigStatus, value);
    }

    private string _uFX4LabelConnectionDisplay = string.Empty;
    public string UFX4LabelConnectionDisplay
    {
        get => _uFX4LabelConnectionDisplay;
        set => Set(ref _uFX4LabelConnectionDisplay, value);
    }

    private string _uFX4LabelStatus = string.Empty;
    public string UFX4LabelStatus
    {
        get => _uFX4LabelStatus;
        set => Set(ref _uFX4LabelStatus, value);
    }

    private string _mC603ConfigConnectionDisplay = string.Empty;
    public string MC603ConfigConnectionDisplay
    {
        get => _mC603ConfigConnectionDisplay;
        set => Set(ref _mC603ConfigConnectionDisplay, value);
    }

    private string _mC603ConfigStatus = string.Empty;
    public string MC603ConfigStatus
    {
        get => _mC603ConfigStatus;
        set => Set(ref _mC603ConfigStatus, value);
    }

    private string _mC603VerifConnectionDisplay = string.Empty;
    public string MC603VerifConnectionDisplay
    {
        get => _mC603VerifConnectionDisplay;
        set => Set(ref _mC603VerifConnectionDisplay, value);
    }

    private string _mC603VerifStatus = string.Empty;
    public string MC603VerifStatus
    {
        get => _mC603VerifStatus;
        set => Set(ref _mC603VerifStatus, value);
    }

    private string _mC803ConfigConnectionDisplay = string.Empty;
    public string MC803ConfigConnectionDisplay
    {
        get => _mC803ConfigConnectionDisplay;
        set => Set(ref _mC803ConfigConnectionDisplay, value);
    }

    private string _mC803ConfigStatus = string.Empty;
    public string MC803ConfigStatus
    {
        get => _mC803ConfigStatus;
        set => Set(ref _mC803ConfigStatus, value);
    }

    private string _mC803VerifConnectionDisplay = string.Empty;
    public string MC803VerifConnectionDisplay
    {
        get => _mC803VerifConnectionDisplay;
        set => Set(ref _mC803VerifConnectionDisplay, value);
    }

    private string _mC803VerifStatus = string.Empty;
    public string MC803VerifStatus
    {
        get => _mC803VerifStatus;
        set => Set(ref _mC803VerifStatus, value);
    }

    private string _moduleVerifConnectionDisplay = string.Empty;
    public string ModuleVerifConnectionDisplay
    {
        get => _moduleVerifConnectionDisplay;
        set => Set(ref _moduleVerifConnectionDisplay, value);
    }

    private string _moduleVerifStatus = string.Empty;
    public string ModuleVerifStatus
    {
        get => _moduleVerifStatus;
        set => Set(ref _moduleVerifStatus, value);
    }

    private string _uFX4VerifConnectionDisplay = string.Empty;
    public string UFX4VerifConnectionDisplay
    {
        get => _uFX4VerifConnectionDisplay;
        set => Set(ref _uFX4VerifConnectionDisplay, value);
    }

    private string _uFX4VerifStatus = string.Empty;
    public string UFX4VerifStatus
    {
        get => _uFX4VerifStatus;
        set => Set(ref _uFX4VerifStatus, value);
    }

    private string _verification2005ConnectionDisplay = string.Empty;
    public string Verification2005ConnectionDisplay
    {
        get => _verification2005ConnectionDisplay;
        set => Set(ref _verification2005ConnectionDisplay, value);
    }

    private string _verification2005Status = string.Empty;
    public string Verification2005Status
    {
        get => _verification2005Status;
        set => Set(ref _verification2005Status, value);
    }

    private string _uFX5ConfigConnectionDisplay = string.Empty;
    public string UFX5ConfigConnectionDisplay
    {
        get => _uFX5ConfigConnectionDisplay;
        set => Set(ref _uFX5ConfigConnectionDisplay, value);
    }

    private string _uFX5ConfigStatus = string.Empty;
    public string UFX5ConfigStatus
    {
        get => _uFX5ConfigStatus;
        set => Set(ref _uFX5ConfigStatus, value);
    }

    private string _uFX5VerifConnectionDisplay = string.Empty;
    public string UFX5VerifConnectionDisplay
    {
        get => _uFX5VerifConnectionDisplay;
        set => Set(ref _uFX5VerifConnectionDisplay, value);
    }

    private string _uFX5VerifStatus = string.Empty;
    public string UFX5VerifStatus
    {
        get => _uFX5VerifStatus;
        set => Set(ref _uFX5VerifStatus, value);
    }

    private string _encryptionKeysUrlDisplay = string.Empty;
    public string EncryptionKeysUrlDisplay
    {
        get => _encryptionKeysUrlDisplay;
        set => Set(ref _encryptionKeysUrlDisplay, value);
    }

    private string _encryptionKeysStatus = string.Empty;
    public string EncryptionKeysStatus
    {
        get => _encryptionKeysStatus;
        set => Set(ref _encryptionKeysStatus, value);
    }

    private string _erpIntegrationUrlDisplay = string.Empty;
    public string ErpIntegrationUrlDisplay
    {
        get => _erpIntegrationUrlDisplay;
        set => Set(ref _erpIntegrationUrlDisplay, value);
    }

    private string _erpIntegrationStatus = string.Empty;
    public string ErpIntegrationStatus
    {
        get => _erpIntegrationStatus;
        set => Set(ref _erpIntegrationStatus, value);
    }

    private string _labelDataUrlDisplay = string.Empty;
    public string LabelDataUrlDisplay
    {
        get => _labelDataUrlDisplay;
        set => Set(ref _labelDataUrlDisplay, value);
    }

    private string _labelDataStatus = string.Empty;
    public string LabelDataStatus
    {
        get => _labelDataStatus;
        set => Set(ref _labelDataStatus, value);
    }

    private ICommand _refreshCommand;
    public ICommand RefreshCommand
    {
        get => _refreshCommand;
        set => Set(ref _refreshCommand, value);
    }

    private ICommand _closeCommand;
    public ICommand CloseCommand
    {
        get => _closeCommand;
        set => Set(ref _closeCommand, value);
    }

    private StatusIndicatorState _encryptionKeysStatusIndicatorState;
    public StatusIndicatorState EncryptionKeysStatusIndicatorState { get => _encryptionKeysStatusIndicatorState; set => Set(ref _encryptionKeysStatusIndicatorState, value); }

    private StatusIndicatorState _erpIntegrationStatusIndicatorState;
    public StatusIndicatorState ErpIntegrationStatusIndicatorState { get => _erpIntegrationStatusIndicatorState; set => Set(ref _erpIntegrationStatusIndicatorState, value); }

    private StatusIndicatorState _flowBenchStatusIndicatorState;
    public StatusIndicatorState FlowBenchStatusIndicatorState { get => _flowBenchStatusIndicatorState; set => Set(ref _flowBenchStatusIndicatorState, value); }

    private StatusIndicatorState _labelDataStatusIndicatorState;
    public StatusIndicatorState LabelDataStatusIndicatorState { get => _labelDataStatusIndicatorState; set => Set(ref _labelDataStatusIndicatorState, value); }

    private StatusIndicatorState _mC603ConfigStatusIndicatorState;
    public StatusIndicatorState MC603ConfigStatusIndicatorState { get => _mC603ConfigStatusIndicatorState; set => Set(ref _mC603ConfigStatusIndicatorState, value); }

    private StatusIndicatorState _mC603VerifStatusIndicatorState;
    public StatusIndicatorState MC603VerifStatusIndicatorState { get => _mC603VerifStatusIndicatorState; set => Set(ref _mC603VerifStatusIndicatorState, value); }

    private StatusIndicatorState _mC803ConfigStatusIndicatorState;
    public StatusIndicatorState MC803ConfigStatusIndicatorState { get => _mC803ConfigStatusIndicatorState; set => Set(ref _mC803ConfigStatusIndicatorState, value); }

    private StatusIndicatorState _mC803VerifStatusIndicatorState;
    public StatusIndicatorState MC803VerifStatusIndicatorState { get => _mC803VerifStatusIndicatorState; set => Set(ref _mC803VerifStatusIndicatorState, value); }

    private StatusIndicatorState _moduleVerifStatusIndicatorState;
    public StatusIndicatorState ModuleVerifStatusIndicatorState { get => _moduleVerifStatusIndicatorState; set => Set(ref _moduleVerifStatusIndicatorState, value); }

    private StatusIndicatorState _montageLinje11BStatusIndicatorState;
    public StatusIndicatorState MontageLinje11BStatusIndicatorState { get => _montageLinje11BStatusIndicatorState; set => Set(ref _montageLinje11BStatusIndicatorState, value); }

    private StatusIndicatorState _prods2005StatusIndicatorState;
    public StatusIndicatorState Prods2005StatusIndicatorState { get => _prods2005StatusIndicatorState; set => Set(ref _prods2005StatusIndicatorState, value); }

    private StatusIndicatorState _uFX4ConfigStatusIndicatorState;
    public StatusIndicatorState UFX4ConfigStatusIndicatorState { get => _uFX4ConfigStatusIndicatorState; set => Set(ref _uFX4ConfigStatusIndicatorState, value); }

    private StatusIndicatorState _uFX4LabelStatusIndicatorState;
    public StatusIndicatorState UFX4LabelStatusIndicatorState { get => _uFX4LabelStatusIndicatorState; set => Set(ref _uFX4LabelStatusIndicatorState, value); }

    private StatusIndicatorState _uFX4VerifStatusIndicatorState;
    public StatusIndicatorState UFX4VerifStatusIndicatorState { get => _uFX4VerifStatusIndicatorState; set => Set(ref _uFX4VerifStatusIndicatorState, value); }

    private StatusIndicatorState _uFX5ConfigStatusIndicatorState;
    public StatusIndicatorState UFX5ConfigStatusIndicatorState { get => _uFX5ConfigStatusIndicatorState; set => Set(ref _uFX5ConfigStatusIndicatorState, value); }

    private StatusIndicatorState _uFX5VerifStatusIndicatorState;
    public StatusIndicatorState UFX5VerifStatusIndicatorState { get => _uFX5VerifStatusIndicatorState; set => Set(ref _uFX5VerifStatusIndicatorState, value); }

    private StatusIndicatorState _verification2005StatusIndicatorState;
    public StatusIndicatorState Verification2005StatusIndicatorState { get => _verification2005StatusIndicatorState; set => Set(ref _verification2005StatusIndicatorState, value); }
}
