using System;
using System.Windows.Input;
using System.Windows.Media;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Systems;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Systems;

public sealed class BigFlowViewModel : WorkspaceViewModelBase
{
    public BigFlowViewModel()
    {
        DisplayName = "BigFlow moduler";
        Icon = PackIconKind.Puzzle;
    }

    private string _orderNumber = string.Empty;
    public string OrderNumber { get => _orderNumber; set => Set(ref _orderNumber, value); }

    private string _orderType = string.Empty;
    public string OrderType { get => _orderType; set => Set(ref _orderType, value); }

    private string _connectionModuleRequirement = string.Empty;
    public string ConnectionModuleRequirement { get => _connectionModuleRequirement; set => Set(ref _connectionModuleRequirement, value); }

    private string _powerModuleRequirement = string.Empty;
    public string PowerModuleRequirement { get => _powerModuleRequirement; set => Set(ref _powerModuleRequirement, value); }

    private string _connectionBarcode = string.Empty;
    public string ConnectionBarcode { get => _connectionBarcode; set => Set(ref _connectionBarcode, value); }

    private string _connectionInternalNumber = string.Empty;
    public string ConnectionInternalNumber { get => _connectionInternalNumber; set => Set(ref _connectionInternalNumber, value); }

    private string _connectionPartNumber = string.Empty;
    public string ConnectionPartNumber { get => _connectionPartNumber; set => Set(ref _connectionPartNumber, value); }

    private string _connectionRevision = string.Empty;
    public string ConnectionRevision { get => _connectionRevision; set => Set(ref _connectionRevision, value); }

    private string _connectionState = string.Empty;
    public string ConnectionState { get => _connectionState; set => Set(ref _connectionState, value); }

    private string _powerBarcode = string.Empty;
    public string PowerBarcode { get => _powerBarcode; set => Set(ref _powerBarcode, value); }

    private string _powerInternalNumber = string.Empty;
    public string PowerInternalNumber { get => _powerInternalNumber; set => Set(ref _powerInternalNumber, value); }

    private string _powerPartNumber = string.Empty;
    public string PowerPartNumber { get => _powerPartNumber; set => Set(ref _powerPartNumber, value); }

    private string _powerRevision = string.Empty;
    public string PowerRevision { get => _powerRevision; set => Set(ref _powerRevision, value); }

    private string _powerState = string.Empty;
    public string PowerState { get => _powerState; set => Set(ref _powerState, value); }

    private string _modulesState = string.Empty;
    public string ModulesState { get => _modulesState; set => Set(ref _modulesState, value); }

    private string _modulesRegisteredState = string.Empty;
    public string ModulesRegisteredState { get => _modulesRegisteredState; set => Set(ref _modulesRegisteredState, value); }

    private ImageSource _connectionModuleImage;
    public ImageSource ConnectionModuleImage { get => _connectionModuleImage; set => Set(ref _connectionModuleImage, value); }

    private ImageSource _powerModuleImage;
    public ImageSource PowerModuleImage { get => _powerModuleImage; set => Set(ref _powerModuleImage, value); }

    private string _lookupInternalNumber = string.Empty;
    public string LookupInternalNumber { get => _lookupInternalNumber; set => Set(ref _lookupInternalNumber, value); }

    private string _lookupBarcode = string.Empty;
    public string LookupBarcode { get => _lookupBarcode; set => Set(ref _lookupBarcode, value); }

    private string _lookupOrder = string.Empty;
    public string LookupOrder { get => _lookupOrder; set => Set(ref _lookupOrder, value); }

    private string _lookupPartNumber = string.Empty;
    public string LookupPartNumber { get => _lookupPartNumber; set => Set(ref _lookupPartNumber, value); }

    private string _lookupRevision = string.Empty;
    public string LookupRevision { get => _lookupRevision; set => Set(ref _lookupRevision, value); }

    private string _lookupRegistrationState = string.Empty;
    public string LookupRegistrationState { get => _lookupRegistrationState; set => Set(ref _lookupRegistrationState, value); }

    private ICommand _loadOrderCommand;
    public ICommand LoadOrderCommand { get => _loadOrderCommand; set => Set(ref _loadOrderCommand, value); }

    private ICommand _checkConnectionCommand;
    public ICommand CheckConnectionCommand { get => _checkConnectionCommand; set => Set(ref _checkConnectionCommand, value); }

    private ICommand _checkPowerCommand;
    public ICommand CheckPowerCommand { get => _checkPowerCommand; set => Set(ref _checkPowerCommand, value); }

    private ICommand _clearInputsCommand;
    public ICommand ClearInputsCommand { get => _clearInputsCommand; set => Set(ref _clearInputsCommand, value); }

    private ICommand _readModuleCommand;
    public ICommand ReadModuleCommand { get => _readModuleCommand; set => Set(ref _readModuleCommand, value); }

    private ICommand _releaseModuleCommand;
    public ICommand ReleaseModuleCommand { get => _releaseModuleCommand; set => Set(ref _releaseModuleCommand, value); }


    private StatusIndicatorState _connectionStateIndicatorState;
    public StatusIndicatorState ConnectionStateIndicatorState { get => _connectionStateIndicatorState; set => Set(ref _connectionStateIndicatorState, value); }

    private StatusIndicatorState _lookupRegistrationStateIndicatorState;
    public StatusIndicatorState LookupRegistrationStateIndicatorState { get => _lookupRegistrationStateIndicatorState; set => Set(ref _lookupRegistrationStateIndicatorState, value); }

    private StatusIndicatorState _modulesRegisteredStateIndicatorState;
    public StatusIndicatorState ModulesRegisteredStateIndicatorState { get => _modulesRegisteredStateIndicatorState; set => Set(ref _modulesRegisteredStateIndicatorState, value); }

    private StatusIndicatorState _modulesStateIndicatorState;
    public StatusIndicatorState ModulesStateIndicatorState { get => _modulesStateIndicatorState; set => Set(ref _modulesStateIndicatorState, value); }

    private StatusIndicatorState _powerStateIndicatorState;
    public StatusIndicatorState PowerStateIndicatorState { get => _powerStateIndicatorState; set => Set(ref _powerStateIndicatorState, value); }
}
