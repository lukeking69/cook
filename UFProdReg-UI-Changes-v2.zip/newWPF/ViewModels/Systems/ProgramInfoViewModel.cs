using System;
using System.Windows.Input;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Systems;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Systems;

/// <summary>UI contract only. The host supplies values and commands.</summary>
public sealed class ProgramInfoViewModel : WorkspaceViewModelBase
{
    public ProgramInfoViewModel()
    {
        DisplayName = "Programinfo";
        Icon = PackIconKind.InformationOutline;
    }

    public BindableCollection<ProgramAssemblyRow> Assemblies { get; } = new();

    private string _productName = string.Empty;
    public string ProductName
    {
        get => _productName;
        set => Set(ref _productName, value);
    }

    private string _title = string.Empty;
    public string Title
    {
        get => _title;
        set => Set(ref _title, value);
    }

    private string _version = string.Empty;
    public string Version
    {
        get => _version;
        set => Set(ref _version, value);
    }

    private string _copyright = string.Empty;
    public string Copyright
    {
        get => _copyright;
        set => Set(ref _copyright, value);
    }

    private string _companyName = string.Empty;
    public string CompanyName
    {
        get => _companyName;
        set => Set(ref _companyName, value);
    }

    private string _description = string.Empty;
    public string Description
    {
        get => _description;
        set => Set(ref _description, value);
    }

    private string _runtimeVersion = string.Empty;
    public string RuntimeVersion
    {
        get => _runtimeVersion;
        set => Set(ref _runtimeVersion, value);
    }

    private string _operatingSystem = string.Empty;
    public string OperatingSystem
    {
        get => _operatingSystem;
        set => Set(ref _operatingSystem, value);
    }

    private string _processArchitecture = string.Empty;
    public string ProcessArchitecture
    {
        get => _processArchitecture;
        set => Set(ref _processArchitecture, value);
    }

    private System.Windows.Media.ImageSource _logoSource;
    public System.Windows.Media.ImageSource LogoSource
    {
        get => _logoSource;
        set => Set(ref _logoSource, value);
    }

    private ProgramAssemblyRow _selectedAssembly;
    public ProgramAssemblyRow SelectedAssembly
    {
        get => _selectedAssembly;
        set => Set(ref _selectedAssembly, value);
    }

    private ICommand _refreshCommand;
    public ICommand RefreshCommand
    {
        get => _refreshCommand;
        set => Set(ref _refreshCommand, value);
    }

    private ICommand _closeCommand;
    public ICommand CloseCommand
    {
        get => _closeCommand;
        set => Set(ref _closeCommand, value);
    }
}
