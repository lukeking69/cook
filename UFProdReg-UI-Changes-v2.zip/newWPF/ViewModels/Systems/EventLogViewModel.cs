using System;
using System.Windows.Input;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Systems;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Systems;

/// <summary>UI contract only. The host supplies values and commands.</summary>
public sealed class EventLogViewModel : WorkspaceViewModelBase
{
    public EventLogViewModel()
    {
        DisplayName = "Hændelseslog";
        Icon = PackIconKind.TextBoxSearchOutline;
    }

    public BindableCollection<LookupOption> SeverityOptions { get; } = new();
    public BindableCollection<EventLogRow> Events { get; } = new();

    private string _loadedFile = string.Empty;
    public string LoadedFile
    {
        get => _loadedFile;
        set => Set(ref _loadedFile, value);
    }

    private int? _totalEventCount;
    public int? TotalEventCount
    {
        get => _totalEventCount;
        set => Set(ref _totalEventCount, value);
    }

    private int? _visibleEventCount;
    public int? VisibleEventCount
    {
        get => _visibleEventCount;
        set => Set(ref _visibleEventCount, value);
    }

    private string _searchText = string.Empty;
    public string SearchText
    {
        get => _searchText;
        set => Set(ref _searchText, value);
    }

    private string _selectedSeverityValue = string.Empty;
    public string SelectedSeverityValue
    {
        get => _selectedSeverityValue;
        set => Set(ref _selectedSeverityValue, value);
    }

    private DateTime? _fromDate;
    public DateTime? FromDate
    {
        get => _fromDate;
        set => Set(ref _fromDate, value);
    }

    private DateTime? _toDate;
    public DateTime? ToDate
    {
        get => _toDate;
        set => Set(ref _toDate, value);
    }

    private EventLogRow _selectedEvent;
    public EventLogRow SelectedEvent
    {
        get => _selectedEvent;
        set => Set(ref _selectedEvent, value);
    }

    private ICommand _importCommand;
    public ICommand ImportCommand
    {
        get => _importCommand;
        set => Set(ref _importCommand, value);
    }

    private ICommand _filterCommand;
    public ICommand FilterCommand
    {
        get => _filterCommand;
        set => Set(ref _filterCommand, value);
    }

    private ICommand _resetFiltersCommand;
    public ICommand ResetFiltersCommand
    {
        get => _resetFiltersCommand;
        set => Set(ref _resetFiltersCommand, value);
    }

    private ICommand _exportCommand;
    public ICommand ExportCommand
    {
        get => _exportCommand;
        set => Set(ref _exportCommand, value);
    }
}
