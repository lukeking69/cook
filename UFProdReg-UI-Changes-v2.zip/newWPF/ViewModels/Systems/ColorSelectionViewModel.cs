using System;
using System.Windows.Input;
using System.Windows.Media;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Systems;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Systems;

public sealed class ColorSelectionViewModel : WorkspaceViewModelBase
{
    public ColorSelectionViewModel()
    {
        DisplayName = "Farvevalg";
        Icon = PackIconKind.Palette;
    }

    private string _colorFileName = string.Empty;
    public string ColorFileName { get => _colorFileName; set => Set(ref _colorFileName, value); }

    private int? _colorRuleCount;
    public int? ColorRuleCount { get => _colorRuleCount; set => Set(ref _colorRuleCount, value); }

    public BindableCollection<ProductColorRow> ColorRules { get; } = new();

    private ProductColorRow _selectedColorRule;
    public ProductColorRow SelectedColorRule { get => _selectedColorRule; set => Set(ref _selectedColorRule, value); }

    private ICommand _importColorsCommand;
    public ICommand ImportColorsCommand { get => _importColorsCommand; set => Set(ref _importColorsCommand, value); }

    private ICommand _editColorsCommand;
    public ICommand EditColorsCommand { get => _editColorsCommand; set => Set(ref _editColorsCommand, value); }

}
