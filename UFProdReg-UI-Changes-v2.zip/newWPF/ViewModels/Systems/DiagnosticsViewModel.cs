using System.Security;
using System.Windows.Input;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Systems;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.ViewModels.Systems;

/// <summary>
/// Explicit UI contract for the legacy technical tools. No test, simulation,
/// production operation, validation, device access or data access is performed here.
/// Values, lookup options, result rows and commands are supplied by the host.
/// </summary>
public sealed class DiagnosticsViewModel : WorkspaceViewModelBase
{
    public DiagnosticsViewModel()
    {
        DisplayName = "Tekniske værktøjer";
        Icon = PackIconKind.Wrench;
    }

    public BindableCollection<LookupOption> TestBoxAddressOptions { get; } = new();
    public BindableCollection<LookupOption> Uf44AddressOptions { get; } = new();
    public BindableCollection<CurrentReadingRow> CurrentReadings { get; } = new();
    public BindableCollection<LookupOption> InternalMeterOptions { get; } = new();

    private string _technicalAccess = string.Empty;
    public string TechnicalAccess
    {
        get => _technicalAccess;
        set => Set(ref _technicalAccess, value);
    }

    private string _testBoxAddressValue = string.Empty;
    public string TestBoxAddressValue
    {
        get => _testBoxAddressValue;
        set => Set(ref _testBoxAddressValue, value);
    }

    private string _testBoxActivity = string.Empty;
    public string TestBoxActivity
    {
        get => _testBoxActivity;
        set => Set(ref _testBoxActivity, value);
    }

    private string _testBoxLabel = string.Empty;
    public string TestBoxLabel
    {
        get => _testBoxLabel;
        set => Set(ref _testBoxLabel, value);
    }

    private string _testBoxPowerState = string.Empty;
    public string TestBoxPowerState
    {
        get => _testBoxPowerState;
        set => Set(ref _testBoxPowerState, value);
    }

    private decimal? _testBoxCurrentUa;
    public decimal? TestBoxCurrentUa
    {
        get => _testBoxCurrentUa;
        set => Set(ref _testBoxCurrentUa, value);
    }

    private string _testBoxFirmware = string.Empty;
    public string TestBoxFirmware
    {
        get => _testBoxFirmware;
        set => Set(ref _testBoxFirmware, value);
    }

    private string _testBoxComPort = string.Empty;
    public string TestBoxComPort
    {
        get => _testBoxComPort;
        set => Set(ref _testBoxComPort, value);
    }

    private string _testBoxComStatus = string.Empty;
    public string TestBoxComStatus
    {
        get => _testBoxComStatus;
        set => Set(ref _testBoxComStatus, value);
    }

    private string _testBoxListeningStatus = string.Empty;
    public string TestBoxListeningStatus
    {
        get => _testBoxListeningStatus;
        set => Set(ref _testBoxListeningStatus, value);
    }

    private ICommand _testBoxPowerUpCommand;
    public ICommand TestBoxPowerUpCommand
    {
        get => _testBoxPowerUpCommand;
        set => Set(ref _testBoxPowerUpCommand, value);
    }

    private ICommand _testBoxPowerDownCommand;
    public ICommand TestBoxPowerDownCommand
    {
        get => _testBoxPowerDownCommand;
        set => Set(ref _testBoxPowerDownCommand, value);
    }

    private ICommand _testBoxStartCurrentCommand;
    public ICommand TestBoxStartCurrentCommand
    {
        get => _testBoxStartCurrentCommand;
        set => Set(ref _testBoxStartCurrentCommand, value);
    }

    private ICommand _testBoxReadCurrentCommand;
    public ICommand TestBoxReadCurrentCommand
    {
        get => _testBoxReadCurrentCommand;
        set => Set(ref _testBoxReadCurrentCommand, value);
    }

    private ICommand _testBoxReadFirmwareCommand;
    public ICommand TestBoxReadFirmwareCommand
    {
        get => _testBoxReadFirmwareCommand;
        set => Set(ref _testBoxReadFirmwareCommand, value);
    }

    private ICommand _testBoxReadIoCommand;
    public ICommand TestBoxReadIoCommand
    {
        get => _testBoxReadIoCommand;
        set => Set(ref _testBoxReadIoCommand, value);
    }

    private ICommand _testBoxCheckTopCommand;
    public ICommand TestBoxCheckTopCommand
    {
        get => _testBoxCheckTopCommand;
        set => Set(ref _testBoxCheckTopCommand, value);
    }

    private ICommand _testBoxRestartPortCommand;
    public ICommand TestBoxRestartPortCommand
    {
        get => _testBoxRestartPortCommand;
        set => Set(ref _testBoxRestartPortCommand, value);
    }

    private string _testBoxIo1State = string.Empty;
    public string TestBoxIo1State
    {
        get => _testBoxIo1State;
        set => Set(ref _testBoxIo1State, value);
    }

    private string _testBoxIo2State = string.Empty;
    public string TestBoxIo2State
    {
        get => _testBoxIo2State;
        set => Set(ref _testBoxIo2State, value);
    }

    private string _testBoxIo3State = string.Empty;
    public string TestBoxIo3State
    {
        get => _testBoxIo3State;
        set => Set(ref _testBoxIo3State, value);
    }

    private string _testBoxIo4State = string.Empty;
    public string TestBoxIo4State
    {
        get => _testBoxIo4State;
        set => Set(ref _testBoxIo4State, value);
    }

    private string _testBoxIo5State = string.Empty;
    public string TestBoxIo5State
    {
        get => _testBoxIo5State;
        set => Set(ref _testBoxIo5State, value);
    }

    private string _testBoxIo6State = string.Empty;
    public string TestBoxIo6State
    {
        get => _testBoxIo6State;
        set => Set(ref _testBoxIo6State, value);
    }

    private string _testBoxUfx4InternalNumber = string.Empty;
    public string TestBoxUfx4InternalNumber
    {
        get => _testBoxUfx4InternalNumber;
        set => Set(ref _testBoxUfx4InternalNumber, value);
    }

    private string _testBoxUfx4Revision = string.Empty;
    public string TestBoxUfx4Revision
    {
        get => _testBoxUfx4Revision;
        set => Set(ref _testBoxUfx4Revision, value);
    }

    private string _testBoxUfx4ConfigId = string.Empty;
    public string TestBoxUfx4ConfigId
    {
        get => _testBoxUfx4ConfigId;
        set => Set(ref _testBoxUfx4ConfigId, value);
    }

    private string _testBoxUfx4Data = string.Empty;
    public string TestBoxUfx4Data
    {
        get => _testBoxUfx4Data;
        set => Set(ref _testBoxUfx4Data, value);
    }

    private ICommand _testBoxReadUfx4InternalCommand;
    public ICommand TestBoxReadUfx4InternalCommand
    {
        get => _testBoxReadUfx4InternalCommand;
        set => Set(ref _testBoxReadUfx4InternalCommand, value);
    }

    private ICommand _testBoxReadUfx4RevisionCommand;
    public ICommand TestBoxReadUfx4RevisionCommand
    {
        get => _testBoxReadUfx4RevisionCommand;
        set => Set(ref _testBoxReadUfx4RevisionCommand, value);
    }

    private ICommand _testBoxReadUfx4ConfigCommand;
    public ICommand TestBoxReadUfx4ConfigCommand
    {
        get => _testBoxReadUfx4ConfigCommand;
        set => Set(ref _testBoxReadUfx4ConfigCommand, value);
    }

    private ICommand _testBoxShowUfx4Command;
    public ICommand TestBoxShowUfx4Command
    {
        get => _testBoxShowUfx4Command;
        set => Set(ref _testBoxShowUfx4Command, value);
    }

    private string _testBoxUfx5Type = string.Empty;
    public string TestBoxUfx5Type
    {
        get => _testBoxUfx5Type;
        set => Set(ref _testBoxUfx5Type, value);
    }

    private string _testBoxUfx5InternalNumber = string.Empty;
    public string TestBoxUfx5InternalNumber
    {
        get => _testBoxUfx5InternalNumber;
        set => Set(ref _testBoxUfx5InternalNumber, value);
    }

    private string _testBoxUfx5Revision = string.Empty;
    public string TestBoxUfx5Revision
    {
        get => _testBoxUfx5Revision;
        set => Set(ref _testBoxUfx5Revision, value);
    }

    private string _testBoxUfx5ConfigId = string.Empty;
    public string TestBoxUfx5ConfigId
    {
        get => _testBoxUfx5ConfigId;
        set => Set(ref _testBoxUfx5ConfigId, value);
    }

    private string _testBoxUfx5Data = string.Empty;
    public string TestBoxUfx5Data
    {
        get => _testBoxUfx5Data;
        set => Set(ref _testBoxUfx5Data, value);
    }

    private ICommand _testBoxReadUfx5TypeCommand;
    public ICommand TestBoxReadUfx5TypeCommand
    {
        get => _testBoxReadUfx5TypeCommand;
        set => Set(ref _testBoxReadUfx5TypeCommand, value);
    }

    private ICommand _testBoxReadUfx5InternalCommand;
    public ICommand TestBoxReadUfx5InternalCommand
    {
        get => _testBoxReadUfx5InternalCommand;
        set => Set(ref _testBoxReadUfx5InternalCommand, value);
    }

    private ICommand _testBoxReadUfx5RevisionCommand;
    public ICommand TestBoxReadUfx5RevisionCommand
    {
        get => _testBoxReadUfx5RevisionCommand;
        set => Set(ref _testBoxReadUfx5RevisionCommand, value);
    }

    private ICommand _testBoxReadUfx5ConfigCommand;
    public ICommand TestBoxReadUfx5ConfigCommand
    {
        get => _testBoxReadUfx5ConfigCommand;
        set => Set(ref _testBoxReadUfx5ConfigCommand, value);
    }

    private ICommand _testBoxShowUfx5Command;
    public ICommand TestBoxShowUfx5Command
    {
        get => _testBoxShowUfx5Command;
        set => Set(ref _testBoxShowUfx5Command, value);
    }

    private SecureString _uf44SecurePassword;
    public SecureString Uf44SecurePassword
    {
        get => _uf44SecurePassword;
        set => Set(ref _uf44SecurePassword, value);
    }

    private string _uf44AddressValue = string.Empty;
    public string Uf44AddressValue
    {
        get => _uf44AddressValue;
        set => Set(ref _uf44AddressValue, value);
    }

    private string _uf44SerialNumber = string.Empty;
    public string Uf44SerialNumber
    {
        get => _uf44SerialNumber;
        set => Set(ref _uf44SerialNumber, value);
    }

    private string _uf44Activity = string.Empty;
    public string Uf44Activity
    {
        get => _uf44Activity;
        set => Set(ref _uf44Activity, value);
    }

    private ICommand _uf44ReadCommand;
    public ICommand Uf44ReadCommand
    {
        get => _uf44ReadCommand;
        set => Set(ref _uf44ReadCommand, value);
    }

    private ICommand _uf44SetSerialCommand;
    public ICommand Uf44SetSerialCommand
    {
        get => _uf44SetSerialCommand;
        set => Set(ref _uf44SetSerialCommand, value);
    }

    private ICommand _uf44SetPasswordCommand;
    public ICommand Uf44SetPasswordCommand
    {
        get => _uf44SetPasswordCommand;
        set => Set(ref _uf44SetPasswordCommand, value);
    }

    private ICommand _uf44SetAllCommand;
    public ICommand Uf44SetAllCommand
    {
        get => _uf44SetAllCommand;
        set => Set(ref _uf44SetAllCommand, value);
    }

    private ICommand _uf44WriteAllCommand;
    public ICommand Uf44WriteAllCommand
    {
        get => _uf44WriteAllCommand;
        set => Set(ref _uf44WriteAllCommand, value);
    }

    private ICommand _uf44UnlockCommand;
    public ICommand Uf44UnlockCommand
    {
        get => _uf44UnlockCommand;
        set => Set(ref _uf44UnlockCommand, value);
    }

    private ICommand _uf44LockCommand;
    public ICommand Uf44LockCommand
    {
        get => _uf44LockCommand;
        set => Set(ref _uf44LockCommand, value);
    }

    private ICommand _uf44ResetCommand;
    public ICommand Uf44ResetCommand
    {
        get => _uf44ResetCommand;
        set => Set(ref _uf44ResetCommand, value);
    }

    private ICommand _uf44ResetCountersCommand;
    public ICommand Uf44ResetCountersCommand
    {
        get => _uf44ResetCountersCommand;
        set => Set(ref _uf44ResetCountersCommand, value);
    }

    private string _uf44ReadSerialNumber = string.Empty;
    public string Uf44ReadSerialNumber
    {
        get => _uf44ReadSerialNumber;
        set => Set(ref _uf44ReadSerialNumber, value);
    }

    private string _uf44PasswordStatus = string.Empty;
    public string Uf44PasswordStatus
    {
        get => _uf44PasswordStatus;
        set => Set(ref _uf44PasswordStatus, value);
    }

    private string _uf44LockState = string.Empty;
    public string Uf44LockState
    {
        get => _uf44LockState;
        set => Set(ref _uf44LockState, value);
    }

    private string _uf44Status = string.Empty;
    public string Uf44Status
    {
        get => _uf44Status;
        set => Set(ref _uf44Status, value);
    }

    private string _uf44TestTopRevision = string.Empty;
    public string Uf44TestTopRevision
    {
        get => _uf44TestTopRevision;
        set => Set(ref _uf44TestTopRevision, value);
    }

    private string _uf44SerialModeEnabled = string.Empty;
    public string Uf44SerialModeEnabled
    {
        get => _uf44SerialModeEnabled;
        set => Set(ref _uf44SerialModeEnabled, value);
    }

    private string _uf44PasswordWriteEnabled = string.Empty;
    public string Uf44PasswordWriteEnabled
    {
        get => _uf44PasswordWriteEnabled;
        set => Set(ref _uf44PasswordWriteEnabled, value);
    }

    private string _uf44UnlockTimeoutDisabled = string.Empty;
    public string Uf44UnlockTimeoutDisabled
    {
        get => _uf44UnlockTimeoutDisabled;
        set => Set(ref _uf44UnlockTimeoutDisabled, value);
    }

    private int? _uf44TimeoutMs;
    public int? Uf44TimeoutMs
    {
        get => _uf44TimeoutMs;
        set => Set(ref _uf44TimeoutMs, value);
    }

    private string _uf44Readout = string.Empty;
    public string Uf44Readout
    {
        get => _uf44Readout;
        set => Set(ref _uf44Readout, value);
    }

    private int? _currentNumberOfReads;
    public int? CurrentNumberOfReads
    {
        get => _currentNumberOfReads;
        set => Set(ref _currentNumberOfReads, value);
    }

    private bool _currentPowerDownBetweenReads;
    public bool CurrentPowerDownBetweenReads
    {
        get => _currentPowerDownBetweenReads;
        set => Set(ref _currentPowerDownBetweenReads, value);
    }

    private string _currentActivity = string.Empty;
    public string CurrentActivity
    {
        get => _currentActivity;
        set => Set(ref _currentActivity, value);
    }

    private int? _currentConfiguredWaitMs;
    public int? CurrentConfiguredWaitMs
    {
        get => _currentConfiguredWaitMs;
        set => Set(ref _currentConfiguredWaitMs, value);
    }

    private bool _currentInrushActive;
    public bool CurrentInrushActive
    {
        get => _currentInrushActive;
        set => Set(ref _currentInrushActive, value);
    }

    private int? _currentFromMs;
    public int? CurrentFromMs
    {
        get => _currentFromMs;
        set => Set(ref _currentFromMs, value);
    }

    private int? _currentToMs;
    public int? CurrentToMs
    {
        get => _currentToMs;
        set => Set(ref _currentToMs, value);
    }

    private int? _currentStepMs;
    public int? CurrentStepMs
    {
        get => _currentStepMs;
        set => Set(ref _currentStepMs, value);
    }

    private ICommand _currentStartCommand;
    public ICommand CurrentStartCommand
    {
        get => _currentStartCommand;
        set => Set(ref _currentStartCommand, value);
    }

    private CurrentReadingRow _selectedCurrentReading;
    public CurrentReadingRow SelectedCurrentReading
    {
        get => _selectedCurrentReading;
        set => Set(ref _selectedCurrentReading, value);
    }

    private string _calibrationEquipmentName = string.Empty;
    public string CalibrationEquipmentName
    {
        get => _calibrationEquipmentName;
        set => Set(ref _calibrationEquipmentName, value);
    }

    private decimal? _calibrationCurrentUa;
    public decimal? CalibrationCurrentUa
    {
        get => _calibrationCurrentUa;
        set => Set(ref _calibrationCurrentUa, value);
    }

    private string _calibrationActivity = string.Empty;
    public string CalibrationActivity
    {
        get => _calibrationActivity;
        set => Set(ref _calibrationActivity, value);
    }

    private string _calibrationState = string.Empty;
    public string CalibrationState
    {
        get => _calibrationState;
        set => Set(ref _calibrationState, value);
    }

    private ICommand _calibrationTestCommand;
    public ICommand CalibrationTestCommand
    {
        get => _calibrationTestCommand;
        set => Set(ref _calibrationTestCommand, value);
    }

    private ICommand _calibrationCloseCommand;
    public ICommand CalibrationCloseCommand
    {
        get => _calibrationCloseCommand;
        set => Set(ref _calibrationCloseCommand, value);
    }

    private string _palettePosition = string.Empty;
    public string PalettePosition
    {
        get => _palettePosition;
        set => Set(ref _palettePosition, value);
    }

    private string _paletteOrderNumber = string.Empty;
    public string PaletteOrderNumber
    {
        get => _paletteOrderNumber;
        set => Set(ref _paletteOrderNumber, value);
    }

    private string _paletteId = string.Empty;
    public string PaletteId
    {
        get => _paletteId;
        set => Set(ref _paletteId, value);
    }

    private string _paletteSerialNumber = string.Empty;
    public string PaletteSerialNumber
    {
        get => _paletteSerialNumber;
        set => Set(ref _paletteSerialNumber, value);
    }

    private string _paletteActivity = string.Empty;
    public string PaletteActivity
    {
        get => _paletteActivity;
        set => Set(ref _paletteActivity, value);
    }

    private string _paletteErrorSupport = string.Empty;
    public string PaletteErrorSupport
    {
        get => _paletteErrorSupport;
        set => Set(ref _paletteErrorSupport, value);
    }

    private ICommand _paletteSendCommand;
    public ICommand PaletteSendCommand
    {
        get => _paletteSendCommand;
        set => Set(ref _paletteSendCommand, value);
    }

    private ICommand _paletteSendErrorCommand;
    public ICommand PaletteSendErrorCommand
    {
        get => _paletteSendErrorCommand;
        set => Set(ref _paletteSendErrorCommand, value);
    }

    private string _internalMeterValue = string.Empty;
    public string InternalMeterValue
    {
        get => _internalMeterValue;
        set => Set(ref _internalMeterValue, value);
    }

    private string _internalNumber = string.Empty;
    public string InternalNumber
    {
        get => _internalNumber;
        set => Set(ref _internalNumber, value);
    }

    private string _internalSoftwareRevision = string.Empty;
    public string InternalSoftwareRevision
    {
        get => _internalSoftwareRevision;
        set => Set(ref _internalSoftwareRevision, value);
    }

    private string _internalSimulationActivity = string.Empty;
    public string InternalSimulationActivity
    {
        get => _internalSimulationActivity;
        set => Set(ref _internalSimulationActivity, value);
    }

    private ICommand _internalSendCommand;
    public ICommand InternalSendCommand
    {
        get => _internalSendCommand;
        set => Set(ref _internalSendCommand, value);
    }

    private string _orderCacheStatus = string.Empty;
    public string OrderCacheStatus
    {
        get => _orderCacheStatus;
        set => Set(ref _orderCacheStatus, value);
    }

    private ICommand _clearOrderCacheCommand;
    public ICommand ClearOrderCacheCommand
    {
        get => _clearOrderCacheCommand;
        set => Set(ref _clearOrderCacheCommand, value);
    }

    private string _uc1Status = string.Empty;
    public string Uc1Status
    {
        get => _uc1Status;
        set => Set(ref _uc1Status, value);
    }

    private string _uc1InternalNumber = string.Empty;
    public string Uc1InternalNumber
    {
        get => _uc1InternalNumber;
        set => Set(ref _uc1InternalNumber, value);
    }

    private int? _uc1InfoWidth;
    public int? Uc1InfoWidth
    {
        get => _uc1InfoWidth;
        set => Set(ref _uc1InfoWidth, value);
    }

    private string _uc1Ufx4OrderNumber = string.Empty;
    public string Uc1Ufx4OrderNumber
    {
        get => _uc1Ufx4OrderNumber;
        set => Set(ref _uc1Ufx4OrderNumber, value);
    }

    private string _uc1Ufx4MeterSerialNumber = string.Empty;
    public string Uc1Ufx4MeterSerialNumber
    {
        get => _uc1Ufx4MeterSerialNumber;
        set => Set(ref _uc1Ufx4MeterSerialNumber, value);
    }

    private string _uc1Ufx4UfSerialNumber = string.Empty;
    public string Uc1Ufx4UfSerialNumber
    {
        get => _uc1Ufx4UfSerialNumber;
        set => Set(ref _uc1Ufx4UfSerialNumber, value);
    }

    private string _uc1Ufx4TypeNumber = string.Empty;
    public string Uc1Ufx4TypeNumber
    {
        get => _uc1Ufx4TypeNumber;
        set => Set(ref _uc1Ufx4TypeNumber, value);
    }

    private string _uc1Ufx4PartNumber59xx = string.Empty;
    public string Uc1Ufx4PartNumber59xx
    {
        get => _uc1Ufx4PartNumber59xx;
        set => Set(ref _uc1Ufx4PartNumber59xx, value);
    }

    private string _uc1Ufx4MeterConfigurationNumber = string.Empty;
    public string Uc1Ufx4MeterConfigurationNumber
    {
        get => _uc1Ufx4MeterConfigurationNumber;
        set => Set(ref _uc1Ufx4MeterConfigurationNumber, value);
    }

    private string _uc1Ufx4CustomerNumber = string.Empty;
    public string Uc1Ufx4CustomerNumber
    {
        get => _uc1Ufx4CustomerNumber;
        set => Set(ref _uc1Ufx4CustomerNumber, value);
    }

    private string _uc1Ufx4RegisteredAt = string.Empty;
    public string Uc1Ufx4RegisteredAt
    {
        get => _uc1Ufx4RegisteredAt;
        set => Set(ref _uc1Ufx4RegisteredAt, value);
    }

    private string _uc1Ufx4RegisteredBy = string.Empty;
    public string Uc1Ufx4RegisteredBy
    {
        get => _uc1Ufx4RegisteredBy;
        set => Set(ref _uc1Ufx4RegisteredBy, value);
    }

    private string _uc1Ufx4TestType = string.Empty;
    public string Uc1Ufx4TestType
    {
        get => _uc1Ufx4TestType;
        set => Set(ref _uc1Ufx4TestType, value);
    }

    private string _uc1Ufx4FinalTestDate = string.Empty;
    public string Uc1Ufx4FinalTestDate
    {
        get => _uc1Ufx4FinalTestDate;
        set => Set(ref _uc1Ufx4FinalTestDate, value);
    }

    private string _uc1Ufx4FinalTestOperator = string.Empty;
    public string Uc1Ufx4FinalTestOperator
    {
        get => _uc1Ufx4FinalTestOperator;
        set => Set(ref _uc1Ufx4FinalTestOperator, value);
    }

    private string _uc1Ufx4ConfigId = string.Empty;
    public string Uc1Ufx4ConfigId
    {
        get => _uc1Ufx4ConfigId;
        set => Set(ref _uc1Ufx4ConfigId, value);
    }

    private string _uc1Ufx4ApprovedInLab = string.Empty;
    public string Uc1Ufx4ApprovedInLab
    {
        get => _uc1Ufx4ApprovedInLab;
        set => Set(ref _uc1Ufx4ApprovedInLab, value);
    }

    private string _uc1Ufx4SoftwareRevision = string.Empty;
    public string Uc1Ufx4SoftwareRevision
    {
        get => _uc1Ufx4SoftwareRevision;
        set => Set(ref _uc1Ufx4SoftwareRevision, value);
    }

    private int? _uc1Ufx4StorageDays;
    public int? Uc1Ufx4StorageDays
    {
        get => _uc1Ufx4StorageDays;
        set => Set(ref _uc1Ufx4StorageDays, value);
    }

    private ICommand _uc1LoadInternalCommand;
    public ICommand Uc1LoadInternalCommand
    {
        get => _uc1LoadInternalCommand;
        set => Set(ref _uc1LoadInternalCommand, value);
    }

    private ICommand _uc1ClearUfx4Command;
    public ICommand Uc1ClearUfx4Command
    {
        get => _uc1ClearUfx4Command;
        set => Set(ref _uc1ClearUfx4Command, value);
    }

    private string _uc1TestActivatedPort = string.Empty;
    public string Uc1TestActivatedPort
    {
        get => _uc1TestActivatedPort;
        set => Set(ref _uc1TestActivatedPort, value);
    }

    private string _uc1TestActivatedStatus = string.Empty;
    public string Uc1TestActivatedStatus
    {
        get => _uc1TestActivatedStatus;
        set => Set(ref _uc1TestActivatedStatus, value);
    }

    private string _uc1BlackButtonState = string.Empty;
    public string Uc1BlackButtonState
    {
        get => _uc1BlackButtonState;
        set => Set(ref _uc1BlackButtonState, value);
    }

    private string _uc1GreenButtonState = string.Empty;
    public string Uc1GreenButtonState
    {
        get => _uc1GreenButtonState;
        set => Set(ref _uc1GreenButtonState, value);
    }

    private string _uc1Activation62State = string.Empty;
    public string Uc1Activation62State
    {
        get => _uc1Activation62State;
        set => Set(ref _uc1Activation62State, value);
    }

    private ICommand _uc1OpenPortCommand;
    public ICommand Uc1OpenPortCommand
    {
        get => _uc1OpenPortCommand;
        set => Set(ref _uc1OpenPortCommand, value);
    }

    private ICommand _uc1ClosePortCommand;
    public ICommand Uc1ClosePortCommand
    {
        get => _uc1ClosePortCommand;
        set => Set(ref _uc1ClosePortCommand, value);
    }

    private ICommand _uc1BlackCommand;
    public ICommand Uc1BlackCommand
    {
        get => _uc1BlackCommand;
        set => Set(ref _uc1BlackCommand, value);
    }

    private ICommand _uc1GreenCommand;
    public ICommand Uc1GreenCommand
    {
        get => _uc1GreenCommand;
        set => Set(ref _uc1GreenCommand, value);
    }

    private ICommand _uc1Activation62OnCommand;
    public ICommand Uc1Activation62OnCommand
    {
        get => _uc1Activation62OnCommand;
        set => Set(ref _uc1Activation62OnCommand, value);
    }

    private ICommand _uc1Activation62OffCommand;
    public ICommand Uc1Activation62OffCommand
    {
        get => _uc1Activation62OffCommand;
        set => Set(ref _uc1Activation62OffCommand, value);
    }

    private string _uc1WithdrawalId = string.Empty;
    public string Uc1WithdrawalId
    {
        get => _uc1WithdrawalId;
        set => Set(ref _uc1WithdrawalId, value);
    }

    private string _uc1WithdrawalStartNumber = string.Empty;
    public string Uc1WithdrawalStartNumber
    {
        get => _uc1WithdrawalStartNumber;
        set => Set(ref _uc1WithdrawalStartNumber, value);
    }

    private string _uc1WithdrawalNextNumber = string.Empty;
    public string Uc1WithdrawalNextNumber
    {
        get => _uc1WithdrawalNextNumber;
        set => Set(ref _uc1WithdrawalNextNumber, value);
    }

    private int? _uc1WithdrawalCount;
    public int? Uc1WithdrawalCount
    {
        get => _uc1WithdrawalCount;
        set => Set(ref _uc1WithdrawalCount, value);
    }

    private int? _uc1WithdrawalProducedCount;
    public int? Uc1WithdrawalProducedCount
    {
        get => _uc1WithdrawalProducedCount;
        set => Set(ref _uc1WithdrawalProducedCount, value);
    }

    private int? _uc1WithdrawalRemainingCount;
    public int? Uc1WithdrawalRemainingCount
    {
        get => _uc1WithdrawalRemainingCount;
        set => Set(ref _uc1WithdrawalRemainingCount, value);
    }

    private ICommand _uc1WithdrawalFixture1Command;
    public ICommand Uc1WithdrawalFixture1Command
    {
        get => _uc1WithdrawalFixture1Command;
        set => Set(ref _uc1WithdrawalFixture1Command, value);
    }

    private ICommand _uc1WithdrawalFixture2Command;
    public ICommand Uc1WithdrawalFixture2Command
    {
        get => _uc1WithdrawalFixture2Command;
        set => Set(ref _uc1WithdrawalFixture2Command, value);
    }

    private ICommand _uc1ClearWithdrawalCommand;
    public ICommand Uc1ClearWithdrawalCommand
    {
        get => _uc1ClearWithdrawalCommand;
        set => Set(ref _uc1ClearWithdrawalCommand, value);
    }

    private string _uc1Uf44SerialNumber = string.Empty;
    public string Uc1Uf44SerialNumber
    {
        get => _uc1Uf44SerialNumber;
        set => Set(ref _uc1Uf44SerialNumber, value);
    }

    private string _uc1Uf44PasswordStatus = string.Empty;
    public string Uc1Uf44PasswordStatus
    {
        get => _uc1Uf44PasswordStatus;
        set => Set(ref _uc1Uf44PasswordStatus, value);
    }

    private string _uc1Uf44LockState = string.Empty;
    public string Uc1Uf44LockState
    {
        get => _uc1Uf44LockState;
        set => Set(ref _uc1Uf44LockState, value);
    }

    private string _uc1Uf44Status = string.Empty;
    public string Uc1Uf44Status
    {
        get => _uc1Uf44Status;
        set => Set(ref _uc1Uf44Status, value);
    }

    private string _uc1Uf44TestTopRevision = string.Empty;
    public string Uc1Uf44TestTopRevision
    {
        get => _uc1Uf44TestTopRevision;
        set => Set(ref _uc1Uf44TestTopRevision, value);
    }

    private string _uc1Uf44SerialModeEnabled = string.Empty;
    public string Uc1Uf44SerialModeEnabled
    {
        get => _uc1Uf44SerialModeEnabled;
        set => Set(ref _uc1Uf44SerialModeEnabled, value);
    }

    private string _uc1Uf44PasswordWriteEnabled = string.Empty;
    public string Uc1Uf44PasswordWriteEnabled
    {
        get => _uc1Uf44PasswordWriteEnabled;
        set => Set(ref _uc1Uf44PasswordWriteEnabled, value);
    }

    private string _uc1Uf44UnlockTimeoutDisabled = string.Empty;
    public string Uc1Uf44UnlockTimeoutDisabled
    {
        get => _uc1Uf44UnlockTimeoutDisabled;
        set => Set(ref _uc1Uf44UnlockTimeoutDisabled, value);
    }

    private int? _uc1Uf44TimeoutMs;
    public int? Uc1Uf44TimeoutMs
    {
        get => _uc1Uf44TimeoutMs;
        set => Set(ref _uc1Uf44TimeoutMs, value);
    }

    private ICommand _uc1Uf44StubCommand;
    public ICommand Uc1Uf44StubCommand
    {
        get => _uc1Uf44StubCommand;
        set => Set(ref _uc1Uf44StubCommand, value);
    }

    private ICommand _uc1Uf44ShowFixtureCommand;
    public ICommand Uc1Uf44ShowFixtureCommand
    {
        get => _uc1Uf44ShowFixtureCommand;
        set => Set(ref _uc1Uf44ShowFixtureCommand, value);
    }

    private ICommand _uc1ClearUf44Command;
    public ICommand Uc1ClearUf44Command
    {
        get => _uc1ClearUf44Command;
        set => Set(ref _uc1ClearUf44Command, value);
    }

    private string _uc1UltraflowTypeNumber = string.Empty;
    public string Uc1UltraflowTypeNumber
    {
        get => _uc1UltraflowTypeNumber;
        set => Set(ref _uc1UltraflowTypeNumber, value);
    }

    private string _uc1UltraflowUnit = string.Empty;
    public string Uc1UltraflowUnit
    {
        get => _uc1UltraflowUnit;
        set => Set(ref _uc1UltraflowUnit, value);
    }

    private string _uc1UltraflowVerification = string.Empty;
    public string Uc1UltraflowVerification
    {
        get => _uc1UltraflowVerification;
        set => Set(ref _uc1UltraflowVerification, value);
    }

    private string _uc1UltraflowDoubleState = string.Empty;
    public string Uc1UltraflowDoubleState
    {
        get => _uc1UltraflowDoubleState;
        set => Set(ref _uc1UltraflowDoubleState, value);
    }

    private string _uc1UltraflowPosition = string.Empty;
    public string Uc1UltraflowPosition
    {
        get => _uc1UltraflowPosition;
        set => Set(ref _uc1UltraflowPosition, value);
    }

    private string _uc1UltraflowMountingStatus = string.Empty;
    public string Uc1UltraflowMountingStatus
    {
        get => _uc1UltraflowMountingStatus;
        set => Set(ref _uc1UltraflowMountingStatus, value);
    }

    private string _uc1UltraflowGwfState = string.Empty;
    public string Uc1UltraflowGwfState
    {
        get => _uc1UltraflowGwfState;
        set => Set(ref _uc1UltraflowGwfState, value);
    }

    private string _uc1UltraflowBigFlowState = string.Empty;
    public string Uc1UltraflowBigFlowState
    {
        get => _uc1UltraflowBigFlowState;
        set => Set(ref _uc1UltraflowBigFlowState, value);
    }

    private string _uc1UltraflowWithoutUfState = string.Empty;
    public string Uc1UltraflowWithoutUfState
    {
        get => _uc1UltraflowWithoutUfState;
        set => Set(ref _uc1UltraflowWithoutUfState, value);
    }

    private ICommand _uc1UltraflowStandardCommand;
    public ICommand Uc1UltraflowStandardCommand
    {
        get => _uc1UltraflowStandardCommand;
        set => Set(ref _uc1UltraflowStandardCommand, value);
    }

    private ICommand _uc1UltraflowGwfCommand;
    public ICommand Uc1UltraflowGwfCommand
    {
        get => _uc1UltraflowGwfCommand;
        set => Set(ref _uc1UltraflowGwfCommand, value);
    }

    private ICommand _uc1UltraflowSvmCommand;
    public ICommand Uc1UltraflowSvmCommand
    {
        get => _uc1UltraflowSvmCommand;
        set => Set(ref _uc1UltraflowSvmCommand, value);
    }

    private ICommand _uc1UltraflowBigFlowCommand;
    public ICommand Uc1UltraflowBigFlowCommand
    {
        get => _uc1UltraflowBigFlowCommand;
        set => Set(ref _uc1UltraflowBigFlowCommand, value);
    }

    private ICommand _uc1UltraflowWithoutUfCommand;
    public ICommand Uc1UltraflowWithoutUfCommand
    {
        get => _uc1UltraflowWithoutUfCommand;
        set => Set(ref _uc1UltraflowWithoutUfCommand, value);
    }

    private ICommand _uc1UltraflowSensorAssemblyCommand;
    public ICommand Uc1UltraflowSensorAssemblyCommand
    {
        get => _uc1UltraflowSensorAssemblyCommand;
        set => Set(ref _uc1UltraflowSensorAssemblyCommand, value);
    }

    private ICommand _uc1ClearUltraflowCommand;
    public ICommand Uc1ClearUltraflowCommand
    {
        get => _uc1ClearUltraflowCommand;
        set => Set(ref _uc1ClearUltraflowCommand, value);
    }

    private string _uc1SealMarks = string.Empty;
    public string Uc1SealMarks
    {
        get => _uc1SealMarks;
        set => Set(ref _uc1SealMarks, value);
    }

    private ICommand _uc1SetSealMarksCommand;
    public ICommand Uc1SetSealMarksCommand
    {
        get => _uc1SetSealMarksCommand;
        set => Set(ref _uc1SetSealMarksCommand, value);
    }

    private ICommand _uc1ClearSealMarksCommand;
    public ICommand Uc1ClearSealMarksCommand
    {
        get => _uc1ClearSealMarksCommand;
        set => Set(ref _uc1ClearSealMarksCommand, value);
    }

    private string _uc1OrderNumber = string.Empty;
    public string Uc1OrderNumber
    {
        get => _uc1OrderNumber;
        set => Set(ref _uc1OrderNumber, value);
    }

    private int? _uc1ProducedCount;
    public int? Uc1ProducedCount
    {
        get => _uc1ProducedCount;
        set => Set(ref _uc1ProducedCount, value);
    }

    private int? _uc1RemainingCount;
    public int? Uc1RemainingCount
    {
        get => _uc1RemainingCount;
        set => Set(ref _uc1RemainingCount, value);
    }

    private int? _uc1WithdrawalRemainingInput;
    public int? Uc1WithdrawalRemainingInput
    {
        get => _uc1WithdrawalRemainingInput;
        set => Set(ref _uc1WithdrawalRemainingInput, value);
    }

    private string _uc1OrderCustomer = string.Empty;
    public string Uc1OrderCustomer
    {
        get => _uc1OrderCustomer;
        set => Set(ref _uc1OrderCustomer, value);
    }

    private string _uc1OrderVendor = string.Empty;
    public string Uc1OrderVendor
    {
        get => _uc1OrderVendor;
        set => Set(ref _uc1OrderVendor, value);
    }

    private string _uc1OrderDeliveryDate = string.Empty;
    public string Uc1OrderDeliveryDate
    {
        get => _uc1OrderDeliveryDate;
        set => Set(ref _uc1OrderDeliveryDate, value);
    }

    private int? _uc1OrderQuantity;
    public int? Uc1OrderQuantity
    {
        get => _uc1OrderQuantity;
        set => Set(ref _uc1OrderQuantity, value);
    }

    private int? _uc1OrderProduced;
    public int? Uc1OrderProduced
    {
        get => _uc1OrderProduced;
        set => Set(ref _uc1OrderProduced, value);
    }

    private int? _uc1OrderRemaining;
    public int? Uc1OrderRemaining
    {
        get => _uc1OrderRemaining;
        set => Set(ref _uc1OrderRemaining, value);
    }

    private ICommand _uc1SetOrderCommand;
    public ICommand Uc1SetOrderCommand
    {
        get => _uc1SetOrderCommand;
        set => Set(ref _uc1SetOrderCommand, value);
    }

    private ICommand _uc1SetCountsCommand;
    public ICommand Uc1SetCountsCommand
    {
        get => _uc1SetCountsCommand;
        set => Set(ref _uc1SetCountsCommand, value);
    }

    private ICommand _uc1SetRestInWithdrawalCommand;
    public ICommand Uc1SetRestInWithdrawalCommand
    {
        get => _uc1SetRestInWithdrawalCommand;
        set => Set(ref _uc1SetRestInWithdrawalCommand, value);
    }

    private ICommand _uc1ClearOrderCommand;
    public ICommand Uc1ClearOrderCommand
    {
        get => _uc1ClearOrderCommand;
        set => Set(ref _uc1ClearOrderCommand, value);
    }

    private string _uc1MulticalTypeNumber = string.Empty;
    public string Uc1MulticalTypeNumber
    {
        get => _uc1MulticalTypeNumber;
        set => Set(ref _uc1MulticalTypeNumber, value);
    }

    private string _uc1MulticalProgramNumber = string.Empty;
    public string Uc1MulticalProgramNumber
    {
        get => _uc1MulticalProgramNumber;
        set => Set(ref _uc1MulticalProgramNumber, value);
    }

    private string _uc1MulticalConfigNumber = string.Empty;
    public string Uc1MulticalConfigNumber
    {
        get => _uc1MulticalConfigNumber;
        set => Set(ref _uc1MulticalConfigNumber, value);
    }

    private string _uc1MulticalStartSerialNumber = string.Empty;
    public string Uc1MulticalStartSerialNumber
    {
        get => _uc1MulticalStartSerialNumber;
        set => Set(ref _uc1MulticalStartSerialNumber, value);
    }

    private string _uc1MulticalCustomerLabel = string.Empty;
    public string Uc1MulticalCustomerLabel
    {
        get => _uc1MulticalCustomerLabel;
        set => Set(ref _uc1MulticalCustomerLabel, value);
    }

    private string _uc1MulticalSensorType = string.Empty;
    public string Uc1MulticalSensorType
    {
        get => _uc1MulticalSensorType;
        set => Set(ref _uc1MulticalSensorType, value);
    }

    private string _uc1MulticalSensorClass = string.Empty;
    public string Uc1MulticalSensorClass
    {
        get => _uc1MulticalSensorClass;
        set => Set(ref _uc1MulticalSensorClass, value);
    }

    private string _uc1MulticalModule1 = string.Empty;
    public string Uc1MulticalModule1
    {
        get => _uc1MulticalModule1;
        set => Set(ref _uc1MulticalModule1, value);
    }

    private string _uc1MulticalModule2 = string.Empty;
    public string Uc1MulticalModule2
    {
        get => _uc1MulticalModule2;
        set => Set(ref _uc1MulticalModule2, value);
    }

    private ICommand _uc1Multical603Command;
    public ICommand Uc1Multical603Command
    {
        get => _uc1Multical603Command;
        set => Set(ref _uc1Multical603Command, value);
    }

    private ICommand _uc1Multical062Command;
    public ICommand Uc1Multical062Command
    {
        get => _uc1Multical062Command;
        set => Set(ref _uc1Multical062Command, value);
    }

    private ICommand _uc1ClearMulticalCommand;
    public ICommand Uc1ClearMulticalCommand
    {
        get => _uc1ClearMulticalCommand;
        set => Set(ref _uc1ClearMulticalCommand, value);
    }

    private string _uc1PaletteOrderNumber = string.Empty;
    public string Uc1PaletteOrderNumber
    {
        get => _uc1PaletteOrderNumber;
        set => Set(ref _uc1PaletteOrderNumber, value);
    }

    private string _uc1PaletteCustomerNumber = string.Empty;
    public string Uc1PaletteCustomerNumber
    {
        get => _uc1PaletteCustomerNumber;
        set => Set(ref _uc1PaletteCustomerNumber, value);
    }

    private string _uc1PaletteId = string.Empty;
    public string Uc1PaletteId
    {
        get => _uc1PaletteId;
        set => Set(ref _uc1PaletteId, value);
    }

    private string _uc1PaletteSerialNumber = string.Empty;
    public string Uc1PaletteSerialNumber
    {
        get => _uc1PaletteSerialNumber;
        set => Set(ref _uc1PaletteSerialNumber, value);
    }

    private int? _uc1PaletteRemainingCount;
    public int? Uc1PaletteRemainingCount
    {
        get => _uc1PaletteRemainingCount;
        set => Set(ref _uc1PaletteRemainingCount, value);
    }

    private ICommand _uc1PaletteFixtureCommand;
    public ICommand Uc1PaletteFixtureCommand
    {
        get => _uc1PaletteFixtureCommand;
        set => Set(ref _uc1PaletteFixtureCommand, value);
    }

    private ICommand _uc1ClearPaletteCommand;
    public ICommand Uc1ClearPaletteCommand
    {
        get => _uc1ClearPaletteCommand;
        set => Set(ref _uc1ClearPaletteCommand, value);
    }

    private string _uc1Readout = string.Empty;
    public string Uc1Readout
    {
        get => _uc1Readout;
        set => Set(ref _uc1Readout, value);
    }

    private string _uc2OrderNumber = string.Empty;
    public string Uc2OrderNumber
    {
        get => _uc2OrderNumber;
        set => Set(ref _uc2OrderNumber, value);
    }

    private string _uc2ConnectionBarcode = string.Empty;
    public string Uc2ConnectionBarcode
    {
        get => _uc2ConnectionBarcode;
        set => Set(ref _uc2ConnectionBarcode, value);
    }

    private string _uc2PowerBarcode = string.Empty;
    public string Uc2PowerBarcode
    {
        get => _uc2PowerBarcode;
        set => Set(ref _uc2PowerBarcode, value);
    }

    private bool _uc2Enabled;
    public bool Uc2Enabled
    {
        get => _uc2Enabled;
        set => Set(ref _uc2Enabled, value);
    }

    private bool _uc2ShowRegistered;
    public bool Uc2ShowRegistered
    {
        get => _uc2ShowRegistered;
        set => Set(ref _uc2ShowRegistered, value);
    }

    private string _uc2ConnectionPartNumber = string.Empty;
    public string Uc2ConnectionPartNumber
    {
        get => _uc2ConnectionPartNumber;
        set => Set(ref _uc2ConnectionPartNumber, value);
    }

    private string _uc2ConnectionRevision = string.Empty;
    public string Uc2ConnectionRevision
    {
        get => _uc2ConnectionRevision;
        set => Set(ref _uc2ConnectionRevision, value);
    }

    private string _uc2PowerPartNumber = string.Empty;
    public string Uc2PowerPartNumber
    {
        get => _uc2PowerPartNumber;
        set => Set(ref _uc2PowerPartNumber, value);
    }

    private string _uc2PowerRevision = string.Empty;
    public string Uc2PowerRevision
    {
        get => _uc2PowerRevision;
        set => Set(ref _uc2PowerRevision, value);
    }

    private string _uc2RegisteredState = string.Empty;
    public string Uc2RegisteredState
    {
        get => _uc2RegisteredState;
        set => Set(ref _uc2RegisteredState, value);
    }

    private string _uc2Status = string.Empty;
    public string Uc2Status
    {
        get => _uc2Status;
        set => Set(ref _uc2Status, value);
    }

    private string _uc2Readout = string.Empty;
    public string Uc2Readout
    {
        get => _uc2Readout;
        set => Set(ref _uc2Readout, value);
    }

    private ICommand _uc2SetConnectionCommand;
    public ICommand Uc2SetConnectionCommand
    {
        get => _uc2SetConnectionCommand;
        set => Set(ref _uc2SetConnectionCommand, value);
    }

    private ICommand _uc2SetPowerCommand;
    public ICommand Uc2SetPowerCommand
    {
        get => _uc2SetPowerCommand;
        set => Set(ref _uc2SetPowerCommand, value);
    }

    private ICommand _uc2OrderWithTwoModulesCommand;
    public ICommand Uc2OrderWithTwoModulesCommand
    {
        get => _uc2OrderWithTwoModulesCommand;
        set => Set(ref _uc2OrderWithTwoModulesCommand, value);
    }

    private ICommand _uc2OrderWithConnectionCommand;
    public ICommand Uc2OrderWithConnectionCommand
    {
        get => _uc2OrderWithConnectionCommand;
        set => Set(ref _uc2OrderWithConnectionCommand, value);
    }

    private ICommand _uc2SetEnabledCommand;
    public ICommand Uc2SetEnabledCommand
    {
        get => _uc2SetEnabledCommand;
        set => Set(ref _uc2SetEnabledCommand, value);
    }

    private ICommand _uc2SetRegisteredCommand;
    public ICommand Uc2SetRegisteredCommand
    {
        get => _uc2SetRegisteredCommand;
        set => Set(ref _uc2SetRegisteredCommand, value);
    }

    private ICommand _uc2ClearCommand;
    public ICommand Uc2ClearCommand
    {
        get => _uc2ClearCommand;
        set => Set(ref _uc2ClearCommand, value);
    }

    private string _erpOrderNumber = string.Empty;
    public string ErpOrderNumber
    {
        get => _erpOrderNumber;
        set => Set(ref _erpOrderNumber, value);
    }

    private string _erpResult = string.Empty;
    public string ErpResult
    {
        get => _erpResult;
        set => Set(ref _erpResult, value);
    }

    private string _erpLegacyModelSupport = string.Empty;
    public string ErpLegacyModelSupport
    {
        get => _erpLegacyModelSupport;
        set => Set(ref _erpLegacyModelSupport, value);
    }

    private ICommand _erpReadShopOrderCommand;
    public ICommand ErpReadShopOrderCommand
    {
        get => _erpReadShopOrderCommand;
        set => Set(ref _erpReadShopOrderCommand, value);
    }

    private ICommand _erpGetUfModelCommand;
    public ICommand ErpGetUfModelCommand
    {
        get => _erpGetUfModelCommand;
        set => Set(ref _erpGetUfModelCommand, value);
    }

    private ICommand _erpGetUfModelLongCommand;
    public ICommand ErpGetUfModelLongCommand
    {
        get => _erpGetUfModelLongCommand;
        set => Set(ref _erpGetUfModelLongCommand, value);
    }

    private ICommand _erpConfiguredMeterCommand;
    public ICommand ErpConfiguredMeterCommand
    {
        get => _erpConfiguredMeterCommand;
        set => Set(ref _erpConfiguredMeterCommand, value);
    }

    private ICommand _erpModuleModelCommand;
    public ICommand ErpModuleModelCommand
    {
        get => _erpModuleModelCommand;
        set => Set(ref _erpModuleModelCommand, value);
    }

    private string _datasetUfx4InternalNumber = string.Empty;
    public string DatasetUfx4InternalNumber
    {
        get => _datasetUfx4InternalNumber;
        set => Set(ref _datasetUfx4InternalNumber, value);
    }

    private string _datasetMc603TypeNumber = string.Empty;
    public string DatasetMc603TypeNumber
    {
        get => _datasetMc603TypeNumber;
        set => Set(ref _datasetMc603TypeNumber, value);
    }

    private string _datasetMc603InternalNumber = string.Empty;
    public string DatasetMc603InternalNumber
    {
        get => _datasetMc603InternalNumber;
        set => Set(ref _datasetMc603InternalNumber, value);
    }

    private string _datasetMc803TypeNumber = string.Empty;
    public string DatasetMc803TypeNumber
    {
        get => _datasetMc803TypeNumber;
        set => Set(ref _datasetMc803TypeNumber, value);
    }

    private string _datasetMc803InternalNumber = string.Empty;
    public string DatasetMc803InternalNumber
    {
        get => _datasetMc803InternalNumber;
        set => Set(ref _datasetMc803InternalNumber, value);
    }

    private string _datasetModuleInternalNumber = string.Empty;
    public string DatasetModuleInternalNumber
    {
        get => _datasetModuleInternalNumber;
        set => Set(ref _datasetModuleInternalNumber, value);
    }

    private string _datasetResult = string.Empty;
    public string DatasetResult
    {
        get => _datasetResult;
        set => Set(ref _datasetResult, value);
    }

    private ICommand _datasetReadUfx4Command;
    public ICommand DatasetReadUfx4Command
    {
        get => _datasetReadUfx4Command;
        set => Set(ref _datasetReadUfx4Command, value);
    }

    private ICommand _datasetRead603ConfigCommand;
    public ICommand DatasetRead603ConfigCommand
    {
        get => _datasetRead603ConfigCommand;
        set => Set(ref _datasetRead603ConfigCommand, value);
    }

    private ICommand _datasetRead603VerifCommand;
    public ICommand DatasetRead603VerifCommand
    {
        get => _datasetRead603VerifCommand;
        set => Set(ref _datasetRead603VerifCommand, value);
    }

    private ICommand _datasetRead803ConfigCommand;
    public ICommand DatasetRead803ConfigCommand
    {
        get => _datasetRead803ConfigCommand;
        set => Set(ref _datasetRead803ConfigCommand, value);
    }

    private ICommand _datasetRead803VerifCommand;
    public ICommand DatasetRead803VerifCommand
    {
        get => _datasetRead803VerifCommand;
        set => Set(ref _datasetRead803VerifCommand, value);
    }

    private ICommand _datasetReadModuleVerifCommand;
    public ICommand DatasetReadModuleVerifCommand
    {
        get => _datasetReadModuleVerifCommand;
        set => Set(ref _datasetReadModuleVerifCommand, value);
    }

    private ICommand _datasetCheckSealMarksCommand;
    public ICommand DatasetCheckSealMarksCommand
    {
        get => _datasetCheckSealMarksCommand;
        set => Set(ref _datasetCheckSealMarksCommand, value);
    }

    private ICommand _validateInputsCommand;
    public ICommand ValidateInputsCommand
    {
        get => _validateInputsCommand;
        set => Set(ref _validateInputsCommand, value);
    }

    private ICommand _clearInputsCommand;
    public ICommand ClearInputsCommand
    {
        get => _clearInputsCommand;
        set => Set(ref _clearInputsCommand, value);
    }


    private StatusIndicatorState _calibrationStateIndicatorState;
    public StatusIndicatorState CalibrationStateIndicatorState { get => _calibrationStateIndicatorState; set => Set(ref _calibrationStateIndicatorState, value); }

    private StatusIndicatorState _orderCacheStatusIndicatorState;
    public StatusIndicatorState OrderCacheStatusIndicatorState { get => _orderCacheStatusIndicatorState; set => Set(ref _orderCacheStatusIndicatorState, value); }

    private StatusIndicatorState _testBoxComStatusIndicatorState;
    public StatusIndicatorState TestBoxComStatusIndicatorState { get => _testBoxComStatusIndicatorState; set => Set(ref _testBoxComStatusIndicatorState, value); }

    private StatusIndicatorState _testBoxIo1StateIndicatorState;
    public StatusIndicatorState TestBoxIo1StateIndicatorState { get => _testBoxIo1StateIndicatorState; set => Set(ref _testBoxIo1StateIndicatorState, value); }

    private StatusIndicatorState _testBoxIo2StateIndicatorState;
    public StatusIndicatorState TestBoxIo2StateIndicatorState { get => _testBoxIo2StateIndicatorState; set => Set(ref _testBoxIo2StateIndicatorState, value); }

    private StatusIndicatorState _testBoxIo3StateIndicatorState;
    public StatusIndicatorState TestBoxIo3StateIndicatorState { get => _testBoxIo3StateIndicatorState; set => Set(ref _testBoxIo3StateIndicatorState, value); }

    private StatusIndicatorState _testBoxIo4StateIndicatorState;
    public StatusIndicatorState TestBoxIo4StateIndicatorState { get => _testBoxIo4StateIndicatorState; set => Set(ref _testBoxIo4StateIndicatorState, value); }

    private StatusIndicatorState _testBoxIo5StateIndicatorState;
    public StatusIndicatorState TestBoxIo5StateIndicatorState { get => _testBoxIo5StateIndicatorState; set => Set(ref _testBoxIo5StateIndicatorState, value); }

    private StatusIndicatorState _testBoxIo6StateIndicatorState;
    public StatusIndicatorState TestBoxIo6StateIndicatorState { get => _testBoxIo6StateIndicatorState; set => Set(ref _testBoxIo6StateIndicatorState, value); }

    private StatusIndicatorState _testBoxListeningStatusIndicatorState;
    public StatusIndicatorState TestBoxListeningStatusIndicatorState { get => _testBoxListeningStatusIndicatorState; set => Set(ref _testBoxListeningStatusIndicatorState, value); }

    private StatusIndicatorState _testBoxPowerStateIndicatorState;
    public StatusIndicatorState TestBoxPowerStateIndicatorState { get => _testBoxPowerStateIndicatorState; set => Set(ref _testBoxPowerStateIndicatorState, value); }

    private StatusIndicatorState _uc1Activation62StateIndicatorState;
    public StatusIndicatorState Uc1Activation62StateIndicatorState { get => _uc1Activation62StateIndicatorState; set => Set(ref _uc1Activation62StateIndicatorState, value); }

    private StatusIndicatorState _uc1BlackButtonStateIndicatorState;
    public StatusIndicatorState Uc1BlackButtonStateIndicatorState { get => _uc1BlackButtonStateIndicatorState; set => Set(ref _uc1BlackButtonStateIndicatorState, value); }

    private StatusIndicatorState _uc1GreenButtonStateIndicatorState;
    public StatusIndicatorState Uc1GreenButtonStateIndicatorState { get => _uc1GreenButtonStateIndicatorState; set => Set(ref _uc1GreenButtonStateIndicatorState, value); }

    private StatusIndicatorState _uc1StatusIndicatorState;
    public StatusIndicatorState Uc1StatusIndicatorState { get => _uc1StatusIndicatorState; set => Set(ref _uc1StatusIndicatorState, value); }

    private StatusIndicatorState _uc1TestActivatedStatusIndicatorState;
    public StatusIndicatorState Uc1TestActivatedStatusIndicatorState { get => _uc1TestActivatedStatusIndicatorState; set => Set(ref _uc1TestActivatedStatusIndicatorState, value); }

    private StatusIndicatorState _uc1Uf44LockStateIndicatorState;
    public StatusIndicatorState Uc1Uf44LockStateIndicatorState { get => _uc1Uf44LockStateIndicatorState; set => Set(ref _uc1Uf44LockStateIndicatorState, value); }

    private StatusIndicatorState _uc1Uf44PasswordStatusIndicatorState;
    public StatusIndicatorState Uc1Uf44PasswordStatusIndicatorState { get => _uc1Uf44PasswordStatusIndicatorState; set => Set(ref _uc1Uf44PasswordStatusIndicatorState, value); }

    private StatusIndicatorState _uc1Uf44StatusIndicatorState;
    public StatusIndicatorState Uc1Uf44StatusIndicatorState { get => _uc1Uf44StatusIndicatorState; set => Set(ref _uc1Uf44StatusIndicatorState, value); }

    private StatusIndicatorState _uc1UltraflowBigFlowStateIndicatorState;
    public StatusIndicatorState Uc1UltraflowBigFlowStateIndicatorState { get => _uc1UltraflowBigFlowStateIndicatorState; set => Set(ref _uc1UltraflowBigFlowStateIndicatorState, value); }

    private StatusIndicatorState _uc1UltraflowDoubleStateIndicatorState;
    public StatusIndicatorState Uc1UltraflowDoubleStateIndicatorState { get => _uc1UltraflowDoubleStateIndicatorState; set => Set(ref _uc1UltraflowDoubleStateIndicatorState, value); }

    private StatusIndicatorState _uc1UltraflowGwfStateIndicatorState;
    public StatusIndicatorState Uc1UltraflowGwfStateIndicatorState { get => _uc1UltraflowGwfStateIndicatorState; set => Set(ref _uc1UltraflowGwfStateIndicatorState, value); }

    private StatusIndicatorState _uc1UltraflowMountingStatusIndicatorState;
    public StatusIndicatorState Uc1UltraflowMountingStatusIndicatorState { get => _uc1UltraflowMountingStatusIndicatorState; set => Set(ref _uc1UltraflowMountingStatusIndicatorState, value); }

    private StatusIndicatorState _uc1UltraflowWithoutUfStateIndicatorState;
    public StatusIndicatorState Uc1UltraflowWithoutUfStateIndicatorState { get => _uc1UltraflowWithoutUfStateIndicatorState; set => Set(ref _uc1UltraflowWithoutUfStateIndicatorState, value); }

    private StatusIndicatorState _uc2RegisteredStateIndicatorState;
    public StatusIndicatorState Uc2RegisteredStateIndicatorState { get => _uc2RegisteredStateIndicatorState; set => Set(ref _uc2RegisteredStateIndicatorState, value); }

    private StatusIndicatorState _uc2StatusIndicatorState;
    public StatusIndicatorState Uc2StatusIndicatorState { get => _uc2StatusIndicatorState; set => Set(ref _uc2StatusIndicatorState, value); }

    private StatusIndicatorState _uf44LockStateIndicatorState;
    public StatusIndicatorState Uf44LockStateIndicatorState { get => _uf44LockStateIndicatorState; set => Set(ref _uf44LockStateIndicatorState, value); }

    private StatusIndicatorState _uf44PasswordStatusIndicatorState;
    public StatusIndicatorState Uf44PasswordStatusIndicatorState { get => _uf44PasswordStatusIndicatorState; set => Set(ref _uf44PasswordStatusIndicatorState, value); }

    private StatusIndicatorState _uf44StatusIndicatorState;
    public StatusIndicatorState Uf44StatusIndicatorState { get => _uf44StatusIndicatorState; set => Set(ref _uf44StatusIndicatorState, value); }
}
