using System;
using System.Windows.Input;
using System.Windows.Media;
using Caliburn.Micro;
using Kamstrup.HC.NewWPF.Entities;
using Kamstrup.HC.NewWPF.Entities.Systems;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using MaterialDesignThemes.Wpf;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Kamstrup.HC.NewWPF.ViewModels.Systems;

public sealed class ConfigurationViewModel : WorkspaceViewModelBase
{
    public ConfigurationViewModel()
    {
        DisplayName = "Indstillinger";
        Icon = PackIconKind.Cog;
    }

    private string _databaseEnvironment = string.Empty;
    private string _databaseEnvironmentAccepted = string.Empty;
    public string DatabaseEnvironment { get => _databaseEnvironment; set { if (Set(ref _databaseEnvironment, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    public BindableCollection<LookupOption> DatabaseEnvironmentOptions { get; } = new();

    private string _equipmentName = string.Empty;
    private string _equipmentNameAccepted = string.Empty;
    public string EquipmentName { get => _equipmentName; set { if (Set(ref _equipmentName, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private int? _extractionNumber;
    private int? _extractionNumberAccepted;
    public int? ExtractionNumber { get => _extractionNumber; set { if (Set(ref _extractionNumber, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private int? _defaultExtractionCount;
    private int? _defaultExtractionCountAccepted;
    public int? DefaultExtractionCount { get => _defaultExtractionCount; set { if (Set(ref _defaultExtractionCount, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private int? _minimumAutomaticExtractionCount;
    public int? MinimumAutomaticExtractionCount { get => _minimumAutomaticExtractionCount; set => Set(ref _minimumAutomaticExtractionCount, value); }

    private int? _maximumStorageDays;
    private int? _maximumStorageDaysAccepted;
    public int? MaximumStorageDays { get => _maximumStorageDays; set { if (Set(ref _maximumStorageDays, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private int? _sealDelaySeconds;
    private int? _sealDelaySecondsAccepted;
    public int? SealDelaySeconds { get => _sealDelaySeconds; set { if (Set(ref _sealDelaySeconds, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _automaticMode;
    private bool _automaticModeAccepted;
    public bool AutomaticMode { get => _automaticMode; set { if (Set(ref _automaticMode, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private int? _varoPosition;
    private int? _varoPositionAccepted;
    public int? VaroPosition { get => _varoPosition; set { if (Set(ref _varoPosition, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _palletLockEnabled;
    private bool _palletLockEnabledAccepted;
    public bool PalletLockEnabled { get => _palletLockEnabled; set { if (Set(ref _palletLockEnabled, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _finalAssemblyEnabled;
    public bool FinalAssemblyEnabled { get => _finalAssemblyEnabled; set => Set(ref _finalAssemblyEnabled, value); }

    private bool _autoLogoutEnabled;
    private bool _autoLogoutEnabledAccepted;
    public bool AutoLogoutEnabled { get => _autoLogoutEnabled; set { if (Set(ref _autoLogoutEnabled, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private int? _autoLogoutTickMilliseconds;
    private int? _autoLogoutTickMillisecondsAccepted;
    public int? AutoLogoutTickMilliseconds { get => _autoLogoutTickMilliseconds; set { if (Set(ref _autoLogoutTickMilliseconds, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private int? _autoLogoutTickCount;
    private int? _autoLogoutTickCountAccepted;
    public int? AutoLogoutTickCount { get => _autoLogoutTickCount; set { if (Set(ref _autoLogoutTickCount, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private string _printerUf54 = string.Empty;
    private string _printerUf54Accepted = string.Empty;
    public string PrinterUf54 { get => _printerUf54; set { if (Set(ref _printerUf54, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    public BindableCollection<LookupOption> PrinterUf54Options { get; } = new();

    private string _printerUf34 = string.Empty;
    private string _printerUf34Accepted = string.Empty;
    public string PrinterUf34 { get => _printerUf34; set { if (Set(ref _printerUf34, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    public BindableCollection<LookupOption> PrinterUf34Options { get; } = new();

    private string _printerUf85 = string.Empty;
    private string _printerUf85Accepted = string.Empty;
    public string PrinterUf85 { get => _printerUf85; set { if (Set(ref _printerUf85, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    public BindableCollection<LookupOption> PrinterUf85Options { get; } = new();

    private string _printerBigFlow = string.Empty;
    private string _printerBigFlowAccepted = string.Empty;
    public string PrinterBigFlow { get => _printerBigFlow; set { if (Set(ref _printerBigFlow, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    public BindableCollection<LookupOption> PrinterBigFlowOptions { get; } = new();

    private string _printerContainer = string.Empty;
    private string _printerContainerAccepted = string.Empty;
    public string PrinterContainer { get => _printerContainer; set { if (Set(ref _printerContainer, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    public BindableCollection<LookupOption> PrinterContainerOptions { get; } = new();

    private string _cable1Port = string.Empty;
    private string _cable1PortAccepted = string.Empty;
    public string Cable1Port { get => _cable1Port; set { if (Set(ref _cable1Port, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    public BindableCollection<LookupOption> Cable1PortOptions { get; } = new();

    private string _cable2Port = string.Empty;
    private string _cable2PortAccepted = string.Empty;
    public string Cable2Port { get => _cable2Port; set { if (Set(ref _cable2Port, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    public BindableCollection<LookupOption> Cable2PortOptions { get; } = new();

    private string _testBoxPort = string.Empty;
    private string _testBoxPortAccepted = string.Empty;
    public string TestBoxPort { get => _testBoxPort; set { if (Set(ref _testBoxPort, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    public BindableCollection<LookupOption> TestBoxPortOptions { get; } = new();

    private int? _cableBaudRate;
    public int? CableBaudRate { get => _cableBaudRate; set => Set(ref _cableBaudRate, value); }

    private int? _cableTimeoutMilliseconds;
    public int? CableTimeoutMilliseconds { get => _cableTimeoutMilliseconds; set => Set(ref _cableTimeoutMilliseconds, value); }

    private int? _cableRetries;
    public int? CableRetries { get => _cableRetries; set => Set(ref _cableRetries, value); }

    private int? _testBoxBaudRate;
    public int? TestBoxBaudRate { get => _testBoxBaudRate; set => Set(ref _testBoxBaudRate, value); }

    private int? _testBoxTimeoutMilliseconds;
    public int? TestBoxTimeoutMilliseconds { get => _testBoxTimeoutMilliseconds; set => Set(ref _testBoxTimeoutMilliseconds, value); }

    private int? _testBoxRetries;
    public int? TestBoxRetries { get => _testBoxRetries; set => Set(ref _testBoxRetries, value); }

    private bool _printLabelEnabled;
    private bool _printLabelEnabledAccepted;
    public bool PrintLabelEnabled { get => _printLabelEnabled; set { if (Set(ref _printLabelEnabled, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _checkMeterEnabled;
    private bool _checkMeterEnabledAccepted;
    public bool CheckMeterEnabled { get => _checkMeterEnabled; set { if (Set(ref _checkMeterEnabled, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _showZeroQuantity;
    private bool _showZeroQuantityAccepted;
    public bool ShowZeroQuantity { get => _showZeroQuantity; set { if (Set(ref _showZeroQuantity, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _releaseMeterEnabled;
    private bool _releaseMeterEnabledAccepted;
    public bool ReleaseMeterEnabled { get => _releaseMeterEnabled; set { if (Set(ref _releaseMeterEnabled, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _filterLocationEnabled;
    private bool _filterLocationEnabledAccepted;
    public bool FilterLocationEnabled { get => _filterLocationEnabled; set { if (Set(ref _filterLocationEnabled, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _showProductImages;
    private bool _showProductImagesAccepted;
    public bool ShowProductImages { get => _showProductImages; set { if (Set(ref _showProductImages, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _eventScannerEnabled;
    private bool _eventScannerEnabledAccepted;
    public bool EventScannerEnabled { get => _eventScannerEnabled; set { if (Set(ref _eventScannerEnabled, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _checkLabelMounted;
    private bool _checkLabelMountedAccepted;
    public bool CheckLabelMounted { get => _checkLabelMounted; set { if (Set(ref _checkLabelMounted, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _printBySerialNumberEnabled;
    private bool _printBySerialNumberEnabledAccepted;
    public bool PrintBySerialNumberEnabled { get => _printBySerialNumberEnabled; set { if (Set(ref _printBySerialNumberEnabled, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _extraTiLabelEnabled;
    private bool _extraTiLabelEnabledAccepted;
    public bool ExtraTiLabelEnabled { get => _extraTiLabelEnabled; set { if (Set(ref _extraTiLabelEnabled, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _checkCurrentAboveQp40;
    public bool CheckCurrentAboveQp40 { get => _checkCurrentAboveQp40; set => Set(ref _checkCurrentAboveQp40, value); }

    private decimal? _bigFlowMinimumQp;
    private decimal? _bigFlowMinimumQpAccepted;
    public decimal? BigFlowMinimumQp { get => _bigFlowMinimumQp; set { if (Set(ref _bigFlowMinimumQp, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private decimal? _ufTestQpBoundary;
    private decimal? _ufTestQpBoundaryAccepted;
    public decimal? UfTestQpBoundary { get => _ufTestQpBoundary; set { if (Set(ref _ufTestQpBoundary, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _showProgramStart;
    private bool _showProgramStartAccepted;
    public bool ShowProgramStart { get => _showProgramStart; set { if (Set(ref _showProgramStart, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _useDefaultBarProfileRevision;
    private bool _useDefaultBarProfileRevisionAccepted;
    public bool UseDefaultBarProfileRevision { get => _useDefaultBarProfileRevision; set { if (Set(ref _useDefaultBarProfileRevision, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private string _defaultBarProfileRevision = string.Empty;
    private string _defaultBarProfileRevisionAccepted = string.Empty;
    public string DefaultBarProfileRevision { get => _defaultBarProfileRevision; set { if (Set(ref _defaultBarProfileRevision, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _useDefaultHotForgedRevision;
    private bool _useDefaultHotForgedRevisionAccepted;
    public bool UseDefaultHotForgedRevision { get => _useDefaultHotForgedRevision; set { if (Set(ref _useDefaultHotForgedRevision, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private string _defaultHotForgedRevision = string.Empty;
    private string _defaultHotForgedRevisionAccepted = string.Empty;
    public string DefaultHotForgedRevision { get => _defaultHotForgedRevision; set { if (Set(ref _defaultHotForgedRevision, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private bool _useDefaultUf44Revision;
    private bool _useDefaultUf44RevisionAccepted;
    public bool UseDefaultUf44Revision { get => _useDefaultUf44Revision; set { if (Set(ref _useDefaultUf44Revision, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private string _defaultUf44Revision = string.Empty;
    private string _defaultUf44RevisionAccepted = string.Empty;
    public string DefaultUf44Revision { get => _defaultUf44Revision; set { if (Set(ref _defaultUf44Revision, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private string _documentationFolder = string.Empty;
    private string _documentationFolderAccepted = string.Empty;
    public string DocumentationFolder { get => _documentationFolder; set { if (Set(ref _documentationFolder, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private string _productColorFolder = string.Empty;
    private string _productColorFolderAccepted = string.Empty;
    public string ProductColorFolder { get => _productColorFolder; set { if (Set(ref _productColorFolder, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private string _registrationLogFolder = string.Empty;
    private string _registrationLogFolderAccepted = string.Empty;
    public string RegistrationLogFolder { get => _registrationLogFolder; set { if (Set(ref _registrationLogFolder, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private int? _maximumLogSizeKilobytes;
    private int? _maximumLogSizeKilobytesAccepted;
    public int? MaximumLogSizeKilobytes { get => _maximumLogSizeKilobytes; set { if (Set(ref _maximumLogSizeKilobytes, value)) NotifyOfPropertyChange(nameof(HasUnsavedChanges)); } }

    private ICommand _refreshDevicesCommand;
    public ICommand RefreshDevicesCommand { get => _refreshDevicesCommand; set => Set(ref _refreshDevicesCommand, value); }

    private ICommand _browseDocumentationCommand;
    public ICommand BrowseDocumentationCommand { get => _browseDocumentationCommand; set => Set(ref _browseDocumentationCommand, value); }

    private ICommand _browseColorsCommand;
    public ICommand BrowseColorsCommand { get => _browseColorsCommand; set => Set(ref _browseColorsCommand, value); }

    private ICommand _browseLogCommand;
    public ICommand BrowseLogCommand { get => _browseLogCommand; set => Set(ref _browseLogCommand, value); }

    private ICommand _reloadCommand;
    public ICommand ReloadCommand { get => _reloadCommand; set => Set(ref _reloadCommand, value); }

    private ICommand _saveCommand;
    public ICommand SaveCommand { get => _saveCommand; set => Set(ref _saveCommand, value); }

    private ICommand _revertCommand;
    public ICommand RevertCommand { get => _revertCommand; set => Set(ref _revertCommand, value); }

    public bool HasUnsavedChanges =>
        _databaseEnvironment != _databaseEnvironmentAccepted ||
        _equipmentName != _equipmentNameAccepted ||
        _extractionNumber != _extractionNumberAccepted ||
        _defaultExtractionCount != _defaultExtractionCountAccepted ||
        _maximumStorageDays != _maximumStorageDaysAccepted ||
        _sealDelaySeconds != _sealDelaySecondsAccepted ||
        _automaticMode != _automaticModeAccepted ||
        _varoPosition != _varoPositionAccepted ||
        _palletLockEnabled != _palletLockEnabledAccepted ||
        _autoLogoutEnabled != _autoLogoutEnabledAccepted ||
        _autoLogoutTickMilliseconds != _autoLogoutTickMillisecondsAccepted ||
        _autoLogoutTickCount != _autoLogoutTickCountAccepted ||
        _printerUf54 != _printerUf54Accepted ||
        _printerUf34 != _printerUf34Accepted ||
        _printerUf85 != _printerUf85Accepted ||
        _printerBigFlow != _printerBigFlowAccepted ||
        _printerContainer != _printerContainerAccepted ||
        _cable1Port != _cable1PortAccepted ||
        _cable2Port != _cable2PortAccepted ||
        _testBoxPort != _testBoxPortAccepted ||
        _printLabelEnabled != _printLabelEnabledAccepted ||
        _checkMeterEnabled != _checkMeterEnabledAccepted ||
        _showZeroQuantity != _showZeroQuantityAccepted ||
        _releaseMeterEnabled != _releaseMeterEnabledAccepted ||
        _filterLocationEnabled != _filterLocationEnabledAccepted ||
        _showProductImages != _showProductImagesAccepted ||
        _eventScannerEnabled != _eventScannerEnabledAccepted ||
        _checkLabelMounted != _checkLabelMountedAccepted ||
        _printBySerialNumberEnabled != _printBySerialNumberEnabledAccepted ||
        _extraTiLabelEnabled != _extraTiLabelEnabledAccepted ||
        _bigFlowMinimumQp != _bigFlowMinimumQpAccepted ||
        _ufTestQpBoundary != _ufTestQpBoundaryAccepted ||
        _showProgramStart != _showProgramStartAccepted ||
        _useDefaultBarProfileRevision != _useDefaultBarProfileRevisionAccepted ||
        _defaultBarProfileRevision != _defaultBarProfileRevisionAccepted ||
        _useDefaultHotForgedRevision != _useDefaultHotForgedRevisionAccepted ||
        _defaultHotForgedRevision != _defaultHotForgedRevisionAccepted ||
        _useDefaultUf44Revision != _useDefaultUf44RevisionAccepted ||
        _defaultUf44Revision != _defaultUf44RevisionAccepted ||
        _documentationFolder != _documentationFolderAccepted ||
        _productColorFolder != _productColorFolderAccepted ||
        _registrationLogFolder != _registrationLogFolderAccepted ||
        _maximumLogSizeKilobytes != _maximumLogSizeKilobytesAccepted;

    /// <summary>The host calls this after authoritative values have been loaded or saved.</summary>
    public void AcceptChanges()
    {
        _databaseEnvironmentAccepted = _databaseEnvironment;
        _equipmentNameAccepted = _equipmentName;
        _extractionNumberAccepted = _extractionNumber;
        _defaultExtractionCountAccepted = _defaultExtractionCount;
        _maximumStorageDaysAccepted = _maximumStorageDays;
        _sealDelaySecondsAccepted = _sealDelaySeconds;
        _automaticModeAccepted = _automaticMode;
        _varoPositionAccepted = _varoPosition;
        _palletLockEnabledAccepted = _palletLockEnabled;
        _autoLogoutEnabledAccepted = _autoLogoutEnabled;
        _autoLogoutTickMillisecondsAccepted = _autoLogoutTickMilliseconds;
        _autoLogoutTickCountAccepted = _autoLogoutTickCount;
        _printerUf54Accepted = _printerUf54;
        _printerUf34Accepted = _printerUf34;
        _printerUf85Accepted = _printerUf85;
        _printerBigFlowAccepted = _printerBigFlow;
        _printerContainerAccepted = _printerContainer;
        _cable1PortAccepted = _cable1Port;
        _cable2PortAccepted = _cable2Port;
        _testBoxPortAccepted = _testBoxPort;
        _printLabelEnabledAccepted = _printLabelEnabled;
        _checkMeterEnabledAccepted = _checkMeterEnabled;
        _showZeroQuantityAccepted = _showZeroQuantity;
        _releaseMeterEnabledAccepted = _releaseMeterEnabled;
        _filterLocationEnabledAccepted = _filterLocationEnabled;
        _showProductImagesAccepted = _showProductImages;
        _eventScannerEnabledAccepted = _eventScannerEnabled;
        _checkLabelMountedAccepted = _checkLabelMounted;
        _printBySerialNumberEnabledAccepted = _printBySerialNumberEnabled;
        _extraTiLabelEnabledAccepted = _extraTiLabelEnabled;
        _bigFlowMinimumQpAccepted = _bigFlowMinimumQp;
        _ufTestQpBoundaryAccepted = _ufTestQpBoundary;
        _showProgramStartAccepted = _showProgramStart;
        _useDefaultBarProfileRevisionAccepted = _useDefaultBarProfileRevision;
        _defaultBarProfileRevisionAccepted = _defaultBarProfileRevision;
        _useDefaultHotForgedRevisionAccepted = _useDefaultHotForgedRevision;
        _defaultHotForgedRevisionAccepted = _defaultHotForgedRevision;
        _useDefaultUf44RevisionAccepted = _useDefaultUf44Revision;
        _defaultUf44RevisionAccepted = _defaultUf44Revision;
        _documentationFolderAccepted = _documentationFolder;
        _productColorFolderAccepted = _productColorFolder;
        _registrationLogFolderAccepted = _registrationLogFolder;
        _maximumLogSizeKilobytesAccepted = _maximumLogSizeKilobytes;
        NotifyOfPropertyChange(nameof(HasUnsavedChanges));
    }

    public override Task<bool> CanCloseAsync(CancellationToken cancellationToken = default)
    {
        if (!IsActive || !HasUnsavedChanges) return Task.FromResult(true);
        var result = MessageBox.Show("Du har ændringer i indstillingerne. Vil du fortsætte uden at gemme?",
            "Ikke-gemte indstillinger", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);
        return Task.FromResult(result == MessageBoxResult.Yes);
    }

}
