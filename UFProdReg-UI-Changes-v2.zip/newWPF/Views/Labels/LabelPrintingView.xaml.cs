using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Labels
{
    public partial class LabelPrintingView : UserControl
    {
        public LabelPrintingView()
        {
            InitializeComponent();
        }
    }
}
