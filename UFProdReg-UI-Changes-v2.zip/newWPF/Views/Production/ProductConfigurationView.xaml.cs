using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Production;

public partial class ProductConfigurationView : UserControl
{
    public ProductConfigurationView() { InitializeComponent(); }
}
