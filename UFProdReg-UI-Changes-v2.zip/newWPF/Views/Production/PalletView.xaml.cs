using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Production;

public partial class PalletView : UserControl
{
    public PalletView() { InitializeComponent(); }
}
