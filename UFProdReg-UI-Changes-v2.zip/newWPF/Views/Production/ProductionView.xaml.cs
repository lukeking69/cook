using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Production;

public partial class ProductionView : UserControl
{
    public ProductionView() { InitializeComponent(); }
}
