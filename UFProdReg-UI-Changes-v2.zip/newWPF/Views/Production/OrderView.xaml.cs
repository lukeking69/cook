using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Production;

public partial class OrderView : UserControl
{
    public OrderView() { InitializeComponent(); }
}
