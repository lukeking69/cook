using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Production;

public partial class ExtractionView : UserControl
{
    public ExtractionView() { InitializeComponent(); }
}
