using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Controls
{
    public partial class StepLabelView : UserControl
    {
        public StepLabelView()
        {
            InitializeComponent();
        }
    }
}
