using System.Windows;
using System.Windows.Controls;
using Kamstrup.HC.NewWPF.Entities;

namespace Kamstrup.HC.NewWPF.Views.Controls
{
    /// <summary>Presentation-only badge. The owning page supplies text and an explicit visual state.</summary>
    public partial class StatusBadgeView : UserControl
    {
        public static readonly DependencyProperty TextProperty = DependencyProperty.Register(
            nameof(Text), typeof(string), typeof(StatusBadgeView),
            new PropertyMetadata("Afventer data", null, CoerceDisplayText));
        public static readonly DependencyProperty StateProperty = DependencyProperty.Register(
            nameof(State), typeof(StatusIndicatorState), typeof(StatusBadgeView),
            new PropertyMetadata(StatusIndicatorState.Unknown));

        public string Text
        {
            get => (string)GetValue(TextProperty);
            set => SetValue(TextProperty, value);
        }
        public StatusIndicatorState State
        {
            get => (StatusIndicatorState)GetValue(StateProperty);
            set => SetValue(StateProperty, value);
        }

        public StatusBadgeView() => InitializeComponent();

        private static object CoerceDisplayText(DependencyObject owner, object value)
            => string.IsNullOrWhiteSpace(value as string) ? "Afventer data" : value;
    }
}
