﻿using System;
using System.Collections;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using MaterialDesignThemes.Wpf;

namespace Kamstrup.HC.NewWPF.Views.Controls;

public partial class MenuListBox : UserControl
{
    private bool _isSynchronizing;
    private object _pendingSelection;

    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register(nameof(ItemsSource), typeof(IEnumerable), typeof(MenuListBox), new PropertyMetadata(null, OnItemsSourceChanged));

    public static readonly DependencyProperty SelectedItemProperty =
        DependencyProperty.Register(nameof(SelectedItem), typeof(object), typeof(MenuListBox),
            new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnSelectedItemChanged));

    public static readonly DependencyProperty SelectionBackgroundProperty =
        DependencyProperty.Register(nameof(SelectionBackground), typeof(Brush), typeof(MenuListBox), new PropertyMetadata(null));

    public static readonly DependencyProperty SelectionForegroundProperty =
        DependencyProperty.Register(nameof(SelectionForeground), typeof(Brush), typeof(MenuListBox), new PropertyMetadata(null));

    public static readonly DependencyProperty SelectionBorderBrushProperty =
        DependencyProperty.Register(nameof(SelectionBorderBrush), typeof(Brush), typeof(MenuListBox), new PropertyMetadata(null));

    public MenuListBox()
    {
        InitializeComponent();
        Loaded += OnLoaded;
    }

    public IEnumerable ItemsSource
    {
        get => (IEnumerable)GetValue(ItemsSourceProperty);
        set => SetValue(ItemsSourceProperty, value);
    }

    public object SelectedItem
    {
        get => GetValue(SelectedItemProperty);
        set => SetCurrentValue(SelectedItemProperty, value);
    }

    public Brush SelectionBackground
    {
        get => (Brush)GetValue(SelectionBackgroundProperty);
        set => SetValue(SelectionBackgroundProperty, value);
    }

    public Brush SelectionForeground
    {
        get => (Brush)GetValue(SelectionForegroundProperty);
        set => SetValue(SelectionForegroundProperty, value);
    }

    public Brush SelectionBorderBrush
    {
        get => (Brush)GetValue(SelectionBorderBrushProperty);
        set => SetValue(SelectionBorderBrushProperty, value);
    }

    private static void OnItemsSourceChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
    {
        ((MenuListBox)dependencyObject).SyncSelection();
    }

    private static void OnSelectedItemChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
    {
        ((MenuListBox)dependencyObject).SyncSelection();
    }

    private void OnInnerListBoxSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_isSynchronizing)
        {
            return;
        }

        _pendingSelection = InnerListBox.SelectedItem;
        _isSynchronizing = true;
        try
        {
            InnerListBox.SelectedItem = SelectedItem;
        }
        finally
        {
            _isSynchronizing = false;
        }

        if (_pendingSelection != null && !ReferenceEquals(SelectedItem, _pendingSelection))
        {
            SelectedItem = _pendingSelection;
            _pendingSelection = null;
        }
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        SyncSelection();
    }

    private void OnMenuItemIconLoaded(object sender, RoutedEventArgs e)
    {
        UpdateMenuItemIconVisibility((PackIcon)sender);
    }

    private void OnMenuItemIconDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        UpdateMenuItemIconVisibility((PackIcon)sender);
    }

    private static void UpdateMenuItemIconVisibility(PackIcon packIcon)
    {
        object iconValue = GetIconValue(packIcon.DataContext);
        packIcon.Visibility = IsIconVisible(iconValue) ? Visibility.Visible : Visibility.Collapsed;
    }

    private static object GetIconValue(object dataContext)
    {
        if (dataContext == null)
        {
            return null;
        }

        PropertyInfo iconProperty = dataContext.GetType().GetProperty("Icon", BindingFlags.Instance | BindingFlags.Public);
        return iconProperty?.GetValue(dataContext);
    }

    private static bool IsIconVisible(object iconValue)
    {
        if (iconValue == null || iconValue == DependencyProperty.UnsetValue)
        {
            return false;
        }

        if (iconValue is string stringValue)
        {
            return !string.IsNullOrWhiteSpace(stringValue);
        }

        if (iconValue is Enum enumValue)
        {
            return Convert.ToInt32(enumValue) != 0;
        }

        return true;
    }

    private void SyncSelection()
    {
        if (InnerListBox == null)
        {
            return;
        }

        _isSynchronizing = true;
        try
        {
            if (!ReferenceEquals(InnerListBox.ItemsSource, ItemsSource))
            {
                InnerListBox.ItemsSource = ItemsSource;
            }

            if (!ReferenceEquals(InnerListBox.SelectedItem, SelectedItem))
            {
                InnerListBox.SelectedItem = SelectedItem;
            }
        }
        finally
        {
            _isSynchronizing = false;
        }
    }
}
