using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Controls
{
    public partial class StepProgressView : UserControl
    {
        public StepProgressView()
        {
            InitializeComponent();
        }
    }
}
