using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Systems;

public partial class DatabaseInfoView : UserControl
{
    public DatabaseInfoView()
    {
        InitializeComponent();
    }
}
