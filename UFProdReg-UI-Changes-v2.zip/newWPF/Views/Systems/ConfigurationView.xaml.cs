using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Systems;

public partial class ConfigurationView : UserControl
{
    public ConfigurationView() { InitializeComponent(); }
}
