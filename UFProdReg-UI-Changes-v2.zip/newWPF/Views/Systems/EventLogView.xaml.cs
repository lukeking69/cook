using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Systems;

public partial class EventLogView : UserControl
{
    public EventLogView()
    {
        InitializeComponent();
    }
}
