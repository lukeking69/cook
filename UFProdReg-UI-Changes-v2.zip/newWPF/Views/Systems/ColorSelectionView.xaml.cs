using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Systems;

public partial class ColorSelectionView : UserControl
{
    public ColorSelectionView() { InitializeComponent(); }
}
