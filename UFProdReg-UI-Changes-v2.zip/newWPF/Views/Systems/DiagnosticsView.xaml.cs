using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Systems;

public partial class DiagnosticsView : UserControl
{
    public DiagnosticsView()
    {
        InitializeComponent();
    }
}
