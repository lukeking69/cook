using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Systems;

public partial class HardwareStatusView : UserControl
{
    public HardwareStatusView() { InitializeComponent(); }
}
