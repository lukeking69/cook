using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Systems;

public partial class BigFlowView : UserControl
{
    public BigFlowView() { InitializeComponent(); }
}
