using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Systems;

public partial class ProgramInfoView : UserControl
{
    public ProgramInfoView()
    {
        InitializeComponent();
    }
}
