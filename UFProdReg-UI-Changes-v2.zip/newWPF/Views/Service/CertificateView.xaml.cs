using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Service
{
    public partial class CertificateView : UserControl
    {
        public CertificateView()
        {
            InitializeComponent();
        }
    }
}
