using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Service
{
    public partial class ModuleView : UserControl
    {
        public ModuleView()
        {
            InitializeComponent();
        }
    }
}
