using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Service
{
    public partial class MeterLookupView : UserControl
    {
        public MeterLookupView()
        {
            InitializeComponent();
        }
    }
}
