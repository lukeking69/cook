using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Service
{
    public partial class ReplacementView : UserControl
    {
        public ReplacementView()
        {
            InitializeComponent();
        }
    }
}
