using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Service
{
    public partial class RevisionView : UserControl
    {
        public RevisionView()
        {
            InitializeComponent();
        }
    }
}
