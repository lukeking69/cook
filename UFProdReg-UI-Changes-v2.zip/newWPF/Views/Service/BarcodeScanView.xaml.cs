using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Service
{
    public partial class BarcodeScanView : UserControl
    {
        public BarcodeScanView()
        {
            InitializeComponent();
        }
    }
}
