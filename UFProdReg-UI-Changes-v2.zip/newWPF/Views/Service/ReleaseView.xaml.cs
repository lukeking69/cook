using System.Windows.Controls;

namespace Kamstrup.HC.NewWPF.Views.Service
{
    public partial class ReleaseView : UserControl
    {
        public ReleaseView()
        {
            InitializeComponent();
        }
    }
}
