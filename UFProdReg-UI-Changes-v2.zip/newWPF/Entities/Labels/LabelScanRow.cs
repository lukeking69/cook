namespace Kamstrup.HC.NewWPF.Entities.Labels;

public sealed class LabelScanRow
{
    public string PartNumber { get; set; }
    public string Revision { get; set; }
    public int? ExpectedCount { get; set; }
    public int? ScannedCount { get; set; }
    public string Description { get; set; }
}
