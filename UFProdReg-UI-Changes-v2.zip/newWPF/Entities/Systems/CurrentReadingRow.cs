using System;

namespace Kamstrup.HC.NewWPF.Entities.Systems;

/// <summary>Presentation data supplied by the host; contains no workflow logic.</summary>
public sealed class CurrentReadingRow
{
    public int? Count { get; set; }
    public decimal? CurrentUa { get; set; }
}
