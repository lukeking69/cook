using Kamstrup.HC.NewWPF.Entities;
using System;

namespace Kamstrup.HC.NewWPF.Entities.Systems;

/// <summary>Presentation data supplied by the host; contains no workflow logic.</summary>
public sealed class ProgramAssemblyRow
{
    public string Name { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Version { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public StatusIndicatorState StatusIndicatorState { get; set; }
}
