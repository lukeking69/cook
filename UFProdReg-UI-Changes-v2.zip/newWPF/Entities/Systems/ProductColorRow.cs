namespace Kamstrup.HC.NewWPF.Entities.Systems;

public sealed class ProductColorRow
{
    public string ArticlePattern { get; set; } = string.Empty;
    public string ColorName { get; set; } = string.Empty;
}
