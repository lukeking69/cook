using System;

namespace Kamstrup.HC.NewWPF.Entities.Systems;

/// <summary>Presentation data supplied by the host; contains no workflow logic.</summary>
public sealed class EventLogRow
{
    public string Timestamp { get; set; } = string.Empty;
    public DateTime? Date { get; set; }
    public string Severity { get; set; } = string.Empty;
    public string Source { get; set; } = string.Empty;
    public string OrderNumber { get; set; } = string.Empty;
    public string SerialNumber { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
}
