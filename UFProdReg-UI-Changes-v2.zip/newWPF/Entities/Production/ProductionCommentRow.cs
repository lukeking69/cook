using System;

namespace Kamstrup.HC.NewWPF.Entities.Production;

public sealed class ProductionCommentRow
{
    public DateTime? OccurredAt { get; set; }
    public string Instance { get; set; }
    public string Description { get; set; }
}
