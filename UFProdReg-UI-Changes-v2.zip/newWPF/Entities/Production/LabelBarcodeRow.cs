using System;

namespace Kamstrup.HC.NewWPF.Entities.Production;

public sealed class LabelBarcodeRow
{
    public string LabelName { get; set; }
    public string ExpectedBarcode { get; set; }
    public string ScannedBarcode { get; set; }
    public string Status { get; set; }
}
