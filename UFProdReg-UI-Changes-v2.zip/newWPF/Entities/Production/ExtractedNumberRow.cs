using System;

namespace Kamstrup.HC.NewWPF.Entities.Production;

public sealed class ExtractedNumberRow
{
    public string SerialNumber { get; set; }
    public string ExtractionNumber { get; set; }
    public string Status { get; set; }
}
