using System;

namespace Kamstrup.HC.NewWPF.Entities.Production;

public sealed class PalletEventRow
{
    public DateTime? OccurredAt { get; set; }
    public string PalletId { get; set; }
    public string OrderNumber { get; set; }
    public string Sequence { get; set; }
    public string Operator { get; set; }
    public string Action { get; set; }
    public string Result { get; set; }
}
