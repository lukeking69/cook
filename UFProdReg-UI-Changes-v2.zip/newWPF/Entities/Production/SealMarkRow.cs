using System;

namespace Kamstrup.HC.NewWPF.Entities.Production;

public sealed class SealMarkRow
{
    public string PartNumber { get; set; }
    public string Description { get; set; }
    public DateTime? ValidFrom { get; set; }
    public DateTime? ValidTo { get; set; }
    public byte[] Bitmap { get; set; }
}
