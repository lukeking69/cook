using System;

namespace Kamstrup.HC.NewWPF.Entities.Production;

public sealed class ProductionMessageRow
{
    public DateTime? OccurredAt { get; set; }
    public string Unit { get; set; }
    public string InternalNumber { get; set; }
    public string ErrorCode { get; set; }
    public string Description { get; set; }
}
