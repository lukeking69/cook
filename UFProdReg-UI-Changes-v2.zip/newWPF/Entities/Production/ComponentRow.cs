using System;

namespace Kamstrup.HC.NewWPF.Entities.Production;

public sealed class ComponentRow
{
    public string PartNumber { get; set; }
    public string Description { get; set; }
    public decimal? Quantity { get; set; }
    public string Unit { get; set; }
    public string Operation { get; set; }
    public string Status { get; set; }
}
