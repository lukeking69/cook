namespace Kamstrup.HC.NewWPF.Entities;

/// <summary>An explicit presentation state supplied by the owning view model.</summary>
public enum StatusIndicatorState
{
    Unknown,
    Waiting,
    Active,
    Success,
    Error
}
