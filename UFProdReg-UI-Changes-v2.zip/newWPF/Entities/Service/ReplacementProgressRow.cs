using Kamstrup.HC.NewWPF.Entities;
namespace Kamstrup.HC.NewWPF.Entities.Service;

public sealed class ReplacementProgressRow
{
    public string Title { get; set; }
    public string Status { get; set; }
    public string Details { get; set; }
    public StatusIndicatorState StatusIndicatorState { get; set; }
}
