namespace Kamstrup.HC.NewWPF.Entities.Service;

public sealed class ArchivedReleaseRow
{
    public string InternalNumber { get; set; }
    public string SerialNumber { get; set; }
    public string OrderNumber { get; set; }
    public string OrderLine { get; set; }
    public string VolumeInstrumentNumber { get; set; }
    public string BasicMeterType { get; set; }
}
