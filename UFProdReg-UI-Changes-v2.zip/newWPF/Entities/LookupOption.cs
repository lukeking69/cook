namespace Kamstrup.HC.NewWPF.Entities;

/// <summary>A selectable value supplied by the owner of a workspace.</summary>
public sealed class LookupOption
{
    public string Value { get; set; }
    public string DisplayName { get; set; }
}
