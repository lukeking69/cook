using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Autofac;
using Caliburn.Micro;
using Hcw.Common.Login.Core;
using HcwCommon.Core;
using HcwCommon.Core.Interfaces;
using HcwCommon.Dialogs;
using Kamstrup.HC.NewWPF.Interfaces;
using Kamstrup.HC.NewWPF.Properties;
using Kamstrup.HC.NewWPF.Utils;
using Kamstrup.HC.NewWPF.ViewModels;
using Kamstrup.HC.NewWPF.ViewModels.Components;
using Kamstrup.HC.NewWPF.ViewModels.Navigation;
using Kamstrup.HC.NewWPF.ViewModels.Production;
using Kamstrup.HC.NewWPF.ViewModels.Service;
using Kamstrup.HC.NewWPF.ViewModels.Labels;
using Kamstrup.HC.NewWPF.ViewModels.Systems;
using Kamstrup.HC.NewWPF.Views.Behaviours.KeyBinding;
using Login.Wpf;
using Microsoft.Extensions.Logging;
using TriggerBase = Microsoft.Xaml.Behaviors.TriggerBase;

namespace Kamstrup.HC.NewWPF;

public class Bootstrapper : BootstrapperBase
{
    private static IContainer _container;
    private ILogger<Bootstrapper> _logger;
    private ILoggerFactory _loggerFactory;

    public Bootstrapper()
    {
        Initialize();
    }

    protected override void BuildUp(object instance)
    {
        _container.InjectProperties(instance);
    }

    protected override void Configure()
    {
        Logger logger = new();

        _loggerFactory = logger.GetLogger();
        _logger = _loggerFactory.CreateLogger<Bootstrapper>();

        _logger?.LogDebug("Bootstrapper starter");

        try
        {
            ViewLocator.AddNamespaceMapping("Kamstrup.HC.NewWPF.ViewModels", "Kamstrup.HC.NewWPF.Views");
            SetupKeybinding();

            ContainerBuilder builder = new();

            builder.RegisterType<WindowManager>().AsImplementedInterfaces().SingleInstance();
            builder.RegisterType<EventAggregator>().AsImplementedInterfaces().SingleInstance();
            builder.RegisterType<UserAuthentication>().SingleInstance();
            builder.RegisterType<StepProgressViewModel>().AsSelf().As<IStepProgress>().SingleInstance();
            builder.RegisterType<TechnicianLoginCommand>().SingleInstance();
            builder.RegisterType<TechnicianLogoutCommand>().SingleInstance();
            builder.RegisterType<ProductionViewModel>().SingleInstance();
            builder.RegisterType<OrderViewModel>().SingleInstance();
            builder.RegisterType<PalletViewModel>().SingleInstance();
            builder.RegisterType<ExtractionViewModel>().SingleInstance();
            builder.RegisterType<ProductConfigurationViewModel>().SingleInstance();
            builder.RegisterType<MeterLookupViewModel>().SingleInstance();
            builder.RegisterType<ReleaseViewModel>().SingleInstance();
            builder.RegisterType<ReplacementViewModel>().SingleInstance();
            builder.RegisterType<ModuleViewModel>().SingleInstance();
            builder.RegisterType<RevisionViewModel>().SingleInstance();
            builder.RegisterType<CertificateViewModel>().SingleInstance();
            builder.RegisterType<BarcodeScanViewModel>().SingleInstance();
            builder.RegisterType<LabelPrintingViewModel>().SingleInstance();
            builder.RegisterType<ConfigurationViewModel>().SingleInstance();
            builder.RegisterType<HardwareStatusViewModel>().SingleInstance();
            builder.RegisterType<BigFlowViewModel>().SingleInstance();
            builder.RegisterType<ColorSelectionViewModel>().SingleInstance();
            builder.RegisterType<DatabaseInfoViewModel>().SingleInstance();
            builder.RegisterType<EventLogViewModel>().SingleInstance();
            builder.RegisterType<ProgramInfoViewModel>().SingleInstance();
            builder.RegisterType<DiagnosticsViewModel>().SingleInstance();
            builder.Register(c => new BindableCollection<MainMenuItemViewModel>
            {
                new("Funktioner",
                    c.Resolve<ProductionViewModel>(),
                    c.Resolve<OrderViewModel>(),
                    c.Resolve<PalletViewModel>(),
                    c.Resolve<ExtractionViewModel>(),
                    c.Resolve<ProductConfigurationViewModel>(),
                    c.Resolve<MeterLookupViewModel>(),
                    c.Resolve<ReleaseViewModel>(),
                    c.Resolve<ReplacementViewModel>(),
                    c.Resolve<ModuleViewModel>(),
                    c.Resolve<RevisionViewModel>(),
                    c.Resolve<CertificateViewModel>(),
                    c.Resolve<BarcodeScanViewModel>(),
                    c.Resolve<LabelPrintingViewModel>()),
                new("System",
                    c.Resolve<TechnicianLoginCommand>(),
                    c.Resolve<TechnicianLogoutCommand>(),
                    c.Resolve<ConfigurationViewModel>(),
                    c.Resolve<HardwareStatusViewModel>(),
                    c.Resolve<BigFlowViewModel>(),
                    c.Resolve<ColorSelectionViewModel>(),
                    c.Resolve<DatabaseInfoViewModel>(),
                    c.Resolve<EventLogViewModel>(),
                    c.Resolve<ProgramInfoViewModel>(),
                    c.Resolve<DiagnosticsViewModel>())
            }).SingleInstance();
            builder.RegisterType<MainViewModel>().SingleInstance();

            builder.Register(c =>
            {
                SmartCardReader cardReader = new();
                LoginWpf login = new(
                    permissionPrefix: "",
                    PermissionName: "Operator",
                    new ScanSmartCards(cardReader)
                );
                UserManagement userManagement = new(
                        login: login,
                        smartCardReader: cardReader,
                        _loggerFactory.CreateLogger<UserManagement>(),
                        smartCardLookupServiceUrl: App.Config.SmartCardLookupServiceUrl,
                        requirePassword: false,
                        inactivitySecondsUser: App.Config.InactivityTimeOut,
                        inactivitySecondsLogin: App.Config.InactivityTimeOut
                    )
                { IgnoreSmartCardEventsWhenLoginIsShowing = false };
                return userManagement;
            }).As<IUserManagement2>().InstancePerDependency();

            builder.Register(c => new DialogService1(App.Config.MessageBoxSizeWidth, App.Config.MessageBoxSizeHeight)).As<IDialogService3>();
            builder.RegisterType<DialogCanceller>().As<IDialogCanceller>();
            builder.Register(c => _loggerFactory).As<ILoggerFactory>();
            builder.Register(c => logger);

            _logger?.LogDebug("Bootstrapper færdig");
            _container = builder.Build();

            _container.Resolve<UserAuthentication>().SetPermissionPrefix("UFProdReg");
        }
        catch (Exception ex)
        {
            _logger?.LogCritical(ex, ex.Message);
            throw;
        }
    }

    protected override IEnumerable<object> GetAllInstances(Type service)
    {
        Type type = typeof(IEnumerable<>).MakeGenericType(service);
        return _container.Resolve(type) as IEnumerable<object>;
    }

    protected override object GetInstance(Type service, string key)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                if (_container.IsRegistered(service))
                    return _container.Resolve(service);
            }
            else
            {
                if (_container.IsRegisteredWithKey(key, service))
                    return _container.ResolveKeyed(key, service);
            }
            string msgFormat = "Could not locate any instances of contract {0}.";
            string msg = string.Format(msgFormat, key ?? service.Name);
            throw new Exception(msg);
        }
        catch (Exception e)
        {
            _logger?.LogError(e, "Error in GetInstance");
            return null;
        }
    }

    protected override async void OnStartup(object sender, StartupEventArgs e)
    {
        try
        {
            if (ProgramInstanceGuard.IsProgramAlreadyRunning())
            {
                _container.Resolve<IDialogService3>().ShowMessageBox("Dobbelt start", "Dette program kører allerede.", DialogSeverity.Warning,
                    width: App.Config.MessageBoxSizeWidth, height: App.Config.MessageBoxSizeHeight);
                Application.Current.Shutdown();
                return;
            }

            ApplyThemeOverrides();
            Dictionary<string, object> settings = GetSettings();
            await DisplayRootViewForAsync<MainViewModel>(settings);

            Application.MainWindow.Closing += MainWindow_Closing;
            Application.MainWindow.Closed += (_, _) => _loggerFactory?.Dispose();
        }
        catch (Exception ex)
        {
            _logger?.LogCritical(ex, ex.Message);
            throw;
        }
    }

    private static Dictionary<string, object> GetSettings()
    {
        Dictionary<string, object> settings = null;
        if (!App.Config.Debug)
        {
            try
            {
                settings = new Dictionary<string, object>
                {
                    { "Height", Settings.Default.WindowHeight },
                    { "Width", Settings.Default.WindowWidth },
                    { "Top", App.Config.ForceStartOnScreen ? 10 : Settings.Default.WindowTop },
                    { "Left", App.Config.ForceStartOnScreen ? 10 : Settings.Default.WindowLeft },
                    { "WindowState", Settings.Default.WindowState }
                };
            }
            catch
            {
            }
        }
        return settings;
    }

    protected override void OnUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        _logger?.LogCritical(e.Exception, "Unhandled Exception");
    }

    protected override IEnumerable<Assembly> SelectAssemblies()
    {
        Assembly[] assemblyList = new[]
        {
            Assembly.GetExecutingAssembly()
        };
        return assemblyList;
    }

    private static void ApplyThemeOverrides()
    {
#if DEBUG || PRERELEASE
        Application.Current.Resources["MaterialDesign.Brush.Background"] = new SolidColorBrush(Color.FromRgb(243, 246, 248));
#endif
    }

    private void MainWindow_Closing(object sender, EventArgs e)
    {
        if (Application.MainWindow.WindowState != WindowState.Minimized)
        {
            Settings.Default.WindowTop = Application.MainWindow.Top;
            Settings.Default.WindowLeft = Application.MainWindow.Left;
            Settings.Default.WindowHeight = Application.MainWindow.Height;
            Settings.Default.WindowWidth = Application.MainWindow.Width;
            Settings.Default.WindowState = Application.MainWindow.WindowState;
            Settings.Default.Save();
        }
    }

    private void SetupKeybinding()
    {
        Func<DependencyObject, string, TriggerBase> defaultCreateTrigger = Parser.CreateTrigger;

        Parser.CreateTrigger = (target, triggerText) =>
        {
            if (triggerText == null) return defaultCreateTrigger(target, null);

            string triggerDetail = triggerText
                .Replace("[", string.Empty)
                .Replace("]", string.Empty);

            string[] splits = triggerDetail.Split((char[])null, StringSplitOptions.RemoveEmptyEntries);

            switch (splits[0])
            {
                case "Key":
                    Key key = (Key)Enum.Parse(typeof(Key), splits[1], true);
                    return new KeyTrigger { Key = key };

                case "Gesture":
                    MultiKeyGesture mkg = (MultiKeyGesture)(new MultiKeyGestureConverter()).ConvertFrom(splits[1]);
                    return new KeyTrigger { Modifiers = mkg.KeySequences[0].Modifiers, Key = mkg.KeySequences[0].Keys[0] };
            }

            return defaultCreateTrigger(target, triggerText);
        };
    }
}