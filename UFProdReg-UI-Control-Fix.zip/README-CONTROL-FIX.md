# UFProdReg – rettelse af XAML-kontroller

Denne lille pakke opdaterer kun projektfilen og de nødvendige kontrolfiler i den allerede leverede UFProdReg UI. Workspaces, ViewModels og produktionsfunktionalitet ændres ikke.

## Installation

1. Luk Visual Studio.
2. Pak UFProdReg-UI-Control-Fix.zip ud med Windows' almindelige udpakker.
3. Kopiér indholdet ind i projektets rodmappe, hvor NewProgram.sln ligger. Bevar mappestrukturen, og overskriv de tilsvarende filer. Medtag også newWPF/newWPF.csproj og alle .xaml.cs-filer.
4. Hvis din projektfil allerede har egne ændringer, sammenflet i stedet den kommenterede kontrolgruppe fra den leverede newWPF.csproj med din projektfil. Gruppens Compile/Page Remove skal stå før Include; behold dine øvrige tilpasninger og afhængigheder.
5. Fjern de genererede newWPF/bin- og newWPF/obj-mapper. Åbn løsningen, gendan pakker, og kør Rebuild med Release | x86.

## Hvad rettelsen gør

- StatusBadgeView, StepProgressView og StepLabelView leveres som komplette XAML/code-behind-par med matchende namespaces.
- Projektfilen inkluderer kontrollerne eksplicit som Page og Compile. Implicitte SDK-items fjernes først, så der ikke dannes dubletter.
- StatusBadgeView beholder de offentlige Text/State dependency properties og alle eksisterende bindings.
- StepProgressView viser stadig Steps og bruger en almindelig WPF-trigger til HasSteps.
- Den lille StatusIndicatorState-enum medfølger som kontrolafhængighed.

## Kontrol

Udeladelse af StatusBadgeView.xaml.cs fra kompileringen reproducerer MC3072 om den manglende Text-property. Udeladelse af StepProgressView-filparret reproducerer MC3074 på MainView.xaml linje 104. Det er en reproduceret tilsvarende fejltilstand; brugerens lokale projekt er ikke undersøgt.

Den rettede løsning er bygget fra en ren kildekopi med 0 fejl og 0 advarsler mod .NET Framework 4.8 og de reelle afhængigheder. Projektets originale NuGet-referenceversioner er bevaret; lokale validerings-overrides er ikke med i pakken. Windows-layout/runtime er ikke afprøvet her.

UI-CONTROL-FIX.json viser filstier og checksums. Nogle kontrolafhængigheder er identiske med den første levering og medtages for at give komplette filpar.
