# UFProdReg UI – ændringer til den uploadede NewWPF-base

Denne pakke indeholder kun tilføjede og ændrede filer til den oprindeligt uploadede `NewWPF_WithCaliburnMicro`-base. Den leverer UI, bindbar præsentationstilstand og kommandoegenskaber. Ingen produktionsadapter, databaseadgang, hardwarefunktioner eller produktionsregler er tilføjet.

## Anvend pakken

1. Pak den oprindelige NewWPF-base ud i en arbejdsmappe.
2. Pak `UFProdReg-UI-Changes.zip` ud med Windows' almindelige udpakker.
3. Kopiér indholdet ind i basens rodmappe, hvor `NewProgram.sln` ligger. Bevar undermapperne, og overskriv de eksisterende filer med samme navn.
4. Åbn `NewProgram.sln` i Visual Studio med .NET desktop development og .NET Framework 4.8 targeting pack. Vælg `newWPF` som startup-projekt og `Release | x86`.

Pakken er beregnet til den oprindelige uploadede base. En tidligere levering med den generiske formularmotor skal erstattes af en frisk kopi af basen med denne ændringspakke ovenpå.

De originale NuGet-pakker og versionsnumre er bevaret. Brug basens eksisterende virksomhedsfeeds ved restore. Arkivet indeholder ingen DLL'er, kompilerede programmer, gamle projekter eller originale konfigurationsfiler.

## Struktur og navigation

- Caliburn.Micro, `MainMenu`, `SubMenu`, `ActiveItem` og `Conductor<WorkspaceViewModelBase>.Collection.OneActive` bruges som i basen.
- Menuerne `Funktioner` og `System` registreres i `Bootstrapper.Configure()`.
- Alle 21 nye workspaces har et separat native XAML View, code-behind til `InitializeComponent()` og en parameterløs ViewModel direkte på `WorkspaceViewModelBase`. Hver constructor sætter `DisplayName` og `Icon`.
- Eksisterende menukommandoer bruger fortsat `CommandBase`. Workspaces kan kontrollere navigation gennem `CanCloseAsync`; indstillingssiden følger dette mønster.
- Nye styles ligger i `newWPF/Ressources/Styles/UfStyles.xaml`. Basens eksisterende styles genbruges.
- DTO-rækker og valgmuligheder ligger i `Entities`. Fælles UI-hjælpere ligger i `Utils` og `Views/Controls`.

## Binding til fremtidig funktionalitet

ViewModels eksponerer navngivne properties med change notification. Identifikatorer er tekst, antal/målinger er nullable numeriske typer, og datoer er `DateTime?`. Billedvisninger bruger `ImageSource` i ViewModels. DTO-rækker indeholder kun dataegenskaber.

Dropdowns har tomme `BindableCollection<LookupOption>`-lister. `LookupOption.Value` er den stabile værdi; `DisplayName` er den viste tekst. Faktiske valg og revisioner kan leveres senere.

Hver arbejdsområdeknap er bundet til en navngiven `ICommand`-property, eksempelvis `ProductionViewModel.LoadOrderCommand`. Sæt egenskaben til din egen kommandoimplementation, når funktionaliteten tilkobles. En manglende kommando vises deaktiveret; tilkoblede kommandoer styres af deres `CanExecute`. De nye ViewModels udfører ingen produktionshandlinger.

Tabeller har eksplicitte kolonner bundet til navngivne DTO-properties og bindbare typed collections. Tilføj eller erstat rækker i samlingen ved opdatering; de rene DTO-rækker har ingen egen change-notification-logik.

Statusindikatorer bindes særskilt til tekst og `StatusIndicatorState` (`Unknown`, `Waiting`, `Active`, `Success`, `Error`). Farven udledes ikke fra statusord. Produktionens trin kan bruge basens eksisterende `StepState`.

Enter/scannergenveje er native `KeyBinding`-bindings til de tilsvarende læse-/scancommands. Der er ingen automatisk registrering, frigivelse eller print i denne UI-levering.

Indstillingssiden har en lokal UI-baseline og `AcceptChanges()`. Efter indlæsning eller vellykket gem kan ejeren kalde `AcceptChanges()`. UI'et antager ingen gemning og indeholder ingen persistens. Password-input på diagnosesiden bindes som `SecureString` gennem `PasswordBoxBinding`; den fremtidige ejer håndterer de modtagne kopiers levetid.

## App-tilpasninger

`SetPermissionPrefix()` er ændret til `UFProdReg`; custom workspace-typer er registreret i DI. `.gitlab-ci.yml` har `HC\UFProdReg` som publish-undermappe, nye faste UpgradeCodes til Release/Prerelease og `newWPF\newWPF.csproj` som projektsti. Eksisterende pipeline-include og NuGet-versioner er bevaret.

## Kontrol og kildegrundlag

XAML, namespaces, lokale ressourcer og de almindelige ViewModel-/DTO-bindings er kontrolleret. Kompilering er kontrolleret i Linux mod .NET Framework 4.8 og de reelle afhængigheder fra den uploadede base. De lokale build-overrides og afhængighedsfiler indgår ikke i leverancen. Windows-layout og runtimebindings skal afprøves i Visual Studio/på Windows.

Den gamle kode er kun brugt til at kortlægge UI-felter og handlinger. De interne kontroller i den eksterne IFS-stykliste og farveeditor findes ikke i de tilgængelige kilder; UI'et repræsenterer de kendte oplysninger og kommandoer.

`UI-CHANGES.json` angiver præcis hvilke filer der er tilføjet/ændret samt deres checksums. Alle andre filer fra NewWPF-basen bevares.
