# UFProdReg – rettelse af read-only bindings

Denne pakke ændrer kun newWPF/Views/MainView.xaml fra det senest uploadede projekt. Dit layout og alle andre bytes i filen er bevaret; tre bindings får Mode=OneWay.

## Anvend rettelsen

1. Luk programmet og Visual Studio.
2. Pak UFProdReg-UI-Binding-Fix.zip ud med Windows' almindelige udpakker.
3. Kopiér newWPF/Views/MainView.xaml til den tilsvarende placering i dit projekt, og overskriv filen.
4. Åbn løsningen, rebuild og start programmet.

Der skal ikke ændres i projektfilen, ViewModels eller loginlogikken.

## Årsag og ændringer

WPF Run.Text bruger som standard en TwoWay-binding. OperatorName er en skrivebeskyttet property, så WPF afviser bindingen ved opstart. Det samme gælder LoginRemainingSeconds og TechnicianName.

Alle tre Run.Text-bindings bruger nu eksplicit Mode=OneWay. De kan vise opdateringer fra ViewModelens eksisterende change notifications uden at skrive tilbage til login-/statusproperties.

UI-BINDING-FIX.json angiver filen og checksums før/efter. Pakken indeholder kun den ændrede XAML og denne dokumentation; ingen DLL'er eller konfigurationsfiler.

Det korrigerede uploadede projekt kompilerer med 0 fejl og 0 advarsler med basens reelle afhængigheder. Andre bindings til skrivebeskyttede properties er gennemgået; ingen tilsvarende skrivebinding blev fundet. Linux-kontrollen kan ikke afprøve WPF-programmet på Windows.
